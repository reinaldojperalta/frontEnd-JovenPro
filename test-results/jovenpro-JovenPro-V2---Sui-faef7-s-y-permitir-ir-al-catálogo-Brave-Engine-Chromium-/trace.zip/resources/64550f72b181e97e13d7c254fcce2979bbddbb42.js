(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/src_0khraa3._.js","static/chunks/node_modules_0hvcp5n._.js"],
    source: "dynamic"
});
