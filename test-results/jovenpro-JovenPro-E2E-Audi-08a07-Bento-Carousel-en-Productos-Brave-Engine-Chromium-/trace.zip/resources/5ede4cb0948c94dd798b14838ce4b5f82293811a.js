(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/lib/framer-features.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
// src/lib/framer-features.ts
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$dom$2f$features$2d$animation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/render/dom/features-animation.mjs [app-client] (ecmascript)");
;
const __TURBOPACK__default__export__ = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$dom$2f$features$2d$animation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["domAnimation"];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/atoms/Container/Container.variants.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "containerVariants",
    ()=>containerVariants
]);
// ============================================================================
// CONTAINER VARIANTS — Átomo de layout estructural
// ============================================================================
// REFACTOR V3:
// - Todos los tipos exportados ahora se derivan del CVA via Parameters<typeof>
//   en lugar de listas hardcodeadas. Elimina riesgo de desincronización.
// - Tokens validados contra paleta V3:
//   • bg-surface, bg-surface-container, bg-background: existen
//   • shadow-clay, shadow-clay-active, rounded-clay: existen
//   • border-surface-variant: existe
// - No hay colores hardcodeados ni tokens fantasmas en este archivo.
// - Nota de diseño: "surface-container" (#F8FAFC) y "surface" (#F1F5F9) tienen
//   contraste 1.11:1. No anidar variantes de estas dos capas sin borde visible.
// ============================================================================
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/class-variance-authority/dist/index.mjs [app-client] (ecmascript)");
;
const containerVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("mx-auto w-full", {
    variants: {
        size: {
            xs: "max-w-xl",
            sm: "max-w-3xl",
            md: "max-w-5xl",
            lg: "max-w-7xl",
            xl: "max-w-[1440px]",
            full: "max-w-none",
            prose: "max-w-prose"
        },
        padding: {
            none: "px-0",
            xs: "px-2",
            sm: "px-4",
            md: "px-4 md:px-6",
            lg: "px-4 md:px-8",
            xl: "px-12",
            "2xl": "px-16"
        },
        paddingY: {
            none: "py-0",
            xs: "py-4",
            sm: "py-8",
            md: "py-16",
            lg: "py-24",
            xl: "py-32",
            "2xl": "py-40"
        },
        variant: {
            transparent: "",
            surface: "bg-surface",
            "surface-container": "bg-surface-container",
            background: "bg-background",
            clay: "bg-surface shadow-clay rounded-clay",
            "clay-active": "bg-surface shadow-clay-active rounded-clay",
            bordered: "border-2 border-surface-variant rounded-clay"
        },
        align: {
            left: "mr-auto ml-0",
            center: "mx-auto",
            right: "ml-auto mr-0"
        },
        minHeight: {
            none: "",
            screen: "min-h-screen",
            "75vh": "min-h-[75vh]",
            "50vh": "min-h-[50vh]"
        },
        flex: {
            true: "flex flex-col",
            false: ""
        },
        centered: {
            true: "items-center justify-center",
            false: ""
        },
        radius: {
            none: "rounded-none",
            sm: "rounded-sm",
            md: "rounded-md",
            lg: "rounded-lg",
            clay: "rounded-clay",
            full: "rounded-full"
        }
    },
    defaultVariants: {
        size: "lg",
        padding: "md",
        paddingY: "none",
        variant: "transparent",
        align: "center",
        minHeight: "none",
        flex: false,
        centered: false,
        radius: "none"
    }
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/data.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// src/lib/data.ts
// ============================================
// DATOS MOCK — JovenPro V2 SPA (Imágenes locales)
// ============================================
// --------------------------------------------
// TIPOS BASE
// --------------------------------------------
__turbopack_context__.s([
    "categories",
    ()=>categories,
    "footerData",
    ()=>footerData,
    "heroSplitData",
    ()=>heroSplitData,
    "navItems",
    ()=>navItems,
    "newsItems",
    ()=>newsItems,
    "stores",
    ()=>stores,
    "testimonials",
    ()=>testimonials,
    "videos",
    ()=>videos,
    "workWithUsData",
    ()=>workWithUsData
]);
const navItems = [
    {
        label: "Inicio",
        href: "#inicio"
    },
    {
        label: "Productos",
        href: "#productos"
    },
    {
        label: "Noticias",
        href: "#journal"
    },
    {
        label: "Videos",
        href: "#videos"
    },
    {
        label: "Testimonios",
        href: "#testimonios"
    },
    {
        label: "emprende",
        href: "#contacto"
    }
];
const categories = [
    {
        id: "todos",
        name: "Todos",
        icon: "LayoutGrid",
        count: 24
    },
    {
        id: "ceramica",
        name: "Cerámica",
        icon: "Coffee",
        count: 6
    },
    {
        id: "textil",
        name: "Textil",
        icon: "Scissors",
        count: 5
    },
    {
        id: "joyeria",
        name: "Joyería",
        icon: "Gem",
        count: 4
    },
    {
        id: "madera",
        name: "Madera",
        icon: "TreePine",
        count: 5
    },
    {
        id: "cuero",
        name: "Cuero",
        icon: "ShoppingBag",
        count: 4
    }
];
const stores = [
    {
        id: "345",
        slug: "fragola-premium",
        name: "Fragola Premium",
        description: "Condiciones de entrega y conservación La entrega del producto se realiza a domicilio, por lo cual el cliente debe proporcionar una dirección exacta y completa, o indicar un lugar específico y seguro donde el pedido pueda ser recibido o dejado. Una vez entregado, es responsabilidad del cliente garantizar su adecuada conservación.  El producto debe mantenerse en un lugar fresco y seco. No es necesario refrigerarlo; sin embargo, en caso de hacerlo, se recomienda no someterlo a temperaturas muy bajas, ya que esto puede afectar su textura y calidad original. Se aconseja evitar la exposición directa al sol, al calor excesivo o a la humedad para conservar el producto en óptimas condiciones.",
        image: "/images/products/fragola-premium.webp",
        location: "Firavitoba, BOY",
        rating: 0.0,
        reviewCount: 0,
        emprendedor: {
            name: "Leidy Johana Molano Lopez",
            avatar: "/images/artisans/fragola-premium-avatar.webp",
            initials: "LM",
            verified: false
        }
    },
    {
        id: "340",
        slug: "luna-glam",
        name: "Luna Glam",
        description: "Tienda Luna Glam.",
        image: "/images/products/luna-accesorios.webp",
        location: "TOL",
        rating: 0.0,
        reviewCount: 0,
        emprendedor: {
            name: "Mayfred Toledo Perez",
            avatar: "/images/artisans/luna-accesorios-avatar.webp",
            initials: "MT",
            verified: false
        }
    },
    {
        id: "339",
        slug: "httpswww-instagram-comrouri_col",
        name: "Róuri",
        description: "Tienda Róuri en sogamoso.",
        image: "/images/products/r-uri.webp",
        location: "sogamoso, BOY",
        rating: 0.0,
        reviewCount: 0,
        emprendedor: {
            name: "Grether Ruiz",
            avatar: "",
            initials: "GR",
            verified: false
        }
    },
    {
        id: "337",
        slug: "inspira-turquesa",
        name: "Inspira Turquesa",
        description: "Todos nuestros artículos son confeccionados o fabricados a mano con materiales de calidad, especialmente pensados para el cuidado del cabello y uso personal. Las imágenes de nuestros productos son de referencia. Debido al proceso artesanal, pueden existir ligeras variaciones en colores, costuras o acabados. En productos personalizados (como pulseras o kits especiales), no se aceptan modificaciones una vez aprobado el diseño final por el cliente. Nuestros accesorios elaborados en rodio y acero presentan una excelente calidad. Sin embargo, no cuentan con garantía, ya que su durabilidad depende del pH de la piel de cada persona y del cuidado que se les brinde.",
        image: "/images/products/inspira-turquesa.webp",
        location: "Sogamoso, BOY",
        rating: 0.0,
        reviewCount: 0,
        emprendedor: {
            name: "Katherin Andrea Lopez Vija",
            avatar: "/images/artisans/inspira-turquesa-avatar.webp",
            initials: "KL",
            verified: false
        }
    },
    {
        id: "336",
        slug: "waypaoficial-com",
        name: "Waypa",
        description: "Tienda Waypa en Bucaramanga.",
        image: "/images/products/calzado-hombre-ref-raices.webp",
        location: "Bucaramanga, SAN",
        rating: 0.0,
        reviewCount: 0,
        emprendedor: {
            name: "Walter Jesus Rivera Morad",
            avatar: "",
            initials: "WR",
            verified: false
        }
    },
    {
        id: "332",
        slug: "nextgen-3dlasersolutions",
        name: "NextGen 3D",
        description: "Tienda NextGen 3D en Diutama.",
        image: "/images/products/nextgen-3d.webp",
        location: "Diutama, BOY",
        rating: 0.0,
        reviewCount: 0,
        emprendedor: {
            name: "MAYRA ALEJANDRA MARTINEZ HERRERA",
            avatar: "",
            initials: "MM",
            verified: false
        }
    },
    {
        id: "326",
        slug: "carolinda",
        name: "Carolinda",
        description: "Tienda Carolinda en Tuta.",
        image: "/images/products/carolinda.webp",
        location: "Tuta, BOY",
        rating: 0.0,
        reviewCount: 0,
        emprendedor: {
            name: "Carolina Prieto",
            avatar: "/images/artisans/carolinda-avatar.webp",
            initials: "CP",
            verified: false
        }
    },
    {
        id: "321",
        slug: "3d-land",
        name: "3D-Land",
        description: "Tienda 3D-Land en Firavitoba.",
        image: "/images/products/3d-land.webp",
        location: "Firavitoba, BOY",
        rating: 0.0,
        reviewCount: 0,
        emprendedor: {
            name: "Fabian Andres Salamanca F.",
            avatar: "/images/artisans/3d-land-avatar.webp",
            initials: "FS",
            verified: false
        }
    },
    {
        id: "319",
        slug: "upin-pines-metalicos",
        name: "UPin Pines Metálicos",
        description: "Tienda UPin Pines Metálicos en Sogamoso.",
        image: "/images/products/upin-pines-met-licos.webp",
        location: "Sogamoso, BOY",
        rating: 0.0,
        reviewCount: 0,
        emprendedor: {
            name: "Sebastian Camargo Cuesto",
            avatar: "/images/artisans/upin-pines-met-licos-avatar.webp",
            initials: "SC",
            verified: false
        }
    },
    {
        id: "318",
        slug: "licores-artesanales-jb",
        name: "Licores Artesanales JB",
        description: "Tienda Licores Artesanales JB en Duitama.",
        image: "/images/products/ancheta-jb-licores.webp",
        location: "Duitama, BOY",
        rating: 0.0,
        reviewCount: 0,
        emprendedor: {
            name: "Jaider Fabian Blanco Becerra",
            avatar: "/images/artisans/licores-artesanales-jb-avatar.webp",
            initials: "JB",
            verified: false
        }
    },
    {
        id: "317",
        slug: "httpswww-facebook-comprofile-phpid61553130868135",
        name: "LUX DENT ODONTOLOGIA Y ESTETICA S.A.S",
        description: "Tienda LUX DENT ODONTOLOGIA Y ESTETICA S.A.S en SOGAMOSO.",
        image: "/images/products/lux-dent-odontologia-y-estetica-s-a-s.webp",
        location: "SOGAMOSO, BOY",
        rating: 0.0,
        reviewCount: 0,
        emprendedor: {
            name: "Ivonne Alejandra Quiceno Zamora",
            avatar: "",
            initials: "IQ",
            verified: false
        }
    },
    {
        id: "296",
        slug: "angela-saavedra-mentora-de-negocios",
        name: "Ángela Saavedra Mentora de negocios",
        description: "Tienda Ángela Saavedra Mentora de negocios.",
        image: "/images/products/Asesoria.jpeg",
        location: "",
        rating: 0.0,
        reviewCount: 0,
        emprendedor: {
            name: "Angela Saavedra",
            avatar: "",
            initials: "AS",
            verified: false
        }
    },
    {
        id: "271",
        slug: "httpswww-instagram-comcrochetaretes",
        name: "Crochetaretes",
        description: "Tienda Crochetaretes.",
        image: "/images/products/arete.png",
        location: "x",
        rating: 0.0,
        reviewCount: 0,
        emprendedor: {
            name: "Diana Ximena Ladino Morales",
            avatar: "",
            initials: "DL",
            verified: false
        }
    },
    {
        id: "137",
        slug: "uvihatu_esencial",
        name: "Uvihatu_esencial",
        description: "Tienda Uvihatu_esencial en Sogamoso.",
        image: "/images/products/uvihatu-esencial.webp",
        location: "Sogamoso, BOY",
        rating: 0.0,
        reviewCount: 0,
        emprendedor: {
            name: "Leidy Marcela León Tellez",
            avatar: "/images/artisans/uvihatu-esencial-avatar.webp",
            initials: "LL",
            verified: false
        }
    },
    {
        id: "106",
        slug: "makadamia-velas-y-aromas",
        name: "Makadamia - Velas y aromas",
        description: "Tienda Makadamia - Velas y aromas en Duitama.",
        image: "/images/products/makadamia-velas-y-aromas.webp",
        location: "Duitama, Boyacá",
        rating: 0.0,
        reviewCount: 0,
        emprendedor: {
            name: "Monica Murcia",
            avatar: "/images/artisans/makadamia-velas-y-aromas-avatar.webp",
            initials: "MM",
            verified: false
        }
    },
    {
        id: "84",
        slug: "arttemacu",
        name: "MACU",
        description: "Tienda MACU en Bogota D.c.",
        image: "/images/products/macu.webp",
        location: "Bogota D.c",
        rating: 0.0,
        reviewCount: 0,
        emprendedor: {
            name: "Maria Castro",
            avatar: "/images/artisans/macu-avatar.webp",
            initials: "MC",
            verified: false
        }
    },
    {
        id: "36",
        slug: "julio-cesar-gonzalez-mejia-abogados-asesores",
        name: "Julio César González Mejía Abogados Asesores",
        description: "Tienda Julio César González Mejía Abogados Asesores en Sogamoso.",
        image: "/images/products/julio-c-sar-gonz-lez-mej-a-abogados-asesores.webp",
        location: "Sogamoso, Boyacá",
        rating: 0.0,
        reviewCount: 0,
        emprendedor: {
            name: "Julio César González Mejía",
            avatar: "/images/artisans/julio-c-sar-gonz-lez-mej-a-abogados-asesores-avatar.webp",
            initials: "JG",
            verified: false
        }
    },
    {
        id: "30",
        slug: "uzesuamox",
        name: "UZE Suamox",
        description: "Tienda UZE Suamox.",
        image: "/images/products/collar.png",
        location: "",
        rating: 0.0,
        reviewCount: 0,
        emprendedor: {
            name: "Astrid Constanza Castro Gordillo",
            avatar: "",
            initials: "AC",
            verified: false
        }
    },
    {
        id: "25",
        slug: "tuarte",
        name: "TuArte",
        description: "Tienda TuArte en Sogamoso.",
        image: "/images/products/tuarte.webp",
        location: "Sogamoso, Boyacá",
        rating: 0.0,
        reviewCount: 0,
        emprendedor: {
            name: "Javier Mojica",
            avatar: "/images/artisans/tuarte-avatar.webp",
            initials: "JM",
            verified: false
        }
    },
    {
        id: "20",
        slug: "gricellarts",
        name: "Gricellarts",
        description: "Tienda Gricellarts en Bogota.",
        image: "/images/products/gricellarts.webp",
        location: "Bogota, CUN",
        rating: 0.0,
        reviewCount: 0,
        emprendedor: {
            name: "CLAUDIA EMILSEN LOPEZ RIAÑO",
            avatar: "/images/artisans/gricellarts-avatar.webp",
            initials: "CL",
            verified: false
        }
    },
    {
        id: "16",
        slug: "muiscafe",
        name: "MUISCAFE",
        description: "Tienda MUISCAFE en Sogamoso.",
        image: "/images/products/muiscafe.webp",
        location: "Sogamoso",
        rating: 0.0,
        reviewCount: 0,
        emprendedor: {
            name: "Gonzalo Chaparro Mongui",
            avatar: "/images/artisans/muiscafe-avatar.webp",
            initials: "GC",
            verified: false
        }
    }
];
const newsItems = [
    {
        id: "news-001",
        title: "Capacitaciones & Cursos para Emprendedores",
        excerpt: "Universidad Santo Tomas 11 y 12 de Mayo Emprendimiento a otro nivel Capacitaciones en Marketing Digital con Inteligencia Artificia en Alianza Peace Corps Colombia Alianza Internacional para promover productos en Estados Únidos.",
        category: "Capacitaciones",
        image: "/images/news/jovenpro_noticia_uno.webp",
        date: "12 May 2026",
        readTime: "5 min",
        href: "https://www.sumerce.org/jovenpro"
    },
    {
        id: "news-002",
        title: "Tejiendo tradición: El arte wayúu",
        excerpt: "Conoce el significado de cada patrón y color en el tejido ancestral del pueblo wayúu.",
        category: "Textil",
        image: "/images/news/madera-andes.jpg",
        date: "25 Abr 2026",
        readTime: "4 min",
        href: "https://jovenpro.com/"
    },
    {
        id: "news-003",
        title: "La madera noble de los Andes",
        excerpt: "Un recorrido por los talleres de ebanistería que utilizan maderas sostenibles de la región.",
        category: "Madera",
        image: "/images/news/madera-andes.jpg",
        date: "22 Abr 2026",
        readTime: "6 min",
        href: "https://jovenpro.com/"
    },
    {
        id: "news-004",
        title: "Plata y esmeraldas: la dupla perfecta",
        excerpt: "Tendencias en joyería artesanal colombiana para esta temporada.",
        category: "Joyería",
        image: "/images/news/plata-esmeraldas.jpg",
        date: "18 Abr 2026",
        readTime: "3 min",
        href: "https://jovenpro.com/"
    },
    {
        id: "news-005",
        title: "Cerámica raku: fuego y alma colombiana",
        excerpt: "La técnica milenaria del raku llega a los talleres de JovenPro. Descubre cómo nuestros artesanos fusionan la tradición japonesa con la identidad boyacense.",
        category: "Cerámica",
        image: "/images/news/madera-andes.jpg",
        date: "10 Abr 2026",
        readTime: "5 min",
        href: "https://jovenpro.com/"
    }
];
const testimonials = [
    {
        id: "test-001",
        name: "QuigsyOnlineShop",
        role: "@quigsyonlineshop",
        avatar: "/images/testimonials/quisisy-avatar.webp",
        initials: "Quigsy",
        text: "Me ayuda a conseguir clientes, ha sido mi vitrina comercial y subió mis ventas en un 70% Instagram @quigsyonlineshop",
        rating: 4,
        productImage: "/images/testimonials/quisisy-avatar.webp"
    },
    {
        id: "test-002",
        name: "Dementes Abiertas",
        role: "@dementesabiertasboyaca",
        avatar: "/images/testimonials/dementes-avatar.webp",
        initials: "Dementes Abiertas",
        text: "He podido potenciar mis clientes, la publicidad en redes sociales y el reconocimiento que tenemos nosotros los emprendedores en cuanto a ferias comerciales.",
        rating: 5
    },
    {
        id: "test-003",
        name: "Atisbe",
        role: "@_atisbe_",
        avatar: "/images/testimonials/atisbe-avatar.webp",
        initials: "Atisbe",
        text: "El inmenso valor de hacer alianza con Joven Pro, me permite eso en diferentes formas, porque no sólo es el espacio físico abierto constantemente...",
        rating: 4
    }
];
const videos = [
    {
        id: "vid-001",
        title: "El Proceso Creativo",
        thumbnail: "/images/videos/thumbnail-raku.jpg",
        youtubeId: "VEMl5roUvtM",
        duration: "12:34",
        emprendedor: "María Camila R."
    },
    {
        id: "vid-002",
        title: "Comunidad JovenPro",
        thumbnail: "/images/videos/thumbnail-wayuu.jpg",
        youtubeId: "ahDnIPYPPgQ",
        duration: "08:21",
        emprendedor: "Luisa Fernanda T."
    }
];
const heroSplitData = {
    left: {
        title: "Crea con nosotros",
        subtitle: "Únete a nuestra plataforma y lleva tus productos a miles de compradores.",
        cta: "Quiero vender",
        href: "#contacto",
        image: "/images/hero/imagen_heroSide_emprendedor.webp"
    },
    right: {
        title: "Apoya lo local",
        subtitle: "Descubre artesanías únicas, hechas a mano por emprendedores colombianos.",
        cta: "Explorar tienda.",
        href: "#productos",
        image: "/images/hero/emprendedor-mirror.jpg"
    },
    logoSrc: "/images/logo/JovenPro-by-ZonaPro.png"
};
const workWithUsData = {
    headline: "Únete a los demás emprendedores.",
    subheadline: "Transforma tu pasión en un negocio próspero. Accede a herramientas exclusivas, visibilidad internacional y una comunidad que respalda tu crecimiento emprendedor.",
    sectionLabel: "Maker Hub",
    socialsLabel: "Conecta con nosotros",
    whatsappDisplayLabel: "WhatsApp: +57 302 484 0101",
    instagramUrl: "https://www.instagram.com/jovenprocolombia",
    facebookUrl: "https://www.facebook.com/jovenprocolombia",
    whatsappNumber: "573024840101",
    whatsappMessage: "Hola, estoy interesado en ser emprendedor JovenPro.",
    mapUrl: "https://maps.app.goo.gl/Lq3bkJrCh4hacK8g7",
    locationLabel: "JovenPro / Sogamoso, Boyacá",
    mapImageUrl: "/images/logo/mapa.webp",
    locationSubLabel: "Descubre tu potencial"
};
const footerData = {
    brand: "JOVENPRO",
    tagline: "Hecho a mano, hecho con alma.",
    links: [
        {
            label: "Términos y condiciones",
            href: "#"
        },
        {
            label: "Política de privacidad",
            href: "#"
        },
        {
            label: "Preguntas frecuentes",
            href: "#"
        }
    ],
    socials: [
        {
            label: "Instagram",
            href: "https://www.instagram.com/jovenprocolombia"
        },
        {
            label: "Facebook",
            href: "https://www.facebook.com/jovenprocolombia"
        },
        {
            label: "WhatsApp",
            href: "https://wa.me/573024840101"
        },
        {
            label: "Telegram",
            href: "https://t.me/jovenpro"
        }
    ],
    copyright: `© ${new Date().getFullYear()} JovenPro. Todos los derechos reservados.`
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/utils/cn.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "cn",
    ()=>cn
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/tailwind-merge/dist/bundle-mjs.mjs [app-client] (ecmascript)");
;
;
function cn(...inputs) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["twMerge"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clsx"])(inputs));
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/utils/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
// src/lib/utils/index.ts
// ============================================
// RE-EXPORTADOR CONVENIENTE — JovenPro V2 SPA
// ============================================
// Centraliza todos los exports públicos de utils y data.
//export * from "./format";
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/data.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils/cn.ts [app-client] (ecmascript)");
;
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/atoms/Container/Container.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Container",
    ()=>Container
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
// ============================================================================
// CONTAINER — Átomo de layout estructural
// ============================================================================
// REFACTOR V3:
// - Zero inline classes: todo el CSS vive en Container.variants.ts.
// - Tipos importados desde .variants.ts (derivados del CVA).
// - Prop "paddingY" default sincronizada con CVA: "none".
// - No se tocan colores aquí; el tema se controla via tokens de Tailwind.
// ============================================================================
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Container$2f$Container$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Container/Container.variants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/utils/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils/cn.ts [app-client] (ecmascript)");
;
;
;
;
const Container = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = ({ size = "lg", padding = "md", paddingY = "none", variant = "transparent", align = "center", minHeight = "none", radius = "none", flex = false, centered = false, as: Component = "div", className, children, ...props }, ref)=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Component, {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Container$2f$Container$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["containerVariants"])({
            size,
            padding,
            paddingY,
            variant,
            align,
            minHeight,
            radius,
            flex,
            centered
        }), className),
        ...props,
        children: children
    }, void 0, false, {
        fileName: "[project]/src/components/atoms/Container/Container.tsx",
        lineNumber: 67,
        columnNumber: 13
    }, ("TURBOPACK compile-time value", void 0));
});
_c1 = Container;
Container.displayName = "Container";
;
var _c, _c1;
__turbopack_context__.k.register(_c, "Container$forwardRef");
__turbopack_context__.k.register(_c1, "Container");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/atoms/Container/ContainerSkeleton.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ContainerSkeleton",
    ()=>ContainerSkeleton
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
// components/atoms/Container/ContainerSkeleton.tsx
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Container$2f$Container$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Container/Container.variants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/utils/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils/cn.ts [app-client] (ecmascript)");
;
;
;
function ContainerSkeleton({ size = "lg", padding = "md", paddingY = "none", variant = "transparent", align = "center", minHeight = "none", radius = "none", flex = false, centered = false, className, children }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Container$2f$Container$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["containerVariants"])({
            size,
            padding,
            paddingY,
            variant,
            align,
            minHeight,
            radius,
            flex,
            centered
        }), "pointer-events-none select-none", className),
        "aria-hidden": "true",
        children: children
    }, void 0, false, {
        fileName: "[project]/src/components/atoms/Container/ContainerSkeleton.tsx",
        lineNumber: 43,
        columnNumber: 9
    }, this);
}
_c = ContainerSkeleton;
var _c;
__turbopack_context__.k.register(_c, "ContainerSkeleton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/atoms/Container/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
// ============================================================================
// CONTAINER SYSTEM — Barrel export
// ============================================================================
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Container$2f$Container$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Container/Container.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Container$2f$Container$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Container/Container.variants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Container$2f$ContainerSkeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Container/ContainerSkeleton.tsx [app-client] (ecmascript)");
;
;
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/atoms/IconButton/IconButton.variants.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "iconButtonIconWrapperVariants",
    ()=>iconButtonIconWrapperVariants,
    "iconButtonLoaderVariants",
    ()=>iconButtonLoaderVariants,
    "iconButtonVariants",
    ()=>iconButtonVariants,
    "notificationDotVariants",
    ()=>notificationDotVariants
]);
// ============================================================================
// ICON BUTTON VARIANTS — Átomo de acción iconográfica
// ============================================================================
// REFACTOR V3:
// - AGREGADA variante "social" para botones de redes sociales.
//   Patrón recurrente: bg-surface text-primary hover:bg-secondary hover:text-white.
//   Antes inline en WorkWithUs.tsx.
// ============================================================================
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/class-variance-authority/dist/index.mjs [app-client] (ecmascript)");
;
const iconButtonVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("inline-flex items-center justify-center shrink-0 transition-all duration-300 focus:outline-none disabled:opacity-50 disabled:cursor-not-allowed", {
    variants: {
        variant: {
            default: [
                "bg-surface text-foreground",
                "shadow-clay hover:shadow-clay-sm active:shadow-clay-active",
                "hover:text-primary",
                "rounded-clay"
            ],
            primary: [
                "bg-primary text-white",
                "shadow-clay hover:shadow-clay-sm active:shadow-clay-active",
                "hover:brightness-110",
                "rounded-clay"
            ],
            secondary: [
                "bg-secondary text-white",
                "shadow-clay hover:shadow-clay-sm active:shadow-clay-active",
                "rounded-clay"
            ],
            ghost: [
                "bg-transparent text-foreground",
                "shadow-none",
                "hover:bg-surface-container",
                "hover:shadow-clay-sm",
                "rounded-clay"
            ],
            outline: [
                "bg-transparent text-foreground",
                "border-2 border-surface-variant",
                "shadow-none",
                "hover:border-primary hover:text-primary",
                "rounded-clay"
            ],
            circular: [
                "bg-surface text-foreground",
                "shadow-clay hover:shadow-clay-sm active:shadow-clay-active",
                "hover:text-primary",
                "rounded-full"
            ],
            // AGREGADO V3: Botones de redes sociales
            social: [
                "bg-surface text-primary",
                "shadow-sm hover:shadow-clay-sm",
                "hover:bg-secondary hover:text-white",
                "rounded-full"
            ],
            danger: [
                "bg-danger text-white",
                "shadow-lg shadow-danger/30",
                "hover:shadow-danger/50",
                "hover:scale-105 active:scale-100",
                "rounded-clay"
            ],
            whatsapp: [
                "bg-[#25D366] text-white",
                "shadow-clay hover:shadow-clay-sm active:shadow-clay-active",
                "hover:brightness-110",
                "rounded-clay"
            ],
            success: [
                "bg-success text-white",
                "shadow-clay hover:shadow-clay-sm active:shadow-clay-active",
                "hover:brightness-110",
                "rounded-clay"
            ],
            skeleton: [
                "bg-white/20 backdrop-blur-md border border-white/30",
                "shadow-inner shadow-white/40",
                "animate-pulse cursor-wait",
                "text-transparent select-none"
            ]
        },
        size: {
            xs: "w-8 h-8",
            sm: "w-10 h-10",
            md: "w-12 h-12",
            lg: "w-14 h-14",
            xl: "w-16 h-16"
        },
        isLoading: {
            true: "cursor-wait opacity-80",
            false: ""
        },
        hasNotification: {
            true: "relative",
            false: ""
        }
    },
    defaultVariants: {
        variant: "default",
        size: "md",
        isLoading: false,
        hasNotification: false
    }
});
const notificationDotVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("absolute z-10 rounded-full border-2 border-surface-container animate-pulse", {
    variants: {
        size: {
            xs: "w-2 h-2 top-0 right-0",
            sm: "w-2.5 h-2.5 top-0.5 right-0.5",
            md: "w-3 h-3 top-0.5 right-0.5",
            lg: "w-3 h-3 top-1 right-1",
            xl: "w-3.5 h-3.5 top-1 right-1"
        },
        color: {
            primary: "bg-primary",
            secondary: "bg-secondary",
            danger: "bg-danger",
            success: "bg-success"
        }
    },
    defaultVariants: {
        size: "md",
        color: "secondary"
    }
});
const iconButtonLoaderVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("w-5 h-5 animate-spin");
const iconButtonIconWrapperVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("relative z-10 flex items-center justify-center");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/atoms/IconButton/IconButton.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "IconButton",
    ()=>IconButton
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$slot$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-slot/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/loader-circle.js [app-client] (ecmascript) <export default as Loader2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$IconButton$2f$IconButton$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/IconButton/IconButton.variants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/utils/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils/cn.ts [app-client] (ecmascript)");
// ============================================================================
// ICON BUTTON — Átomo de acción iconográfica
// ============================================================================
// REFACTOR V3:
// - Zero inline classes: loader y wrapper de icono delegados a CVA exportados.
//   Antes: Loader2 tenía "w-5 h-5 animate-spin" inline (línea 79).
//   Antes: span interno tenía "relative z-10 flex items-center justify-center" inline (línea 93).
// - Tipos importados desde .variants.ts (derivados del CVA).
// - Variante "liquidGlass" renombrada a "skeleton" en consumidores externos.
// ============================================================================
"use client";
;
;
;
;
;
;
const IconButton = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = ({ icon, variant = "default", size = "md", "aria-label": ariaLabel, isLoading = false, hasNotification = false, notificationColor = "secondary", tooltip, asChild = false, className, disabled, ...props }, ref)=>{
    const Comp = asChild ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$slot$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Slot"] : "button";
    const isDisabled = disabled || isLoading;
    const renderIcon = ()=>{
        if (isLoading) {
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__["Loader2"], {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$IconButton$2f$IconButton$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["iconButtonLoaderVariants"])())
            }, void 0, false, {
                fileName: "[project]/src/components/atoms/IconButton/IconButton.tsx",
                lineNumber: 81,
                columnNumber: 24
            }, ("TURBOPACK compile-time value", void 0));
        }
        return icon;
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Comp, {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$IconButton$2f$IconButton$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["iconButtonVariants"])({
            variant,
            size,
            isLoading,
            hasNotification
        }), className),
        disabled: isDisabled,
        "aria-label": ariaLabel,
        title: tooltip,
        ...props,
        children: [
            hasNotification && !isLoading && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$IconButton$2f$IconButton$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["notificationDotVariants"])({
                    size,
                    color: notificationColor
                }))
            }, void 0, false, {
                fileName: "[project]/src/components/atoms/IconButton/IconButton.tsx",
                lineNumber: 104,
                columnNumber: 21
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$IconButton$2f$IconButton$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["iconButtonIconWrapperVariants"])()),
                children: renderIcon()
            }, void 0, false, {
                fileName: "[project]/src/components/atoms/IconButton/IconButton.tsx",
                lineNumber: 111,
                columnNumber: 17
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/atoms/IconButton/IconButton.tsx",
        lineNumber: 87,
        columnNumber: 13
    }, ("TURBOPACK compile-time value", void 0));
});
_c1 = IconButton;
IconButton.displayName = "IconButton";
;
var _c, _c1;
__turbopack_context__.k.register(_c, "IconButton$forwardRef");
__turbopack_context__.k.register(_c1, "IconButton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/atoms/IconButton/IconButtonSkeleton.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "IconButtonSkeleton",
    ()=>IconButtonSkeleton
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
// components/atoms/IconButton/IconButtonSkeleton.tsx
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$IconButton$2f$IconButton$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/IconButton/IconButton.variants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/utils/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils/cn.ts [app-client] (ecmascript)");
;
;
;
function IconButtonSkeleton({ variant = "skeleton", size = "md", className }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$IconButton$2f$IconButton$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["iconButtonVariants"])({
            variant,
            size
        }), "skeleton-pulse border-transparent shadow-none text-transparent pointer-events-none select-none", className),
        "aria-hidden": "true"
    }, void 0, false, {
        fileName: "[project]/src/components/atoms/IconButton/IconButtonSkeleton.tsx",
        lineNumber: 27,
        columnNumber: 5
    }, this);
}
_c = IconButtonSkeleton;
var _c;
__turbopack_context__.k.register(_c, "IconButtonSkeleton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/atoms/IconButton/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
// ============================================================================
// ICON BUTTON SYSTEM — Barrel export
// ============================================================================
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$IconButton$2f$IconButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/IconButton/IconButton.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$IconButton$2f$IconButton$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/IconButton/IconButton.variants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$IconButton$2f$IconButtonSkeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/IconButton/IconButtonSkeleton.tsx [app-client] (ecmascript)");
;
;
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/atoms/Button/Button.variants.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "buttonIconVariants",
    ()=>buttonIconVariants,
    "buttonLoaderVariants",
    ()=>buttonLoaderVariants,
    "buttonVariants",
    ()=>buttonVariants
]);
// ============================================================================
// BUTTON VARIANTS — Átomo de acción principal
// ============================================================================
// REFACTOR V3:
// - Agregado "group" al base para soportar group-hover en icono derecho.
// - Eliminada variante "icon" y tamaños "icon"/"iconLg": IconButton es átomo
//   separado.
// - "liquidGlass" renombrado a "skeleton" y "glass".
// - "success" migrado a tokens semánticos V3.
// - "secondary" usa bg-surface.
// - translate arbitrario [2px] reemplazado por -translate-y-0.5.
// - Nuevos CVA: buttonLoaderVariants, buttonIconVariants.
// - AGREGADO variant "outline" para CTAs secundarios con borde.
// ============================================================================
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/class-variance-authority/dist/index.mjs [app-client] (ecmascript)");
;
const buttonVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("inline-flex items-center justify-center gap-2 font-bold transition-all duration-300 focus:outline-none disabled:opacity-50 disabled:cursor-not-allowed group", {
    variants: {
        variant: {
            primary: [
                "bg-primary text-white",
                "shadow-clay hover:shadow-clay-sm active:shadow-clay-active",
                "hover:-translate-y-0.5 active:translate-y-0"
            ],
            secondary: [
                "bg-surface text-foreground",
                "shadow-clay hover:shadow-clay-active",
                "border border-transparent"
            ],
            ghost: [
                "bg-transparent text-foreground",
                "hover:bg-surface/50",
                "shadow-none"
            ],
            outline: [
                "bg-transparent text-foreground",
                "border-2 border-foreground/20",
                "hover:bg-foreground hover:text-background",
                "shadow-none"
            ],
            success: [
                "bg-success-subtle text-success",
                "shadow-none"
            ],
            glass: [
                "bg-white/40 backdrop-blur-xl border border-white/50 text-secondary",
                "shadow-lg shadow-black/5"
            ],
            skeleton: [
                "bg-white/20 backdrop-blur-md border border-white/30",
                "shadow-inner shadow-white/40",
                "animate-pulse cursor-wait",
                "text-transparent select-none"
            ]
        },
        size: {
            sm: "h-10 px-4 text-sm rounded-clay",
            md: "h-12 px-6 text-base rounded-clay",
            lg: "h-16 px-10 text-lg rounded-clay"
        },
        isLoading: {
            true: "cursor-wait opacity-80",
            false: ""
        },
        isFullWidth: {
            true: "w-full",
            false: ""
        }
    },
    defaultVariants: {
        variant: "primary",
        size: "md",
        isLoading: false,
        isFullWidth: false
    }
});
const buttonLoaderVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("w-5 h-5 animate-spin shrink-0");
const buttonIconVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("shrink-0", {
    variants: {
        position: {
            left: "",
            right: "group-hover:translate-x-1 transition-transform"
        }
    },
    defaultVariants: {
        position: "left"
    }
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/atoms/Button/Button.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Button",
    ()=>Button
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
// ============================================================================
// BUTTON — Átomo de acción principal
// ============================================================================
// REFACTOR V3:
// - Zero inline classes: loader e iconos delegados a buttonLoaderVariants y
//   buttonIconVariants respectivamente.
// - Eliminada variante "icon" y tamaños "icon"/"iconLg": IconButton es átomo
//   separado. Cualquier uso previo de <Button variant="icon"> debe migrarse
//   al componente IconButton.
// - "group" ahora vive en el CVA base de .variants.ts, no como clase inline.
// - Tipos ButtonVariant y ButtonSize importados desde .variants.ts en lugar
//   de re-declararse (evita desincronización con el CVA).
// ============================================================================
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$slot$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-slot/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/loader-circle.js [app-client] (ecmascript) <export default as Loader2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Button$2f$Button$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Button/Button.variants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/utils/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils/cn.ts [app-client] (ecmascript)");
;
;
;
;
;
;
const Button = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].forwardRef(_c = ({ className, variant = "primary", size = "md", isLoading = false, isFullWidth = false, children, icon, iconPosition = "right", asChild = false, disabled, ...props }, ref)=>{
    const Comp = asChild ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$slot$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Slot"] : "button";
    const isDisabled = disabled || isLoading;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Comp, {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Button$2f$Button$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buttonVariants"])({
            variant,
            size,
            isLoading,
            isFullWidth
        }), className),
        ref: ref,
        disabled: isDisabled,
        ...props,
        children: asChild ? children : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                isLoading && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__["Loader2"], {
                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Button$2f$Button$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buttonLoaderVariants"])())
                }, void 0, false, {
                    fileName: "[project]/src/components/atoms/Button/Button.tsx",
                    lineNumber: 91,
                    columnNumber: 39
                }, ("TURBOPACK compile-time value", void 0)),
                !isLoading && icon && iconPosition === "left" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Button$2f$Button$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buttonIconVariants"])({
                        position: "left"
                    })),
                    children: icon
                }, void 0, false, {
                    fileName: "[project]/src/components/atoms/Button/Button.tsx",
                    lineNumber: 95,
                    columnNumber: 29
                }, ("TURBOPACK compile-time value", void 0)),
                children,
                !isLoading && icon && iconPosition === "right" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Button$2f$Button$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buttonIconVariants"])({
                        position: "right"
                    })),
                    children: icon
                }, void 0, false, {
                    fileName: "[project]/src/components/atoms/Button/Button.tsx",
                    lineNumber: 105,
                    columnNumber: 29
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true)
    }, void 0, false, {
        fileName: "[project]/src/components/atoms/Button/Button.tsx",
        lineNumber: 71,
        columnNumber: 13
    }, ("TURBOPACK compile-time value", void 0));
});
_c1 = Button;
Button.displayName = "Button";
;
var _c, _c1;
__turbopack_context__.k.register(_c, "Button$React.forwardRef");
__turbopack_context__.k.register(_c1, "Button");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/atoms/Button/ButtonSkeleton.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ButtonSkeleton",
    ()=>ButtonSkeleton
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
// components/atoms/Button/ButtonSkeleton.tsx
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Button$2f$Button$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Button/Button.variants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/utils/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils/cn.ts [app-client] (ecmascript)");
;
;
;
function ButtonSkeleton({ variant = "skeleton", size = "md", isFullWidth = false, className }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Button$2f$Button$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buttonVariants"])({
            variant,
            size,
            isFullWidth
        }), "skeleton-pulse border-transparent shadow-none text-transparent pointer-events-none select-none", className),
        "aria-hidden": "true"
    }, void 0, false, {
        fileName: "[project]/src/components/atoms/Button/ButtonSkeleton.tsx",
        lineNumber: 31,
        columnNumber: 5
    }, this);
}
_c = ButtonSkeleton;
var _c;
__turbopack_context__.k.register(_c, "ButtonSkeleton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/atoms/Button/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
// ============================================================================
// BUTTON SYSTEM — Barrel export
// ============================================================================
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Button$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Button/Button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Button$2f$Button$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Button/Button.variants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Button$2f$ButtonSkeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Button/ButtonSkeleton.tsx [app-client] (ecmascript)");
;
;
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/atoms/Input/Input.variants.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getIconPadding",
    ()=>getIconPadding,
    "inputIconLeftVariants",
    ()=>inputIconLeftVariants,
    "inputIconRightVariants",
    ()=>inputIconRightVariants,
    "inputLoaderVariants",
    ()=>inputLoaderVariants,
    "inputVariants",
    ()=>inputVariants,
    "inputWrapperVariants",
    ()=>inputWrapperVariants
]);
// ============================================================================
// INPUT VARIANTS — Átomo de captura de datos
// ============================================================================
// REFACTOR V3:
// - Tokens fantasmas eliminados:
//   • "text-on-surface" → "text-foreground"
//   • "text-on-surface-variant" → "text-muted"
//   • "placeholder:text-on-surface-variant/50" → "placeholder:text-muted"
// - Colores hardcodeados migrados a tokens semánticos:
//   • error: bg-red-50 → bg-danger-subtle, border-red-400 → border-danger,
//     text-red-900 → text-foreground, placeholder:red-400 → placeholder:muted
//   • success: bg-green-50 → bg-success-subtle, border-green-400 → border-success,
//     text-green-900 → text-foreground, placeholder:green-400 → placeholder:muted
// - liquidGlass renombrado a "skeleton" (consistencia V3).
// - Variantes "hasIcon" e "iconPosition" eliminadas: eran dead code (todas "").
//   El Debt Log las señala como no-op semántico.
// - Variantes "error" y "success" eliminadas de dimensión "state": se manejan
//   por dimensión "variant". "state" ahora solo cubre funcional (disabled, loading).
// - inputWrapperVariants: "group" agregado al base, variantes vacías eliminadas.
// - Nuevos CVA exportados:
//   • inputIconLeftVariants: elimina inline del .tsx
//   • inputIconRightVariants: elimina inline del .tsx
//   • inputLoaderVariants: elimina inline "w-5 h-5 animate-spin"
// - getIconPadding: tipado con InputSize en lugar de string genérico.
// - Tipos derivados del CVA.
// ============================================================================
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/class-variance-authority/dist/index.mjs [app-client] (ecmascript)");
;
const inputVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("w-full bg-transparent outline-none transition-all placeholder:text-muted-light", {
    variants: {
        variant: {
            default: [
                "bg-surface",
                "shadow-clay-active",
                "rounded-clay",
                "border border-transparent",
                "focus:border-primary",
                "text-foreground"
            ],
            filled: [
                "bg-surface-container",
                "shadow-inner",
                "rounded-clay",
                "border border-transparent",
                "focus:border-primary",
                "text-foreground"
            ],
            outline: [
                "bg-transparent",
                "shadow-none",
                "rounded-clay",
                "border-2 border-surface-variant",
                "focus:border-primary",
                "text-foreground"
            ],
            ghost: [
                "bg-transparent",
                "shadow-none",
                "rounded-none",
                "border-b-2 border-surface-variant",
                "focus:border-primary",
                "text-foreground",
                "px-0"
            ],
            search: [
                "bg-surface-container",
                "shadow-clay-active",
                "rounded-clay",
                "border border-transparent",
                "focus:border-primary",
                "text-foreground",
                "placeholder:text-sm"
            ],
            error: [
                "bg-danger-subtle",
                "shadow-clay-active",
                "rounded-clay",
                "border border-danger",
                "focus:border-danger",
                "text-foreground",
                "placeholder:text-muted"
            ],
            success: [
                "bg-success-subtle",
                "shadow-clay-active",
                "rounded-clay",
                "border border-success",
                "focus:border-success",
                "text-foreground",
                "placeholder:text-muted"
            ],
            skeleton: [
                "bg-white/20 backdrop-blur-md border border-white/30",
                "shadow-inner shadow-white/40",
                "animate-pulse cursor-wait",
                "text-transparent select-none"
            ]
        },
        size: {
            sm: "h-10 px-3 text-sm",
            md: "h-12 px-4 text-base",
            lg: "h-14 px-6 text-lg"
        },
        state: {
            default: "",
            disabled: "opacity-50 cursor-not-allowed",
            loading: "opacity-80 cursor-wait"
        }
    },
    defaultVariants: {
        variant: "default",
        size: "md",
        state: "default"
    }
});
const inputWrapperVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("relative flex items-center w-full transition-all group", {
    variants: {
        size: {
            sm: "h-10",
            md: "h-12",
            lg: "h-14"
        },
        fullWidth: {
            true: "w-full",
            false: "w-auto"
        }
    },
    defaultVariants: {
        size: "md",
        fullWidth: true
    }
});
const inputIconLeftVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("absolute left-4 top-1/2 -translate-y-1/2 text-secondary transition-colors group-focus-within:text-primary");
const inputIconRightVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("absolute right-4 top-1/2 -translate-y-1/2 text-secondary flex items-center justify-center");
const inputLoaderVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("w-5 h-5 animate-spin");
const getIconPadding = (size, position)=>{
    if (!size) return "";
    const paddingMap = {
        sm: {
            left: "pl-10",
            right: "pr-10"
        },
        md: {
            left: "pl-12",
            right: "pr-12"
        },
        lg: {
            left: "pl-14",
            right: "pr-14"
        }
    };
    return paddingMap[size]?.[position] || "";
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/atoms/Input/Input.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Input",
    ()=>Input
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
// ============================================================================
// INPUT — Átomo de captura de datos
// ============================================================================
// REFACTOR V3:
// - Zero inline classes:
//   • "group" eliminado del wrapper → vive en inputWrapperVariants base.
//   • Icono izquierdo: delegado a inputIconLeftVariants.
//   • Loader2: delegado a inputLoaderVariants.
//   • Icono derecho: delegado a inputIconRightVariants.
// - Tipos importados desde .variants.ts (derivados del CVA).
// - Variante "liquidGlass" renombrada a "skeleton" en consumidores externos.
// ============================================================================
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/loader-circle.js [app-client] (ecmascript) <export default as Loader2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Input$2f$Input$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Input/Input.variants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/utils/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils/cn.ts [app-client] (ecmascript)");
;
;
;
;
;
const Input = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = ({ className, variant = "default", size = "md", state = "default", leftIcon, rightIcon, isLoading = false, type = "text", disabled, value, onChange, ...props }, ref)=>{
    const functionalState = disabled ? "disabled" : isLoading ? "loading" : state || "default";
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Input$2f$Input$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["inputWrapperVariants"])({
            size,
            fullWidth: true
        }), className),
        children: [
            leftIcon && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Input$2f$Input$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["inputIconLeftVariants"])()),
                children: isLoading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__["Loader2"], {
                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Input$2f$Input$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["inputLoaderVariants"])())
                }, void 0, false, {
                    fileName: "[project]/src/components/atoms/Input/Input.tsx",
                    lineNumber: 80,
                    columnNumber: 29
                }, ("TURBOPACK compile-time value", void 0)) : leftIcon
            }, void 0, false, {
                fileName: "[project]/src/components/atoms/Input/Input.tsx",
                lineNumber: 78,
                columnNumber: 21
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                ref: ref,
                type: type,
                value: value,
                onChange: onChange,
                disabled: disabled || isLoading,
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Input$2f$Input$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["inputVariants"])({
                    variant: variant,
                    size,
                    state: functionalState
                }), leftIcon && (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Input$2f$Input$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getIconPadding"])(size, "left"), rightIcon && (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Input$2f$Input$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getIconPadding"])(size, "right")),
                ...props
            }, void 0, false, {
                fileName: "[project]/src/components/atoms/Input/Input.tsx",
                lineNumber: 87,
                columnNumber: 17
            }, ("TURBOPACK compile-time value", void 0)),
            rightIcon && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Input$2f$Input$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["inputIconRightVariants"])()),
                children: rightIcon
            }, void 0, false, {
                fileName: "[project]/src/components/atoms/Input/Input.tsx",
                lineNumber: 106,
                columnNumber: 21
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/atoms/Input/Input.tsx",
        lineNumber: 68,
        columnNumber: 13
    }, ("TURBOPACK compile-time value", void 0));
});
_c1 = Input;
Input.displayName = "Input";
;
var _c, _c1;
__turbopack_context__.k.register(_c, "Input$forwardRef");
__turbopack_context__.k.register(_c1, "Input");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/atoms/Input/InputSkeleton.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "InputSkeleton",
    ()=>InputSkeleton
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
// components/atoms/Input/InputSkeleton.tsx
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Input$2f$Input$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Input/Input.variants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/utils/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils/cn.ts [app-client] (ecmascript)");
;
;
;
function InputSkeleton({ variant = "skeleton", size = "md", showLabel = false, hasLeftIcon = false, hasRightIcon = false, className }) {
    // Mapa de alturas según size para el bloque interno
    const heightMap = {
        sm: "h-5",
        md: "h-6",
        lg: "h-7"
    };
    const iconSizeMap = {
        sm: "w-4 h-4",
        md: "w-5 h-5",
        lg: "w-5 h-5"
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("w-full space-y-2", className),
        "aria-hidden": "true",
        children: [
            showLabel && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "h-3 w-24 rounded-sm skeleton-block animate-pulse"
            }, void 0, false, {
                fileName: "[project]/src/components/atoms/Input/InputSkeleton.tsx",
                lineNumber: 46,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Input$2f$Input$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["inputWrapperVariants"])({
                    size,
                    fullWidth: true
                }), "relative flex items-center skeleton-pulse/40 border-transparent"),
                children: [
                    hasLeftIcon && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("absolute left-4 top-1/2 -translate-y-1/2 rounded-full skeleton-block", iconSizeMap[size] || "w-5 h-5")
                    }, void 0, false, {
                        fileName: "[project]/src/components/atoms/Input/InputSkeleton.tsx",
                        lineNumber: 58,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Input$2f$Input$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["inputVariants"])({
                            variant,
                            size,
                            state: "default"
                        }), "bg-transparent border-transparent shadow-none pointer-events-none select-none", hasLeftIcon && (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Input$2f$Input$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getIconPadding"])(size, "left"), hasRightIcon && (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Input$2f$Input$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getIconPadding"])(size, "right")),
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("w-full rounded-sm bg-muted", heightMap[size] || "h-6")
                        }, void 0, false, {
                            fileName: "[project]/src/components/atoms/Input/InputSkeleton.tsx",
                            lineNumber: 77,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/atoms/Input/InputSkeleton.tsx",
                        lineNumber: 65,
                        columnNumber: 9
                    }, this),
                    hasRightIcon && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("absolute right-4 top-1/2 -translate-y-1/2 rounded-full bg-muted", iconSizeMap[size] || "w-5 h-5")
                    }, void 0, false, {
                        fileName: "[project]/src/components/atoms/Input/InputSkeleton.tsx",
                        lineNumber: 82,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/atoms/Input/InputSkeleton.tsx",
                lineNumber: 50,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/atoms/Input/InputSkeleton.tsx",
        lineNumber: 43,
        columnNumber: 5
    }, this);
}
_c = InputSkeleton;
var _c;
__turbopack_context__.k.register(_c, "InputSkeleton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/atoms/Input/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
// ============================================================================
// INPUT SYSTEM — Barrel export
// ============================================================================
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Input$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Input/Input.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Input$2f$Input$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Input/Input.variants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Input$2f$InputSkeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Input/InputSkeleton.tsx [app-client] (ecmascript)");
;
;
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/atoms/Typography/Typography.variants.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "gradientTextVariants",
    ()=>gradientTextVariants,
    "headingVariants",
    ()=>headingVariants,
    "textVariants",
    ()=>textVariants
]);
// ============================================================================
// TYPOGRAPHY VARIANTS — Átomos de texto (Heading, Text, GradientText)
// ============================================================================
// REFACTOR V3:
// - Tokens fantasmas eliminados:
//   • "text-on-surface-variant" → "text-muted"
//   • "text-on-surface-variant/60" → "text-muted"
//   • "text-foreground/60" (label) → "text-muted"
//   • "text-foreground/50" (muted) → "text-muted"
// - Colores hardcodeados migrados a tokens semánticos:
//   • "text-green-600" (success) → "text-success"
//   • "text-red-500" (error) → "text-danger"
//   • "text-amber-600" (warning) → "text-warning"
// - liquidGlass renombrado a "skeleton" (consistencia V3).
// - Nuevo CVA: gradientTextVariants. Elimina construcción de strings CSS
//   dinámicos en GradientText.tsx (bg-gradient-${direction} ${colors.join}).
//   Tailwind JIT no puede purgar strings dinámicos; esto era deuda crítica.
// - Tipos derivados del CVA. Excepción: LineClamp mantiene type manual
//   porque CVA no preserva tipos numéricos en keys de objeto (se convierten
//   a string en TypeScript).
// ============================================================================
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/class-variance-authority/dist/index.mjs [app-client] (ecmascript)");
;
const headingVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("font-black tracking-tight leading-none", {
    variants: {
        level: {
            h1: "text-5xl lg:text-7xl xl:text-8xl",
            h2: "text-4xl lg:text-6xl xl:text-7xl",
            h3: "text-3xl lg:text-4xl xl:text-5xl",
            h4: "text-2xl lg:text-3xl",
            h5: "text-xl lg:text-2xl font-bold",
            h6: "text-lg lg:text-xl font-bold"
        },
        variant: {
            default: "text-foreground",
            primary: "text-primary",
            secondary: "text-secondary",
            gradient: "bg-gradient-to-r from-primary-dim to-primary bg-clip-text text-transparent",
            muted: "text-muted-foreground",
            inverted: "text-white",
            skeleton: "bg-white/20 backdrop-blur-md border border-white/30 shadow-inner shadow-white/40 animate-pulse cursor-wait text-transparent select-none"
        },
        italic: {
            true: "italic",
            false: ""
        },
        tracking: {
            tighter: "tracking-tighter",
            tight: "tracking-tight",
            normal: "tracking-normal",
            wide: "tracking-wide",
            wider: "tracking-wider",
            widest: "tracking-widest"
        },
        transform: {
            uppercase: "uppercase",
            lowercase: "lowercase",
            capitalize: "capitalize",
            normal: "normal-case"
        }
    },
    defaultVariants: {
        level: "h2",
        variant: "default",
        italic: false,
        tracking: "tighter",
        transform: "normal"
    }
});
const textVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("leading-relaxed", {
    variants: {
        size: {
            xs: "text-[10px] leading-tight",
            sm: "text-xs",
            md: "text-sm",
            base: "text-base",
            lg: "text-lg",
            xl: "text-xl",
            "2xl": "text-2xl"
        },
        variant: {
            default: "text-foreground font-medium",
            body: "text-muted font-body",
            lead: "text-muted-foreground text-xl lg:text-2xl font-medium",
            caption: "text-muted text-xs",
            overline: "text-primary text-[10px] font-black uppercase tracking-[0.3em]",
            label: "text-muted text-xs font-black uppercase tracking-[0.2em]",
            muted: "text-muted-foreground",
            inverted: "text-white/80",
            link: "text-primary hover:text-primary-dim underline-offset-4 hover:underline cursor-pointer",
            success: "text-success font-medium",
            error: "text-danger font-medium",
            warning: "text-warning font-medium",
            skeleton: "bg-white/20 backdrop-blur-md border border-white/30 shadow-inner shadow-white/40 animate-pulse cursor-wait text-transparent select-none"
        },
        weight: {
            light: "font-light",
            normal: "font-normal",
            medium: "font-medium",
            semibold: "font-semibold",
            bold: "font-bold",
            black: "font-black"
        },
        align: {
            left: "text-left",
            center: "text-center",
            right: "text-right"
        },
        transform: {
            uppercase: "uppercase",
            lowercase: "lowercase",
            capitalize: "capitalize",
            normal: "normal-case"
        },
        truncate: {
            true: "truncate",
            false: ""
        },
        lineClamp: {
            none: "",
            1: "line-clamp-1",
            2: "line-clamp-2",
            3: "line-clamp-3",
            4: "line-clamp-4"
        }
    },
    defaultVariants: {
        size: "base",
        variant: "default",
        weight: "medium",
        align: "left",
        transform: "normal",
        truncate: false,
        lineClamp: "none"
    }
});
const gradientTextVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("bg-clip-text text-transparent", {
    variants: {
        direction: {
            "to-r": "bg-gradient-to-r",
            "to-l": "bg-gradient-to-l",
            "to-t": "bg-gradient-to-t",
            "to-b": "bg-gradient-to-b",
            "to-tr": "bg-gradient-to-tr",
            "to-tl": "bg-gradient-to-tl",
            "to-br": "bg-gradient-to-br",
            "to-bl": "bg-gradient-to-bl"
        },
        from: {
            primary: "from-primary",
            "primary-dim": "from-primary-dim",
            secondary: "from-secondary",
            accent: "from-accent"
        },
        to: {
            primary: "to-primary",
            secondary: "to-secondary",
            "secondary-light": "to-secondary-light",
            accent: "to-accent"
        }
    },
    defaultVariants: {
        direction: "to-r",
        from: "primary-dim",
        to: "primary"
    }
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/atoms/Typography/Heading.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Heading",
    ()=>Heading
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
// ============================================================================
// HEADING — Átomo de título semántico
// ============================================================================
// REFACTOR V3:
// - Eliminado span wrapper redundante para variant="gradient".
//   El CVA headingVariants ya incluye bg-clip-text text-transparent en la
//   variante gradient. El span interno duplicaba estas clases y carecía de
//   background-image propio, lo que podía renderizar texto invisible.
// - Tipos importados desde .variants.ts (derivados del CVA).
// - Zero inline classes.
// ============================================================================
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Typography$2f$Typography$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Typography/Typography.variants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/utils/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils/cn.ts [app-client] (ecmascript)");
;
;
;
;
const Heading = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = ({ level = "h2", variant = "default", italic = false, tracking = "tighter", transform = "normal", as, className, children, ...props }, ref)=>{
    const Component = as || level;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Component, {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Typography$2f$Typography$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["headingVariants"])({
            level,
            variant,
            italic,
            tracking,
            transform
        }), className),
        ...props,
        children: children
    }, void 0, false, {
        fileName: "[project]/src/components/atoms/Typography/Heading.tsx",
        lineNumber: 57,
        columnNumber: 13
    }, ("TURBOPACK compile-time value", void 0));
});
_c1 = Heading;
Heading.displayName = "Heading";
;
var _c, _c1;
__turbopack_context__.k.register(_c, "Heading$forwardRef");
__turbopack_context__.k.register(_c1, "Heading");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/atoms/Typography/Text.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Text",
    ()=>Text
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
// ============================================================================
// TEXT — Átomo de cuerpo tipográfico
// ============================================================================
// REFACTOR V3:
// - Tipos importados desde .variants.ts (derivados del CVA).
//   FontWeight renombrado a TextWeight para evitar colisión con tipos globales.
// - LineClamp mantiene type manual (limitación de CVA con keys numéricas).
// - Zero inline classes.
// ============================================================================
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Typography$2f$Typography$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Typography/Typography.variants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/utils/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils/cn.ts [app-client] (ecmascript)");
;
;
;
;
const Text = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = ({ size = "base", variant = "default", weight = "medium", align = "left", transform = "normal", truncate = false, lineClamp = "none", as = "p", className, children, ...props }, ref)=>{
    const Component = as;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Component, {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Typography$2f$Typography$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["textVariants"])({
            size,
            variant,
            weight,
            align,
            transform,
            truncate,
            lineClamp
        }), className),
        ...props,
        children: children
    }, void 0, false, {
        fileName: "[project]/src/components/atoms/Typography/Text.tsx",
        lineNumber: 62,
        columnNumber: 13
    }, ("TURBOPACK compile-time value", void 0));
});
_c1 = Text;
Text.displayName = "Text";
;
var _c, _c1;
__turbopack_context__.k.register(_c, "Text$forwardRef");
__turbopack_context__.k.register(_c1, "Text");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/atoms/Typography/GradientText.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// ============================================================================
// GRADIENT TEXT — Átomo de texto con gradiente
// ============================================================================
// REFACTOR V3:
// - Eliminada construcción de strings CSS dinámicos:
//   ANTES: `bg-gradient-${direction} ${colors.join(" ")} bg-clip-text text-transparent`
//   AHORA: gradientTextVariants con direcciones y colores predefinidos como
//   variantes CVA. Tailwind JIT puede purgar clases estáticas; no strings.
// - Props `colors` (string[]) eliminadas. Reemplazadas por `from` y `to`
//   con valores tipados de la paleta V3.
// - Tipos importados desde Typography.variants.ts.
// - Zero inline classes.
// ============================================================================
__turbopack_context__.s([
    "GradientText",
    ()=>GradientText
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Typography$2f$Typography$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Typography/Typography.variants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/utils/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils/cn.ts [app-client] (ecmascript)");
;
;
;
const GradientText = ({ children, direction = "to-r", from = "primary-dim", to = "primary", className, as: Component = "span" })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Component, {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Typography$2f$Typography$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["gradientTextVariants"])({
            direction,
            from,
            to
        }), className),
        children: children
    }, void 0, false, {
        fileName: "[project]/src/components/atoms/Typography/GradientText.tsx",
        lineNumber: 47,
        columnNumber: 9
    }, ("TURBOPACK compile-time value", void 0));
};
_c = GradientText;
;
var _c;
__turbopack_context__.k.register(_c, "GradientText");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/atoms/Typography/HeadingSkeleton.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "HeadingSkeleton",
    ()=>HeadingSkeleton
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
// components/atoms/Typography/HeadingSkeleton.tsx
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Typography$2f$Typography$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Typography/Typography.variants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/utils/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils/cn.ts [app-client] (ecmascript)");
;
;
;
function HeadingSkeleton({ level = "h2", variant = "skeleton", italic = false, tracking = "tighter", transform = "normal", className, width, height }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        style: {
            width,
            height
        },
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Typography$2f$Typography$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["headingVariants"])({
            level,
            variant,
            italic,
            tracking,
            transform
        }), "skeleton-pulse rounded-sm pointer-events-none select-none text-transparent w-3/4", className),
        "aria-hidden": "true"
    }, void 0, false, {
        fileName: "[project]/src/components/atoms/Typography/HeadingSkeleton.tsx",
        lineNumber: 28,
        columnNumber: 9
    }, this);
}
_c = HeadingSkeleton;
var _c;
__turbopack_context__.k.register(_c, "HeadingSkeleton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/atoms/Typography/TextSkeleton.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TextSkeleton",
    ()=>TextSkeleton
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
// components/atoms/Typography/TextSkeleton.tsx
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Typography$2f$Typography$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Typography/Typography.variants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/utils/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils/cn.ts [app-client] (ecmascript)");
;
;
;
function TextSkeleton({ size = "base", variant = "default", weight = "medium", align = "left", transform = "normal", className, lines = 1, width, height }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        style: {
            width,
            height
        },
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Typography$2f$Typography$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["textVariants"])({
            size,
            variant,
            weight,
            align,
            transform,
            truncate: false,
            lineClamp: "none"
        }), "pointer-events-none select-none flex flex-col gap-2", className),
        "aria-hidden": "true",
        children: Array.from({
            length: lines
        }).map((_, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("block skeleton-pulse rounded-sm text-transparent h-4", i === lines - 1 && lines > 1 ? "w-3/4" : "w-full")
            }, i, false, {
                fileName: "[project]/src/components/atoms/Typography/TextSkeleton.tsx",
                lineNumber: 48,
                columnNumber: 17
            }, this))
    }, void 0, false, {
        fileName: "[project]/src/components/atoms/Typography/TextSkeleton.tsx",
        lineNumber: 30,
        columnNumber: 9
    }, this);
}
_c = TextSkeleton;
var _c;
__turbopack_context__.k.register(_c, "TextSkeleton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/atoms/Typography/GradientTextSkeleton.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GradientTextSkeleton",
    ()=>GradientTextSkeleton
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
// components/atoms/Typography/GradientTextSkeleton.tsx
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/utils/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils/cn.ts [app-client] (ecmascript)");
;
;
function GradientTextSkeleton({ className }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("block skeleton-pulse rounded-sm pointer-events-none select-none text-transparent w-3/4 h-4", className),
        "aria-hidden": "true"
    }, void 0, false, {
        fileName: "[project]/src/components/atoms/Typography/GradientTextSkeleton.tsx",
        lineNumber: 13,
        columnNumber: 9
    }, this);
}
_c = GradientTextSkeleton;
var _c;
__turbopack_context__.k.register(_c, "GradientTextSkeleton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/atoms/Typography/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
// ============================================================================
// TYPOGRAPHY SYSTEM — Barrel export
// ============================================================================
// Componentes
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Typography$2f$Heading$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Typography/Heading.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Typography$2f$Text$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Typography/Text.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Typography$2f$GradientText$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Typography/GradientText.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Typography$2f$HeadingSkeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Typography/HeadingSkeleton.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Typography$2f$TextSkeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Typography/TextSkeleton.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Typography$2f$GradientTextSkeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Typography/GradientTextSkeleton.tsx [app-client] (ecmascript)");
// Variantes y tipos de diseño (para uso avanzado)
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Typography$2f$Typography$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Typography/Typography.variants.ts [app-client] (ecmascript)");
;
;
;
;
;
;
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/molecules/SearchBar/SearchBar.variants.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "searchBarArrowIconVariants",
    ()=>searchBarArrowIconVariants,
    "searchBarClearButtonVariants",
    ()=>searchBarClearButtonVariants,
    "searchBarClearIconVariants",
    ()=>searchBarClearIconVariants,
    "searchBarEmptyStateVariants",
    ()=>searchBarEmptyStateVariants,
    "searchBarEmptyTextVariants",
    ()=>searchBarEmptyTextVariants,
    "searchBarInputIconVariants",
    ()=>searchBarInputIconVariants,
    "searchBarInputWrapperVariants",
    ()=>searchBarInputWrapperVariants,
    "searchBarOverlayVariants",
    ()=>searchBarOverlayVariants,
    "searchBarSuggestionContentVariants",
    ()=>searchBarSuggestionContentVariants,
    "searchBarSuggestionIconVariants",
    ()=>searchBarSuggestionIconVariants,
    "searchBarVariants",
    ()=>searchBarVariants,
    "suggestionItemVariants",
    ()=>suggestionItemVariants,
    "suggestionsVariants",
    ()=>suggestionsVariants
]);
// ============================================================================
// SEARCH BAR VARIANTS — Molécula de búsqueda con autocomplete
// ============================================================================
// REFACTOR V3:
// - Colores hardcodeados migrados a tokens de capa:
//   • "bg-white" → "bg-container-low" (capa 3, #FFFFFF)
//   • "border-black/5" → "border-border/10" (coherente con sistema de bordes)
//   • "rounded-2xl" → "rounded-clay" (1rem, equivalente en Tailwind default)
// - EXCEPCIÓN DOCUMENTADA: hover:bg-primary/5 y bg-primary/10 se mantienen.
//   Son estados de interacción suave (hover/highlight) sobre fondo blanco.
//   Reemplazarlos por tokens sólidos (primary-subtle #E0F2FE) cambiaría
//   drásticamente la apariencia. La opacidad sobre primary es el patrón
//   estándar para estados de foco sutiles.
// - Nuevos CVA exportados para eliminar inline del .tsx:
//   • searchBarInputWrapperVariants
//   • searchBarInputIconVariants, searchBarClearIconVariants
//   • searchBarClearButtonVariants: opacity del botón limpiar
//   • searchBarSuggestionContentVariants: flex layout de cada item
//   • searchBarSuggestionIconVariants: icono ShoppingBag
//   • searchBarArrowIconVariants: icono ArrowRight highlighted
//   • searchBarEmptyStateVariants: wrapper del estado vacío
//   • searchBarEmptyTextVariants: estilo italic del mensaje
//   • searchBarOverlayVariants: overlay fixed para cerrar al click fuera
// - Tipos derivados del CVA.
// ============================================================================
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/class-variance-authority/dist/index.mjs [app-client] (ecmascript)");
;
const searchBarVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("relative w-full", {
    variants: {
        size: {
            sm: "max-w-[300px]",
            md: "max-w-[400px]",
            lg: "max-w-[600px]",
            full: "max-w-none"
        },
        isOpen: {
            true: "",
            false: ""
        }
    },
    defaultVariants: {
        size: "md",
        isOpen: false
    }
});
const suggestionsVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("absolute top-full left-0 right-0 mt-3 bg-container-low shadow-2xl rounded-clay overflow-hidden border border-border/10 z-[60]", {
    variants: {
        variant: {
            default: "bg-container-low",
            clay: "bg-surface shadow-clay-lg rounded-clay border-surface-variant"
        },
        animation: {
            fade: "animate-in fade-in slide-in-from-top-2 duration-200",
            none: ""
        }
    },
    defaultVariants: {
        variant: "clay",
        animation: "fade"
    }
});
const suggestionItemVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("flex items-center justify-between p-4 transition-colors cursor-pointer", {
    variants: {
        variant: {
            default: "hover:bg-primary/5",
            clay: "hover:bg-surface-container rounded-xl mx-2 my-1"
        },
        isHighlighted: {
            true: "bg-primary/10",
            false: ""
        }
    },
    defaultVariants: {
        variant: "clay",
        isHighlighted: false
    }
});
const searchBarInputWrapperVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("relative");
const searchBarInputIconVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("w-5 h-5");
const searchBarClearIconVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("w-4 h-4");
const searchBarClearButtonVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("opacity-50 hover:opacity-100");
const searchBarSuggestionContentVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("flex items-center gap-4");
const searchBarSuggestionIconVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("w-5 h-5 text-primary");
const searchBarArrowIconVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("w-4 h-4 text-primary opacity-60");
const searchBarEmptyStateVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("p-4");
const searchBarEmptyTextVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("italic");
const searchBarOverlayVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("fixed inset-0 z-50 pointer-events-none");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/molecules/SearchBar/SearchBar.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SearchBar",
    ()=>SearchBar
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/search.js [app-client] (ecmascript) <export default as Search>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/x.js [app-client] (ecmascript) <export default as X>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shopping$2d$bag$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ShoppingBag$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/shopping-bag.js [app-client] (ecmascript) <export default as ShoppingBag>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/arrow-right.js [app-client] (ecmascript) <export default as ArrowRight>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Input$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/components/atoms/Input/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Input$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Input/Input.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$IconButton$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/components/atoms/IconButton/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$IconButton$2f$IconButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/IconButton/IconButton.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Typography$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/components/atoms/Typography/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Typography$2f$Text$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Typography/Text.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$SearchBar$2f$SearchBar$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/molecules/SearchBar/SearchBar.variants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/utils/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils/cn.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
// ============================================================================
// SEARCH BAR — Molécula de búsqueda con autocomplete
// ============================================================================
// REFACTOR V3:
// - Zero inline classes:
//   • "relative" (wrapper Input) → searchBarInputWrapperVariants
//   • "w-5 h-5" (Search) → searchBarInputIconVariants
//   • "w-4 h-4" (X) → searchBarClearIconVariants
//   • "opacity-50 hover:opacity-100" (IconButton) → searchBarClearButtonVariants
//   • "w-full" (Input) → ELIMINADO. Input ya es w-full por defecto (CVA base).
//   • "flex items-center gap-4" (suggestion content) → searchBarSuggestionContentVariants
//   • "w-5 h-5 text-primary" (ShoppingBag) → searchBarSuggestionIconVariants
//   • "line-clamp-1" (Text) → Reemplazado por prop lineClamp={1} del átomo Text
//   • "w-4 h-4 text-primary opacity-60" (ArrowRight) → searchBarArrowIconVariants
//   • "p-4" (empty state) → searchBarEmptyStateVariants
//   • "italic" (empty Text) → searchBarEmptyTextVariants
//   • "fixed inset-0 z-50 pointer-events-none" (overlay) → searchBarOverlayVariants
// - Consumo de átomos validado:
//   • Input: variant="search", leftIcon/rightIcon via props. Correcto.
//   • IconButton: variant="ghost", size="sm". Correcto.
//   • Text: size, weight, variant, transform, lineClamp via props. Correcto.
//   • Badge: No se usa en este componente.
// - Tipos importados desde .variants.ts (derivados del CVA).
// ============================================================================
"use client";
;
;
;
;
;
;
;
const SearchBar = /*#__PURE__*/ _s((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = _s(({ value, onChange, onSelect, onSubmit, onClear, suggestions = [], placeholder = "Buscar...", size = "md", suggestionsVariant = "clay", showCategoryIcon = true, emptyMessage = "No se encontraron resultados...", isLoading = false, disabled = false, className, autoFocus = false, closeOnClickOutside = true, minChars = 1 }, ref)=>{
    _s();
    const [isOpen, setIsOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [highlightedIndex, setHighlightedIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(-1);
    const containerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const inputRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const showSuggestions = isOpen && value.length >= minChars && !disabled;
    const filteredSuggestions = suggestions.filter((s)=>s.label.toLowerCase().includes(value.toLowerCase()));
    const handleInputChange = (e)=>{
        onChange(e.target.value);
        setIsOpen(true);
        setHighlightedIndex(-1);
    };
    const handleClear = ()=>{
        onChange("");
        onClear?.();
        setIsOpen(false);
        setHighlightedIndex(-1);
        inputRef.current?.focus();
    };
    const handleSelect = (suggestion)=>{
        onSelect?.(suggestion);
        if (suggestion.onClick) {
            suggestion.onClick();
        }
        setIsOpen(false);
    };
    const handleKeyDown = (e)=>{
        if (!showSuggestions) return;
        switch(e.key){
            case "ArrowDown":
                e.preventDefault();
                setHighlightedIndex((prev)=>prev < filteredSuggestions.length - 1 ? prev + 1 : prev);
                break;
            case "ArrowUp":
                e.preventDefault();
                setHighlightedIndex((prev)=>prev > 0 ? prev - 1 : -1);
                break;
            case "Enter":
                e.preventDefault();
                if (highlightedIndex >= 0 && filteredSuggestions[highlightedIndex]) {
                    handleSelect(filteredSuggestions[highlightedIndex]);
                } else {
                    onSubmit?.(value);
                    setIsOpen(false);
                }
                break;
            case "Escape":
                setIsOpen(false);
                setHighlightedIndex(-1);
                break;
        }
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SearchBar.useEffect": ()=>{
            if (!closeOnClickOutside) return;
            const handleClickOutside = {
                "SearchBar.useEffect.handleClickOutside": (e)=>{
                    if (containerRef.current && !containerRef.current.contains(e.target)) {
                        setIsOpen(false);
                    }
                }
            }["SearchBar.useEffect.handleClickOutside"];
            document.addEventListener("mousedown", handleClickOutside);
            return ({
                "SearchBar.useEffect": ()=>document.removeEventListener("mousedown", handleClickOutside)
            })["SearchBar.useEffect"];
        }
    }["SearchBar.useEffect"], [
        closeOnClickOutside
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SearchBar.useEffect": ()=>{
            if (autoFocus) {
                inputRef.current?.focus();
            }
        }
    }["SearchBar.useEffect"], [
        autoFocus
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: containerRef,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$SearchBar$2f$SearchBar$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["searchBarVariants"])({
            size,
            isOpen: showSuggestions
        }), className),
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$SearchBar$2f$SearchBar$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["searchBarInputWrapperVariants"])()),
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Input$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Input"], {
                    ref: inputRef,
                    variant: "search",
                    size: "md",
                    leftIcon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__["Search"], {
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$SearchBar$2f$SearchBar$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["searchBarInputIconVariants"])())
                    }, void 0, false, {
                        fileName: "[project]/src/components/molecules/SearchBar/SearchBar.tsx",
                        lineNumber: 205,
                        columnNumber: 29
                    }, ("TURBOPACK compile-time value", void 0)),
                    rightIcon: value ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$IconButton$2f$IconButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IconButton"], {
                        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$SearchBar$2f$SearchBar$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["searchBarClearIconVariants"])())
                        }, void 0, false, {
                            fileName: "[project]/src/components/molecules/SearchBar/SearchBar.tsx",
                            lineNumber: 210,
                            columnNumber: 43
                        }, ("TURBOPACK compile-time value", void 0)),
                        variant: "ghost",
                        size: "sm",
                        "aria-label": "Limpiar búsqueda",
                        onClick: handleClear,
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$SearchBar$2f$SearchBar$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["searchBarClearButtonVariants"])())
                    }, void 0, false, {
                        fileName: "[project]/src/components/molecules/SearchBar/SearchBar.tsx",
                        lineNumber: 209,
                        columnNumber: 33
                    }, ("TURBOPACK compile-time value", void 0)) : undefined,
                    placeholder: placeholder,
                    value: value,
                    onChange: handleInputChange,
                    onKeyDown: handleKeyDown,
                    onFocus: ()=>value.length >= minChars && setIsOpen(true),
                    disabled: disabled,
                    isLoading: isLoading
                }, void 0, false, {
                    fileName: "[project]/src/components/molecules/SearchBar/SearchBar.tsx",
                    lineNumber: 200,
                    columnNumber: 21
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/components/molecules/SearchBar/SearchBar.tsx",
                lineNumber: 199,
                columnNumber: 17
            }, ("TURBOPACK compile-time value", void 0)),
            showSuggestions && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$SearchBar$2f$SearchBar$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["suggestionsVariants"])({
                    variant: suggestionsVariant
                })),
                children: filteredSuggestions.length > 0 ? filteredSuggestions.map((suggestion, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$SearchBar$2f$SearchBar$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["suggestionItemVariants"])({
                            variant: suggestionsVariant,
                            isHighlighted: index === highlightedIndex
                        })),
                        onClick: ()=>handleSelect(suggestion),
                        onMouseEnter: ()=>setHighlightedIndex(index),
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$SearchBar$2f$SearchBar$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["searchBarSuggestionContentVariants"])()),
                                children: [
                                    showCategoryIcon && (suggestion.icon || /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shopping$2d$bag$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ShoppingBag$3e$__["ShoppingBag"], {
                                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$SearchBar$2f$SearchBar$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["searchBarSuggestionIconVariants"])())
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/molecules/SearchBar/SearchBar.tsx",
                                        lineNumber: 255,
                                        columnNumber: 49
                                    }, ("TURBOPACK compile-time value", void 0))),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Typography$2f$Text$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Text"], {
                                                size: "sm",
                                                weight: "bold",
                                                lineClamp: 1,
                                                children: suggestion.label
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/molecules/SearchBar/SearchBar.tsx",
                                                lineNumber: 262,
                                                columnNumber: 45
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            suggestion.category && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Typography$2f$Text$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Text"], {
                                                size: "xs",
                                                variant: "caption",
                                                transform: "uppercase",
                                                children: suggestion.category
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/molecules/SearchBar/SearchBar.tsx",
                                                lineNumber: 270,
                                                columnNumber: 49
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/molecules/SearchBar/SearchBar.tsx",
                                        lineNumber: 261,
                                        columnNumber: 41
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/molecules/SearchBar/SearchBar.tsx",
                                lineNumber: 248,
                                columnNumber: 37
                            }, ("TURBOPACK compile-time value", void 0)),
                            index === highlightedIndex && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__["ArrowRight"], {
                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$SearchBar$2f$SearchBar$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["searchBarArrowIconVariants"])())
                            }, void 0, false, {
                                fileName: "[project]/src/components/molecules/SearchBar/SearchBar.tsx",
                                lineNumber: 282,
                                columnNumber: 41
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, suggestion.id, true, {
                        fileName: "[project]/src/components/molecules/SearchBar/SearchBar.tsx",
                        lineNumber: 237,
                        columnNumber: 33
                    }, ("TURBOPACK compile-time value", void 0))) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$SearchBar$2f$SearchBar$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["searchBarEmptyStateVariants"])()),
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Typography$2f$Text$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Text"], {
                        variant: "caption",
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$SearchBar$2f$SearchBar$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["searchBarEmptyTextVariants"])()),
                        children: emptyMessage
                    }, void 0, false, {
                        fileName: "[project]/src/components/molecules/SearchBar/SearchBar.tsx",
                        lineNumber: 292,
                        columnNumber: 33
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/components/molecules/SearchBar/SearchBar.tsx",
                    lineNumber: 291,
                    columnNumber: 29
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/components/molecules/SearchBar/SearchBar.tsx",
                lineNumber: 230,
                columnNumber: 21
            }, ("TURBOPACK compile-time value", void 0)),
            showSuggestions && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$SearchBar$2f$SearchBar$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["searchBarOverlayVariants"])()),
                "aria-hidden": "true"
            }, void 0, false, {
                fileName: "[project]/src/components/molecules/SearchBar/SearchBar.tsx",
                lineNumber: 304,
                columnNumber: 21
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/molecules/SearchBar/SearchBar.tsx",
        lineNumber: 192,
        columnNumber: 13
    }, ("TURBOPACK compile-time value", void 0));
}, "e3L/Jv0P2nb2t6jB5GEv3trN39k=")), "e3L/Jv0P2nb2t6jB5GEv3trN39k=");
_c1 = SearchBar;
SearchBar.displayName = "SearchBar";
;
var _c, _c1;
__turbopack_context__.k.register(_c, "SearchBar$forwardRef");
__turbopack_context__.k.register(_c1, "SearchBar");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/molecules/SearchBar/SearchBarSkeleton.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// components/molecules/SearchBar/SearchBarSkeleton.tsx
__turbopack_context__.s([
    "SearchBarSkeleton",
    ()=>SearchBarSkeleton
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$SearchBar$2f$SearchBar$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/molecules/SearchBar/SearchBar.variants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/utils/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils/cn.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Input$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/components/atoms/Input/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Input$2f$InputSkeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Input/InputSkeleton.tsx [app-client] (ecmascript)");
;
;
;
;
function SearchBarSkeleton({ size = "md", suggestionCount = 0, className }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$SearchBar$2f$SearchBar$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["searchBarVariants"])({
            size,
            isOpen: suggestionCount > 0
        }), className),
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Input$2f$InputSkeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InputSkeleton"], {
            size: size === "full" ? "lg" : size,
            hasLeftIcon: true,
            variant: "skeleton"
        }, void 0, false, {
            fileName: "[project]/src/components/molecules/SearchBar/SearchBarSkeleton.tsx",
            lineNumber: 21,
            columnNumber: 13
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/molecules/SearchBar/SearchBarSkeleton.tsx",
        lineNumber: 20,
        columnNumber: 9
    }, this);
}
_c = SearchBarSkeleton;
var _c;
__turbopack_context__.k.register(_c, "SearchBarSkeleton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/molecules/SearchBar/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
// ============================================================================
// SEARCH BAR SYSTEM — Barrel export
// ============================================================================
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$SearchBar$2f$SearchBar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/molecules/SearchBar/SearchBar.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$SearchBar$2f$SearchBar$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/molecules/SearchBar/SearchBar.variants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$SearchBar$2f$SearchBarSkeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/molecules/SearchBar/SearchBarSkeleton.tsx [app-client] (ecmascript)");
;
;
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/hooks/useAppNavigation.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useAppNavigation",
    ()=>useAppNavigation
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
"use client";
;
function useAppNavigation() {
    _s();
    const openExternal = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useAppNavigation.useCallback[openExternal]": (url)=>{
            if (!url) return;
            window.open(url, "_blank", "noopener,noreferrer");
        }
    }["useAppNavigation.useCallback[openExternal]"], []);
    const searchStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useAppNavigation.useCallback[searchStore]": (query)=>{
            if (!query.trim()) return;
            const url = `https://jovenpro.com/?s=${encodeURIComponent(query)}&post_type=product&product_cat=`;
            openExternal(url);
        }
    }["useAppNavigation.useCallback[searchStore]"], [
        openExternal
    ]);
    const goToCart = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useAppNavigation.useCallback[goToCart]": ()=>{
            openExternal("https://jovenpro.com/carrito/");
        }
    }["useAppNavigation.useCallback[goToCart]"], [
        openExternal
    ]);
    const scrollToSection = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useAppNavigation.useCallback[scrollToSection]": (href)=>{
            if (href.startsWith("#")) {
                const el = document.querySelector(href);
                if (el) {
                    el.scrollIntoView({
                        behavior: "smooth"
                    });
                    return;
                }
            }
            openExternal(href);
        }
    }["useAppNavigation.useCallback[scrollToSection]"], [
        openExternal
    ]);
    return {
        openExternal,
        searchStore,
        goToCart,
        scrollToSection
    };
}
_s(useAppNavigation, "lTznrZ2DIJj0fF1/frw1tbAAWqg=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/organisms/NavbarSticky/NavbarSticky.variants.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "navbarStickyActionIconVariants",
    ()=>navbarStickyActionIconVariants,
    "navbarStickyActionsVariants",
    ()=>navbarStickyActionsVariants,
    "navbarStickyInnerVariants",
    ()=>navbarStickyInnerVariants,
    "navbarStickyLoginButtonVariants",
    ()=>navbarStickyLoginButtonVariants,
    "navbarStickyLogoVariants",
    ()=>navbarStickyLogoVariants,
    "navbarStickyMobileLinkVariants",
    ()=>navbarStickyMobileLinkVariants,
    "navbarStickyMobileListVariants",
    ()=>navbarStickyMobileListVariants,
    "navbarStickyMobileMenuVariants",
    ()=>navbarStickyMobileMenuVariants,
    "navbarStickyMobileToggleVariants",
    ()=>navbarStickyMobileToggleVariants,
    "navbarStickyNavLinkVariants",
    ()=>navbarStickyNavLinkVariants,
    "navbarStickyNavListVariants",
    ()=>navbarStickyNavListVariants,
    "navbarStickySearchVariants",
    ()=>navbarStickySearchVariants,
    "navbarStickySvgIconVariants",
    ()=>navbarStickySvgIconVariants,
    "navbarStickyVariants",
    ()=>navbarStickyVariants
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/class-variance-authority/dist/index.mjs [app-client] (ecmascript)");
;
const navbarStickyVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("z-50 w-full transition-all duration-500 ease-smooth", {
    variants: {
        state: {
            transparent: "relative bg-transparent/5 backdrop-blur-md border-b border-border/70 shadow-clay",
            solid: "sticky top-0 bg-background backdrop-blur-sm border-b border-border/40 shadow-clay"
        }
    },
    defaultVariants: {
        state: "transparent"
    }
});
const navbarStickyInnerVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("flex items-center justify-between h-16 md:h-20");
const navbarStickyLogoVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("", {
    variants: {
        state: {
            transparent: "text-muted-foreground/50",
            solid: "text-secondary"
        }
    },
    defaultVariants: {
        state: "solid"
    }
});
const navbarStickyNavListVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("", {
    variants: {
        searchActive: {
            true: "hidden",
            false: "hidden lg:flex items-center gap-8"
        }
    },
    defaultVariants: {
        searchActive: false
    }
});
const navbarStickyNavLinkVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("text-sm font-semibold uppercase tracking-[0.1em] transition-colors duration-300", {
    variants: {
        state: {
            transparent: "text-muted-foreground/50 hover:text-foreground",
            solid: "text-foreground hover:text-primary"
        }
    },
    defaultVariants: {
        state: "solid"
    }
});
const navbarStickySearchVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("", {
    variants: {
        active: {
            true: "flex-1 max-w-md mx-4 hidden lg:flex",
            false: "hidden"
        }
    },
    defaultVariants: {
        active: false
    }
});
const navbarStickyActionsVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("flex items-center gap-2 shrink-0");
const navbarStickyActionIconVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("", {
    variants: {
        state: {
            transparent: "text-muted-foreground/50",
            solid: "text-foreground"
        }
    },
    defaultVariants: {
        state: "solid"
    }
});
const navbarStickySvgIconVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("w-5 h-5");
const navbarStickyLoginButtonVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("flex", {
    variants: {
        state: {
            transparent: "bg-secondary/20 text-muted-foreground/50 hover:bg-white/20 backdrop-blur-sm border border-white/20 shadow-none",
            solid: ""
        }
    },
    defaultVariants: {
        state: "solid"
    }
});
const navbarStickyMobileToggleVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("lg:hidden");
const navbarStickyMobileMenuVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("lg:hidden absolute left-0 right-0 top-full bg-background border-t border-surface-variant shadow-clay-lg");
const navbarStickyMobileListVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("flex flex-col gap-4 py-4");
const navbarStickyMobileLinkVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("text-base font-semibold text-foreground hover:text-primary transition-colors w-full block py-2");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/organisms/NavbarSticky/NavbarSticky.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "NavbarSticky",
    ()=>NavbarSticky
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$m$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/render/components/m/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/components/AnimatePresence/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$LazyMotion$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/components/LazyMotion/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$framer$2d$features$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/framer-features.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Container$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/components/atoms/Container/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Container$2f$Container$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Container/Container.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$IconButton$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/components/atoms/IconButton/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$IconButton$2f$IconButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/IconButton/IconButton.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Button$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/components/atoms/Button/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Button$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Button/Button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$SearchBar$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/components/molecules/SearchBar/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$SearchBar$2f$SearchBar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/molecules/SearchBar/SearchBar.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/utils/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils/cn.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$menu$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Menu$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/menu.js [app-client] (ecmascript) <export default as Menu>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/x.js [app-client] (ecmascript) <export default as X>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/search.js [app-client] (ecmascript) <export default as Search>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useAppNavigation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/useAppNavigation.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$NavbarSticky$2f$NavbarSticky$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/organisms/NavbarSticky/NavbarSticky.variants.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
;
function NavbarSticky({ items, cartCount = 0, className, loginHref = "https://jovenpro.com/my-account/", searchSuggestions = [] }) {
    _s();
    const [isSolid, setIsSolid] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [mobileOpen, setMobileOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [searchActive, setSearchActive] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [searchValue, setSearchValue] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const { searchStore, openExternal, goToCart, scrollToSection } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useAppNavigation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppNavigation"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "NavbarSticky.useEffect": ()=>{
            const hero = document.querySelector("#inicio");
            if (!hero) return;
            const observer = new IntersectionObserver({
                "NavbarSticky.useEffect": ([entry])=>setIsSolid(!entry.isIntersecting)
            }["NavbarSticky.useEffect"], {
                root: null,
                threshold: 0
            });
            observer.observe(hero);
            return ({
                "NavbarSticky.useEffect": ()=>observer.disconnect()
            })["NavbarSticky.useEffect"];
        }
    }["NavbarSticky.useEffect"], []);
    const navState = isSolid ? "solid" : "transparent";
    const handleNavClick = (href)=>{
        setMobileOpen(false);
        setSearchActive(false);
        // Espera a que la animación de cierre del drawer (300ms) termine antes de hacer scroll.
        // Esto evita el race condition donde scrollIntoView se ejecuta mientras el menú
        // todavía está superpuesto en pantalla y bloquea el viewport.
        setTimeout(()=>scrollToSection(href), 350);
    };
    const toggleSearch = ()=>{
        setSearchActive((prev)=>!prev);
        setMobileOpen(false);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$LazyMotion$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LazyMotion"], {
            features: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$framer$2d$features$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
            strict: true,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$m$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["m"].nav, {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$NavbarSticky$2f$NavbarSticky$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["navbarStickyVariants"])({
                    state: navState
                }), className),
                initial: {
                    y: -100
                },
                animate: {
                    y: 0
                },
                transition: {
                    duration: 0.6,
                    ease: [
                        0.25,
                        1,
                        0.5,
                        1
                    ]
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Container$2f$Container$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Container"], {
                        size: "lg",
                        padding: "md",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$NavbarSticky$2f$NavbarSticky$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["navbarStickyInnerVariants"])(),
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$NavbarSticky$2f$NavbarSticky$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["navbarStickyLogoVariants"])(),
                                    onClick: ()=>handleNavClick("#inicio"),
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                        src: "/images/logo/jpror.png",
                                        alt: "JovenPro Logo",
                                        className: "h-8 md:h-10 w-auto object-contain cursor-pointer"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/organisms/NavbarSticky/NavbarSticky.tsx",
                                        lineNumber: 102,
                                        columnNumber: 29
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/organisms/NavbarSticky/NavbarSticky.tsx",
                                    lineNumber: 98,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$NavbarSticky$2f$NavbarSticky$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["navbarStickyNavListVariants"])({
                                        searchActive
                                    }),
                                    children: items.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                href: item.href,
                                                onClick: (e)=>{
                                                    e.preventDefault();
                                                    handleNavClick(item.href);
                                                },
                                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$NavbarSticky$2f$NavbarSticky$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["navbarStickyNavLinkVariants"])({
                                                    state: navState
                                                }),
                                                children: item.label
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/organisms/NavbarSticky/NavbarSticky.tsx",
                                                lineNumber: 112,
                                                columnNumber: 37
                                            }, this)
                                        }, item.href, false, {
                                            fileName: "[project]/src/components/organisms/NavbarSticky/NavbarSticky.tsx",
                                            lineNumber: 111,
                                            columnNumber: 33
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/src/components/organisms/NavbarSticky/NavbarSticky.tsx",
                                    lineNumber: 109,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$NavbarSticky$2f$NavbarSticky$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["navbarStickySearchVariants"])({
                                        active: searchActive
                                    }),
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$SearchBar$2f$SearchBar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SearchBar"], {
                                        value: searchValue,
                                        onChange: setSearchValue,
                                        onSubmit: searchStore,
                                        onSelect: (s)=>s.href && openExternal(s.href),
                                        suggestions: searchSuggestions,
                                        size: "md",
                                        autoFocus: searchActive,
                                        closeOnClickOutside: true
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/organisms/NavbarSticky/NavbarSticky.tsx",
                                        lineNumber: 127,
                                        columnNumber: 29
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/organisms/NavbarSticky/NavbarSticky.tsx",
                                    lineNumber: 126,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$NavbarSticky$2f$NavbarSticky$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["navbarStickyActionsVariants"])(),
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$IconButton$2f$IconButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IconButton"], {
                                            icon: searchActive ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$NavbarSticky$2f$NavbarSticky$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["navbarStickySvgIconVariants"])())
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/organisms/NavbarSticky/NavbarSticky.tsx",
                                                lineNumber: 143,
                                                columnNumber: 41
                                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__["Search"], {
                                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$NavbarSticky$2f$NavbarSticky$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["navbarStickySvgIconVariants"])())
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/organisms/NavbarSticky/NavbarSticky.tsx",
                                                lineNumber: 145,
                                                columnNumber: 41
                                            }, this),
                                            variant: "ghost",
                                            size: "md",
                                            "aria-label": searchActive ? "Cerrar búsqueda" : "Buscar",
                                            onClick: toggleSearch,
                                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$NavbarSticky$2f$NavbarSticky$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["navbarStickyActionIconVariants"])({
                                                state: navState
                                            })
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/organisms/NavbarSticky/NavbarSticky.tsx",
                                            lineNumber: 140,
                                            columnNumber: 29
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$NavbarSticky$2f$NavbarSticky$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["navbarStickyLoginButtonVariants"])(),
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Button$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                                asChild: true,
                                                variant: isSolid ? "primary" : "glass",
                                                size: "sm",
                                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$NavbarSticky$2f$NavbarSticky$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["navbarStickyLoginButtonVariants"])({
                                                    state: navState
                                                }),
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                    href: loginHref,
                                                    target: "_blank",
                                                    rel: "noopener noreferrer",
                                                    children: "Iniciar sesión"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/organisms/NavbarSticky/NavbarSticky.tsx",
                                                    lineNumber: 173,
                                                    columnNumber: 37
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/organisms/NavbarSticky/NavbarSticky.tsx",
                                                lineNumber: 167,
                                                columnNumber: 33
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/organisms/NavbarSticky/NavbarSticky.tsx",
                                            lineNumber: 166,
                                            columnNumber: 29
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$IconButton$2f$IconButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IconButton"], {
                                            icon: mobileOpen ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$NavbarSticky$2f$NavbarSticky$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["navbarStickySvgIconVariants"])())
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/organisms/NavbarSticky/NavbarSticky.tsx",
                                                lineNumber: 182,
                                                columnNumber: 41
                                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$menu$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Menu$3e$__["Menu"], {
                                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$NavbarSticky$2f$NavbarSticky$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["navbarStickySvgIconVariants"])())
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/organisms/NavbarSticky/NavbarSticky.tsx",
                                                lineNumber: 184,
                                                columnNumber: 41
                                            }, this),
                                            variant: "ghost",
                                            size: "md",
                                            "aria-label": mobileOpen ? "Cerrar menú" : "Abrir menú",
                                            onClick: ()=>setMobileOpen(!mobileOpen),
                                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$NavbarSticky$2f$NavbarSticky$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["navbarStickyMobileToggleVariants"])(), (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$NavbarSticky$2f$NavbarSticky$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["navbarStickyActionIconVariants"])({
                                                state: navState
                                            }))
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/organisms/NavbarSticky/NavbarSticky.tsx",
                                            lineNumber: 179,
                                            columnNumber: 29
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/organisms/NavbarSticky/NavbarSticky.tsx",
                                    lineNumber: 139,
                                    columnNumber: 25
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/organisms/NavbarSticky/NavbarSticky.tsx",
                            lineNumber: 97,
                            columnNumber: 21
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/organisms/NavbarSticky/NavbarSticky.tsx",
                        lineNumber: 96,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimatePresence"], {
                        children: searchActive && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$m$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["m"].div, {
                            initial: {
                                opacity: 0,
                                height: 0
                            },
                            animate: {
                                opacity: 1,
                                height: "auto"
                            },
                            exit: {
                                opacity: 0,
                                height: 0
                            },
                            className: "lg:hidden bg-background/95 backdrop-blur-md border-b border-surface-variant z-50 shadow-clay overflow-visible relative",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Container$2f$Container$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Container"], {
                                size: "lg",
                                padding: "md",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "py-4",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$SearchBar$2f$SearchBar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SearchBar"], {
                                        value: searchValue,
                                        onChange: setSearchValue,
                                        onSubmit: searchStore,
                                        onSelect: (s)=>s.href && openExternal(s.href),
                                        suggestions: searchSuggestions,
                                        size: "md",
                                        autoFocus: true
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/organisms/NavbarSticky/NavbarSticky.tsx",
                                        lineNumber: 211,
                                        columnNumber: 37
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/organisms/NavbarSticky/NavbarSticky.tsx",
                                    lineNumber: 210,
                                    columnNumber: 33
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/organisms/NavbarSticky/NavbarSticky.tsx",
                                lineNumber: 209,
                                columnNumber: 29
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/organisms/NavbarSticky/NavbarSticky.tsx",
                            lineNumber: 203,
                            columnNumber: 25
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/organisms/NavbarSticky/NavbarSticky.tsx",
                        lineNumber: 201,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimatePresence"], {
                        children: mobileOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$m$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["m"].div, {
                            initial: {
                                opacity: 0,
                                y: -10
                            },
                            animate: {
                                opacity: 1,
                                y: 0
                            },
                            exit: {
                                opacity: 0,
                                y: -10
                            },
                            transition: {
                                duration: 0.25,
                                ease: [
                                    0.25,
                                    1,
                                    0.5,
                                    1
                                ]
                            },
                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$NavbarSticky$2f$NavbarSticky$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["navbarStickyMobileMenuVariants"])(),
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Container$2f$Container$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Container"], {
                                size: "lg",
                                padding: "md",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$NavbarSticky$2f$NavbarSticky$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["navbarStickyMobileListVariants"])(),
                                    children: items.map((item, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$m$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["m"].li, {
                                            initial: {
                                                opacity: 0,
                                                x: -20
                                            },
                                            animate: {
                                                opacity: 1,
                                                x: 0
                                            },
                                            transition: {
                                                delay: i * 0.05
                                            },
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                href: item.href,
                                                onClick: (e)=>{
                                                    e.preventDefault();
                                                    handleNavClick(item.href);
                                                },
                                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$NavbarSticky$2f$NavbarSticky$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["navbarStickyMobileLinkVariants"])(),
                                                children: item.label
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/organisms/NavbarSticky/NavbarSticky.tsx",
                                                lineNumber: 244,
                                                columnNumber: 45
                                            }, this)
                                        }, item.href, false, {
                                            fileName: "[project]/src/components/organisms/NavbarSticky/NavbarSticky.tsx",
                                            lineNumber: 238,
                                            columnNumber: 41
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/src/components/organisms/NavbarSticky/NavbarSticky.tsx",
                                    lineNumber: 236,
                                    columnNumber: 33
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/organisms/NavbarSticky/NavbarSticky.tsx",
                                lineNumber: 235,
                                columnNumber: 29
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/organisms/NavbarSticky/NavbarSticky.tsx",
                            lineNumber: 228,
                            columnNumber: 25
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/organisms/NavbarSticky/NavbarSticky.tsx",
                        lineNumber: 226,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/organisms/NavbarSticky/NavbarSticky.tsx",
                lineNumber: 90,
                columnNumber: 13
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/organisms/NavbarSticky/NavbarSticky.tsx",
            lineNumber: 89,
            columnNumber: 13
        }, this)
    }, void 0, false);
}
_s(NavbarSticky, "W10JBEz92RN52nGIXXHhc2yA2c8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useAppNavigation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppNavigation"]
    ];
});
_c = NavbarSticky;
var _c;
__turbopack_context__.k.register(_c, "NavbarSticky");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/atoms/Logo/Logo.variants.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "logoVariants",
    ()=>logoVariants
]);
// ============================================================================
// LOGO VARIANTS — Átomo de identidad de marca
// ============================================================================
// REFACTOR V3:
// - Tokens fantasmas eliminados:
//   • "text-on-surface" → "text-secondary" (highlight "PRO" en navy)
//   • "text-on-surface-variant" → eliminado del gradiente
//   • "from-on-surface" / "to-on-surface-variant" → "from-secondary" / "to-secondary-light"
// - "inverted" conserva "text-white": es utilitario Tailwind válido para fondos
//   oscuros (deep #1A1832). No es token fantasma; es color CSS puro.
// - Tipos derivados del CVA (Parameters<typeof>).
// - Zero inline classes en .tsx ya cumplido; no se toca la estructura del componente.
// ============================================================================
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/class-variance-authority/dist/index.mjs [app-client] (ecmascript)");
;
const logoVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("font-black tracking-tighter inline-flex items-center select-none", {
    variants: {
        variant: {
            default: "text-primary [&>span]:text-secondary",
            inverted: "text-white [&>span]:text-muted-foreground/40",
            monochrome: "text-foreground [&>span]:text-foreground",
            gradient: "bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent [&>span]:bg-gradient-to-r [&>span]:from-secondary [&>span]:to-secondary-light [&>span]:bg-clip-text [&>span]:text-transparent"
        },
        size: {
            sm: "text-xl",
            md: "text-2xl",
            lg: "text-4xl",
            xl: "text-6xl"
        },
        interactive: {
            true: "cursor-pointer hover:opacity-80 transition-opacity",
            false: ""
        }
    },
    defaultVariants: {
        variant: "default",
        size: "md",
        interactive: true
    }
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/atoms/Logo/Logo.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Logo",
    ()=>Logo
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
// ============================================================================
// LOGO — Átomo de identidad de marca
// ============================================================================
// REFACTOR V3:
// - Zero inline classes: todo el CSS vive en Logo.variants.ts.
// - No se tocan colores aquí; el tema se controla via tokens de Tailwind.
// - Tipos importados desde .variants.ts (derivados del CVA).
// - "highlightText" (default "PRO") se estiliza via selector [&>span] en el CVA.
// ============================================================================
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Logo$2f$Logo$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Logo/Logo.variants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/utils/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils/cn.ts [app-client] (ecmascript)");
;
;
;
;
const Logo = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = ({ variant = "default", size = "md", href, text = "JOVEN", highlightText = "PRO", highlightPosition = "end", separator = "", interactive = true, onClick, className, ...props }, ref)=>{
    const content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            highlightPosition === "start" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                children: highlightText
            }, void 0, false, {
                fileName: "[project]/src/components/atoms/Logo/Logo.tsx",
                lineNumber: 60,
                columnNumber: 51
            }, ("TURBOPACK compile-time value", void 0)),
            highlightPosition === "start" && separator,
            text,
            highlightPosition === "end" && separator,
            highlightPosition === "end" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                children: highlightText
            }, void 0, false, {
                fileName: "[project]/src/components/atoms/Logo/Logo.tsx",
                lineNumber: 64,
                columnNumber: 49
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true);
    const classes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Logo$2f$Logo$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["logoVariants"])({
        variant,
        size,
        interactive
    }), className);
    if (href) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
            ref: ref,
            href: href,
            className: classes,
            onClick: onClick,
            ...props,
            children: content
        }, void 0, false, {
            fileName: "[project]/src/components/atoms/Logo/Logo.tsx",
            lineNumber: 75,
            columnNumber: 17
        }, ("TURBOPACK compile-time value", void 0));
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
        ref: ref,
        className: classes,
        onClick: onClick,
        ...props,
        children: content
    }, void 0, false, {
        fileName: "[project]/src/components/atoms/Logo/Logo.tsx",
        lineNumber: 88,
        columnNumber: 13
    }, ("TURBOPACK compile-time value", void 0));
});
_c1 = Logo;
Logo.displayName = "Logo";
;
var _c, _c1;
__turbopack_context__.k.register(_c, "Logo$forwardRef");
__turbopack_context__.k.register(_c1, "Logo");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/atoms/Logo/LogoSkeleton.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LogoSkeleton",
    ()=>LogoSkeleton
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
// components/atoms/Logo/LogoSkeleton.tsx
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Logo$2f$Logo$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Logo/Logo.variants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/utils/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils/cn.ts [app-client] (ecmascript)");
;
;
;
function LogoSkeleton({ variant = "default", size = "md", interactive = true, className }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Logo$2f$Logo$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["logoVariants"])({
            variant,
            size,
            interactive
        }), "skeleton-pulse border-transparent shadow-none text-transparent pointer-events-none select-none", className),
        "aria-hidden": "true"
    }, void 0, false, {
        fileName: "[project]/src/components/atoms/Logo/LogoSkeleton.tsx",
        lineNumber: 20,
        columnNumber: 9
    }, this);
}
_c = LogoSkeleton;
var _c;
__turbopack_context__.k.register(_c, "LogoSkeleton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/atoms/Logo/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
// ============================================================================
// LOGO SYSTEM — Barrel export
// ============================================================================
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Logo$2f$Logo$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Logo/Logo.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Logo$2f$Logo$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Logo/Logo.variants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Logo$2f$LogoSkeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Logo/LogoSkeleton.tsx [app-client] (ecmascript)");
;
;
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/atoms/Section/Section.variants.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "sectionVariants",
    ()=>sectionVariants
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/class-variance-authority/dist/index.mjs [app-client] (ecmascript)");
;
const sectionVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("w-full", {
    variants: {
        spacing: {
            none: "py-0",
            sm: "py-12 md:py-16",
            md: "py-16 md:py-20",
            lg: "py-20 md:py-28",
            xl: "py-24 md:py-32",
            hero: "min-h-screen flex flex-col md:flex-row items-stretch"
        },
        background: {
            transparent: "bg-transparent",
            background: "bg-primary/10",
            surface: "bg-surface",
            "surface-container": "bg-surface-container",
            "surface-container-low": "bg-surface-container-low"
        }
    },
    defaultVariants: {
        spacing: "lg",
        background: "transparent"
    }
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/atoms/Section/Section.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Section",
    ()=>Section
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/utils/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils/cn.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Section$2f$Section$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Section/Section.variants.ts [app-client] (ecmascript)");
;
;
;
;
const Section = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = ({ id, as: Tag = "section", spacing, background, className, children, ...props }, ref)=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Tag, {
        ref: ref,
        id: id,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Section$2f$Section$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sectionVariants"])({
            spacing,
            background
        }), className),
        ...props,
        children: children
    }, void 0, false, {
        fileName: "[project]/src/components/atoms/Section/Section.tsx",
        lineNumber: 17,
        columnNumber: 13
    }, ("TURBOPACK compile-time value", void 0));
});
_c1 = Section;
Section.displayName = "Section";
var _c, _c1;
__turbopack_context__.k.register(_c, "Section$forwardRef");
__turbopack_context__.k.register(_c1, "Section");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/atoms/Section/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
// ============================================================================
// SECTION ATOM — Barrel export
// ============================================================================
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Section$2f$Section$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Section/Section.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Section$2f$Section$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Section/Section.variants.ts [app-client] (ecmascript)");
;
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/organisms/HeroSplit/HeroSplit.variants.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "heroSplitArrowVariants",
    ()=>heroSplitArrowVariants,
    "heroSplitCTAVariants",
    ()=>heroSplitCTAVariants,
    "heroSplitContentVariants",
    ()=>heroSplitContentVariants,
    "heroSplitDarkOverlayVariants",
    ()=>heroSplitDarkOverlayVariants,
    "heroSplitDividerVariants",
    ()=>heroSplitDividerVariants,
    "heroSplitGradientOverlayVariants",
    ()=>heroSplitGradientOverlayVariants,
    "heroSplitImageContainerVariants",
    ()=>heroSplitImageContainerVariants,
    "heroSplitImageVariants",
    ()=>heroSplitImageVariants,
    "heroSplitLogoContainerVariants",
    ()=>heroSplitLogoContainerVariants,
    "heroSplitLogoImageVariants",
    ()=>heroSplitLogoImageVariants,
    "heroSplitLogoWrapperVariants",
    ()=>heroSplitLogoWrapperVariants,
    "heroSplitSideVariants",
    ()=>heroSplitSideVariants,
    "heroSplitSubtitleVariants",
    ()=>heroSplitSubtitleVariants,
    "heroSplitTitleVariants",
    ()=>heroSplitTitleVariants
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/class-variance-authority/dist/index.mjs [app-client] (ecmascript)");
;
const heroSplitDividerVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("hidden md:block absolute left-1/2 top-0 bottom-0 w-px  z-10");
const heroSplitLogoWrapperVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-30 pointer-events-none");
const heroSplitLogoContainerVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("p-4 sm:p-6 md:p-10 rounded-full bg-white/10 backdrop-blur-xl border border-white/20 shadow-[0_0_50px_rgba(255,255,255,0.1)] flex items-center justify-center transition-all duration-700 ease-smooth hover:bg-white/20 hover:scale-110");
const heroSplitLogoImageVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("h-16 sm:h-24 md:h-32 w-auto object-contain drop-shadow-2xl");
const heroSplitSideVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("relative flex-1 w-full min-h-[50vh] md:min-h-screen cursor-pointer group overflow-hidden");
const heroSplitImageContainerVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("absolute inset-0");
const heroSplitImageVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("h-full w-full object-cover transition-all duration-500 ease-smooth group-hover:scale-105", {
    variants: {
        filter: {
            default: "grayscale brightness-100 contrast-100 saturate-0 group-hover:grayscale-0 group-hover:brightness-100 group-hover:contrast-100 group-hover:saturate-100"
        }
    },
    defaultVariants: {
        filter: "default"
    }
});
const heroSplitGradientOverlayVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("absolute inset-0 transition-opacity duration-500 group-hover:opacity-0", {
    variants: {
        direction: {
            left: "bg-gradient-to-l from-surface/90 via-primary/20 to-transparent",
            right: "bg-gradient-to-r from-secondary/90 via-primary/20 to-transparent"
        }
    },
    defaultVariants: {
        direction: "left"
    }
});
const heroSplitDarkOverlayVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("absolute inset-0 bg-black/40 group-hover:bg-black/20 transition-colors duration-500");
const heroSplitContentVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("absolute bottom-4 md:bottom-10 z-20", {
    variants: {
        align: {
            left: "left-4 md:left-10 text-left",
            right: "right-4 md:right-10 text-right"
        }
    },
    defaultVariants: {
        align: "left"
    }
});
const heroSplitTitleVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("font-headline text-2xl sm:text-4xl md:text-6xl font-bold text-white drop-shadow-lg mb-2 md:mb-3");
const heroSplitSubtitleVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("font-body text-white/90 text-sm sm:text-base md:text-lg mb-4 md:mb-6 max-w-[90%] sm:max-w-xs md:max-w-sm", {
    variants: {
        align: {
            left: "",
            right: "ml-auto"
        }
    },
    defaultVariants: {
        align: "left"
    }
});
const heroSplitCTAVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("inline-flex items-center gap-2 text-sm font-semibold uppercase tracking-widest text-white group-hover:gap-3 transition-all duration-300");
const heroSplitArrowVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("w-4 h-4 transition-transform duration-300", {
    variants: {
        direction: {
            // Si el diseño es "left", la flecha mira a la derecha (normal)
            // y se mueve hacia la derecha en hover.
            left: "rotate-0 group-hover:translate-x-1",
            // Si el diseño es "right", la flecha mira a la izquierda (rotada)
            // y se mueve hacia la izquierda en hover.
            right: "rotate-180 group-hover:-translate-x-1"
        }
    },
    defaultVariants: {
        direction: "left"
    }
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/organisms/HeroSplit/HeroSplit.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "HeroSplit",
    ()=>HeroSplit
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$m$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/render/components/m/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$LazyMotion$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/components/LazyMotion/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$framer$2d$features$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/framer-features.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Logo$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/components/atoms/Logo/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Logo$2f$Logo$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Logo/Logo.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Section$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/components/atoms/Section/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Section$2f$Section$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Section/Section.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useAppNavigation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/useAppNavigation.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$HeroSplit$2f$HeroSplit$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/organisms/HeroSplit/HeroSplit.variants.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
function HeroSplit({ left, right, logoSrc, className }) {
    _s();
    const { scrollToSection } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useAppNavigation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppNavigation"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Section$2f$Section$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Section"], {
        id: "inicio",
        spacing: "hero",
        className: className,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(HeroSide, {
                data: left,
                position: "left",
                onClick: ()=>scrollToSection(left.href)
            }, void 0, false, {
                fileName: "[project]/src/components/organisms/HeroSplit/HeroSplit.tsx",
                lineNumber: 63,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$HeroSplit$2f$HeroSplit$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["heroSplitDividerVariants"])()
            }, void 0, false, {
                fileName: "[project]/src/components/organisms/HeroSplit/HeroSplit.tsx",
                lineNumber: 69,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(HeroSide, {
                data: right,
                position: "right",
                onClick: ()=>scrollToSection(right.href)
            }, void 0, false, {
                fileName: "[project]/src/components/organisms/HeroSplit/HeroSplit.tsx",
                lineNumber: 71,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$LazyMotion$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LazyMotion"], {
                features: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$framer$2d$features$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
                strict: true,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$HeroSplit$2f$HeroSplit$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["heroSplitLogoWrapperVariants"])(),
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$m$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["m"].div, {
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$HeroSplit$2f$HeroSplit$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["heroSplitLogoContainerVariants"])(),
                        initial: {
                            opacity: 0,
                            scale: 0.5,
                            rotate: -10
                        },
                        animate: {
                            opacity: 1,
                            scale: 1,
                            rotate: 0
                        },
                        transition: {
                            duration: 1.2,
                            delay: 0.8,
                            ease: [
                                0.23,
                                1,
                                0.32,
                                1
                            ]
                        },
                        children: logoSrc ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                            src: logoSrc,
                            alt: "JovenPro",
                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$HeroSplit$2f$HeroSplit$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["heroSplitLogoImageVariants"])()
                        }, void 0, false, {
                            fileName: "[project]/src/components/organisms/HeroSplit/HeroSplit.tsx",
                            lineNumber: 91,
                            columnNumber: 25
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Logo$2f$Logo$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Logo"], {
                            variant: "default",
                            size: "lg",
                            className: "h-20 md:h-28 w-auto"
                        }, void 0, false, {
                            fileName: "[project]/src/components/organisms/HeroSplit/HeroSplit.tsx",
                            lineNumber: 97,
                            columnNumber: 25
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/organisms/HeroSplit/HeroSplit.tsx",
                        lineNumber: 80,
                        columnNumber: 17
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/organisms/HeroSplit/HeroSplit.tsx",
                    lineNumber: 79,
                    columnNumber: 13
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/organisms/HeroSplit/HeroSplit.tsx",
                lineNumber: 78,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/organisms/HeroSplit/HeroSplit.tsx",
        lineNumber: 62,
        columnNumber: 9
    }, this);
}
_s(HeroSplit, "Ws2jtuq42ObTli5GonSCb7fHyD4=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useAppNavigation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppNavigation"]
    ];
});
_c = HeroSplit;
function HeroSide({ data, position, onClick }) {
    const isLeft = position === "left";
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$LazyMotion$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LazyMotion"], {
        features: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$framer$2d$features$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
        strict: true,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$m$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["m"].div, {
            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$HeroSplit$2f$HeroSplit$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["heroSplitSideVariants"])(),
            onClick: onClick,
            initial: {
                opacity: 0,
                x: isLeft ? -60 : 60
            },
            animate: {
                opacity: 1,
                x: 0
            },
            transition: {
                duration: 0.8,
                ease: [
                    0.25,
                    1,
                    0.5,
                    1
                ],
                delay: isLeft ? 0.2 : 0.4
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$HeroSplit$2f$HeroSplit$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["heroSplitImageContainerVariants"])(),
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                            src: data.image,
                            alt: data.title,
                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$HeroSplit$2f$HeroSplit$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["heroSplitImageVariants"])()
                        }, void 0, false, {
                            fileName: "[project]/src/components/organisms/HeroSplit/HeroSplit.tsx",
                            lineNumber: 135,
                            columnNumber: 17
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$HeroSplit$2f$HeroSplit$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["heroSplitGradientOverlayVariants"])({
                                direction: isLeft ? "left" : "right"
                            })
                        }, void 0, false, {
                            fileName: "[project]/src/components/organisms/HeroSplit/HeroSplit.tsx",
                            lineNumber: 140,
                            columnNumber: 17
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$HeroSplit$2f$HeroSplit$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["heroSplitDarkOverlayVariants"])()
                        }, void 0, false, {
                            fileName: "[project]/src/components/organisms/HeroSplit/HeroSplit.tsx",
                            lineNumber: 145,
                            columnNumber: 17
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/organisms/HeroSplit/HeroSplit.tsx",
                    lineNumber: 134,
                    columnNumber: 13
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$HeroSplit$2f$HeroSplit$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["heroSplitContentVariants"])({
                        align: isLeft ? "left" : "right"
                    }),
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$m$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["m"].h2, {
                            initial: {
                                opacity: 0,
                                y: 30
                            },
                            animate: {
                                opacity: 1,
                                y: 0
                            },
                            transition: {
                                duration: 0.6,
                                delay: isLeft ? 0.5 : 0.7,
                                ease: [
                                    0.25,
                                    1,
                                    0.5,
                                    1
                                ]
                            },
                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$HeroSplit$2f$HeroSplit$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["heroSplitTitleVariants"])(),
                            children: data.title
                        }, void 0, false, {
                            fileName: "[project]/src/components/organisms/HeroSplit/HeroSplit.tsx",
                            lineNumber: 153,
                            columnNumber: 17
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$m$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["m"].p, {
                            initial: {
                                opacity: 0,
                                y: 20
                            },
                            animate: {
                                opacity: 1,
                                y: 0
                            },
                            transition: {
                                duration: 0.6,
                                delay: isLeft ? 0.7 : 0.9,
                                ease: [
                                    0.25,
                                    1,
                                    0.5,
                                    1
                                ]
                            },
                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$HeroSplit$2f$HeroSplit$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["heroSplitSubtitleVariants"])({
                                align: isLeft ? "left" : "right"
                            }),
                            children: data.subtitle
                        }, void 0, false, {
                            fileName: "[project]/src/components/organisms/HeroSplit/HeroSplit.tsx",
                            lineNumber: 166,
                            columnNumber: 17
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$m$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["m"].span, {
                            initial: {
                                opacity: 0,
                                y: 20
                            },
                            animate: {
                                opacity: 1,
                                y: 0
                            },
                            transition: {
                                duration: 0.6,
                                delay: isLeft ? 0.9 : 1.1,
                                ease: [
                                    0.25,
                                    1,
                                    0.5,
                                    1
                                ]
                            },
                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$HeroSplit$2f$HeroSplit$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["heroSplitCTAVariants"])(),
                            children: [
                                data.cta,
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$HeroSplit$2f$HeroSplit$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["heroSplitArrowVariants"])(),
                                    fill: "none",
                                    viewBox: "0 0 24 24",
                                    stroke: "currentColor",
                                    strokeWidth: 2,
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                        strokeLinecap: "round",
                                        strokeLinejoin: "round",
                                        d: "M17 8l4 4m0 0l-4 4m4-4H3"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/organisms/HeroSplit/HeroSplit.tsx",
                                        lineNumber: 199,
                                        columnNumber: 25
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/organisms/HeroSplit/HeroSplit.tsx",
                                    lineNumber: 192,
                                    columnNumber: 21
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/organisms/HeroSplit/HeroSplit.tsx",
                            lineNumber: 181,
                            columnNumber: 17
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/organisms/HeroSplit/HeroSplit.tsx",
                    lineNumber: 148,
                    columnNumber: 13
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/organisms/HeroSplit/HeroSplit.tsx",
            lineNumber: 123,
            columnNumber: 9
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/organisms/HeroSplit/HeroSplit.tsx",
        lineNumber: 122,
        columnNumber: 9
    }, this);
}
_c1 = HeroSide;
var _c, _c1;
__turbopack_context__.k.register(_c, "HeroSplit");
__turbopack_context__.k.register(_c1, "HeroSide");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/atoms/Avatar/Avatar.variants.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "avatarFallbackVariants",
    ()=>avatarFallbackVariants,
    "avatarImageVariants",
    ()=>avatarImageVariants,
    "avatarVariants",
    ()=>avatarVariants
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/class-variance-authority/dist/index.mjs [app-client] (ecmascript)");
;
const avatarVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("relative flex shrink-0 overflow-hidden rounded-full items-center justify-center bg-surface-variant font-headline text-foreground", {
    variants: {
        size: {
            sm: "w-8 h-8 text-xs",
            md: "w-10 h-10 text-sm",
            lg: "w-14 h-14 text-base",
            xl: "w-20 h-20 text-lg"
        },
        variant: {
            default: "",
            solid: "bg-primary text-white",
            outline: "border-2 border-border bg-surface"
        }
    },
    defaultVariants: {
        size: "md",
        variant: "default"
    }
});
const avatarImageVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("h-full w-full object-cover");
const avatarFallbackVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("font-semibold uppercase");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/hooks/useImageFallback.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useImageFallback",
    ()=>useImageFallback
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
"use client";
;
function useImageFallback() {
    _s();
    const [hasError, setHasError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const onError = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useImageFallback.useCallback[onError]": ()=>{
            setHasError(true);
        }
    }["useImageFallback.useCallback[onError]"], []);
    const resetError = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useImageFallback.useCallback[resetError]": ()=>{
            setHasError(false);
        }
    }["useImageFallback.useCallback[resetError]"], []);
    return {
        hasError,
        onError,
        resetError
    };
}
_s(useImageFallback, "l0GBkFhuVn2ScqikqusAUM11usc=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/atoms/Avatar/Avatar.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Avatar",
    ()=>Avatar
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/utils/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils/cn.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Avatar$2f$Avatar$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Avatar/Avatar.variants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useImageFallback$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/useImageFallback.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
const Avatar = /*#__PURE__*/ _s(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].forwardRef(_c = _s(({ className, src, alt, fallback, size, variant, ...props }, ref)=>{
    _s();
    const { hasError, onError } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useImageFallback$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useImageFallback"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Avatar$2f$Avatar$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["avatarVariants"])({
            size,
            variant
        }), className),
        ...props,
        children: src && !hasError ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
            src: src,
            alt: alt || "Avatar",
            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Avatar$2f$Avatar$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["avatarImageVariants"])()),
            onError: onError
        }, void 0, false, {
            fileName: "[project]/src/components/atoms/Avatar/Avatar.tsx",
            lineNumber: 33,
            columnNumber: 21
        }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Avatar$2f$Avatar$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["avatarFallbackVariants"])()),
            children: fallback || alt?.charAt(0) || "?"
        }, void 0, false, {
            fileName: "[project]/src/components/atoms/Avatar/Avatar.tsx",
            lineNumber: 40,
            columnNumber: 21
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/components/atoms/Avatar/Avatar.tsx",
        lineNumber: 27,
        columnNumber: 13
    }, ("TURBOPACK compile-time value", void 0));
}, "ttLfYgL07aNw5opSjyM0T8ZSrvM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useImageFallback$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useImageFallback"]
    ];
})), "ttLfYgL07aNw5opSjyM0T8ZSrvM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useImageFallback$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useImageFallback"]
    ];
});
_c1 = Avatar;
Avatar.displayName = "Avatar";
var _c, _c1;
__turbopack_context__.k.register(_c, "Avatar$React.forwardRef");
__turbopack_context__.k.register(_c1, "Avatar");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/atoms/Avatar/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
// ============================================================================
// AVATAR SYSTEM — Barrel export
// ============================================================================
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Avatar$2f$Avatar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Avatar/Avatar.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Avatar$2f$Avatar$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Avatar/Avatar.variants.ts [app-client] (ecmascript)");
;
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/molecules/StoreCard/StoreCard.variants.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "storeCardBadgeVariants",
    ()=>storeCardBadgeVariants,
    "storeCardEmprendedorBadgeVariants",
    ()=>storeCardEmprendedorBadgeVariants,
    "storeCardEmprendedorNameVariants",
    ()=>storeCardEmprendedorNameVariants,
    "storeCardFullContentVariants",
    ()=>storeCardFullContentVariants,
    "storeCardFullDescriptionVariants",
    ()=>storeCardFullDescriptionVariants,
    "storeCardFullFooterRowVariants",
    ()=>storeCardFullFooterRowVariants,
    "storeCardFullLinkVariants",
    ()=>storeCardFullLinkVariants,
    "storeCardFullLocationVariants",
    ()=>storeCardFullLocationVariants,
    "storeCardFullMediaVariants",
    ()=>storeCardFullMediaVariants,
    "storeCardFullTitleVariants",
    ()=>storeCardFullTitleVariants,
    "storeCardHeaderVariants",
    ()=>storeCardHeaderVariants,
    "storeCardImageVariants",
    ()=>storeCardImageVariants,
    "storeCardMinContentVariants",
    ()=>storeCardMinContentVariants,
    "storeCardMinDescriptionVariants",
    ()=>storeCardMinDescriptionVariants,
    "storeCardMinEmprendedorNameVariants",
    ()=>storeCardMinEmprendedorNameVariants,
    "storeCardMinFooterVariants",
    ()=>storeCardMinFooterVariants,
    "storeCardMinHeaderInfoVariants",
    ()=>storeCardMinHeaderInfoVariants,
    "storeCardMinLocationVariants",
    ()=>storeCardMinLocationVariants,
    "storeCardMinMediaVariants",
    ()=>storeCardMinMediaVariants,
    "storeCardMinTitleVariants",
    ()=>storeCardMinTitleVariants,
    "storeCardThumbnailGlassVariants",
    ()=>storeCardThumbnailGlassVariants,
    "storeCardThumbnailLocationVariants",
    ()=>storeCardThumbnailLocationVariants,
    "storeCardThumbnailTitleVariants",
    ()=>storeCardThumbnailTitleVariants,
    "storeCardVariants",
    ()=>storeCardVariants
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/class-variance-authority/dist/index.mjs [app-client] (ecmascript)");
;
const storeCardVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("relative overflow-hidden group cursor-pointer transition-all duration-500 ease-smooth", {
    variants: {
        variant: {
            "card-full": "h-full flex flex-col rounded-clay bg-muted-light shadow-clay",
            "card-min": "h-full flex flex-col rounded-clay bg-muted-light shadow-clay",
            "card-preview-max": "relative rounded-clay bg-surface shadow-clay h-full",
            "card-preview": "relative rounded-clay bg-surface shadow-clay h-full",
            "history-slot": "relative rounded-clay-sm bg-surface shadow-clay-sm grayscale opacity-60 hover:grayscale-0 hover:opacity-100 transition-all duration-300 h-full"
        }
    },
    defaultVariants: {
        variant: "card-preview"
    }
});
const storeCardHeaderVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("flex items-center gap-3 px-4 pt-4 pb-2 flex-shrink-0");
const storeCardFullMediaVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("flex-1 min-h-0 overflow-hidden");
const storeCardMinMediaVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("flex-1 min-h-0 overflow-hidden");
const storeCardEmprendedorBadgeVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("absolute z-30 top-4 right-4 flex items-center gap-2 bg-white/90 backdrop-blur-sm px-3 py-1.5 rounded-full");
const storeCardEmprendedorNameVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("text-xs font-semibold text-foreground");
const storeCardBadgeVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("absolute z-30 top-4 left-4");
const storeCardFullContentVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("px-5 pt-4 pb-5 flex-shrink-0 space-y-1");
const storeCardFullTitleVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("font-headline font-bold text-foreground text-lg md:text-3xl md:tracking-tight leading-tight truncate");
const storeCardFullDescriptionVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("hidden md:[display:-webkit-box] line-clamp-3 md:text-base md:text-foreground/80 md:leading-relaxed");
const storeCardFullFooterRowVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("flex items-center justify-between gap-2 pt-2");
const storeCardFullLinkVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("inline-flex items-center gap-1 font-body text-xs md:text-sm font-bold uppercase tracking-widest text-primary hover:text-primary-dim transition-all duration-300 group-hover:gap-2");
const storeCardFullLocationVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("font-body text-sm font-medium text-muted-foreground");
const storeCardMinHeaderInfoVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("flex-1 min-w-0");
const storeCardMinTitleVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("font-headline font-bold text-foreground text-sm leading-tight truncate");
const storeCardMinEmprendedorNameVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("truncate");
const storeCardMinContentVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("px-4 pt-2 pb-1 flex-shrink-0");
const storeCardMinDescriptionVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("line-clamp-1");
const storeCardMinFooterVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("px-4 pb-4 flex-shrink-0 flex items-center justify-between");
const storeCardMinLocationVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("font-body text-xs font-medium text-muted-foreground truncate");
const storeCardThumbnailGlassVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("absolute inset-x-0 bottom-0 bg-white/40 md:bg-white/70 backdrop-blur-xl border-t border-white/50 md:border-white/60 px-3 py-2.5 shadow-lg shadow-black/5 flex justify-between items-center");
const storeCardThumbnailTitleVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("font-headline font-bold text-secondary md:text-foreground md:font-black leading-tight truncate");
const storeCardThumbnailLocationVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("font-headline text-xs font-bold text-secondary truncate ml-2 max-w-[40%]");
const storeCardImageVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("w-full h-full object-cover transition-transform duration-700 group-hover:scale-105");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/molecules/StoreCard/StoreCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "StoreCard",
    ()=>StoreCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$m$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/render/components/m/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Avatar$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/components/atoms/Avatar/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Avatar$2f$Avatar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Avatar/Avatar.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Typography$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/components/atoms/Typography/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Typography$2f$Heading$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Typography/Heading.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Typography$2f$Text$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Typography/Text.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/arrow-right.js [app-client] (ecmascript) <export default as ArrowRight>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$map$2d$pin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MapPin$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/map-pin.js [app-client] (ecmascript) <export default as MapPin>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/utils/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils/cn.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$StoreCard$2f$StoreCard$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/molecules/StoreCard/StoreCard.variants.ts [app-client] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
const StoreCard = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = ({ store, variant = "card-preview", className, animate = true, onStoreClick }, ref)=>{
    const isHistory = variant === "history-slot";
    const storeHref = `https://jovenpro.com/store/${store.slug}/`;
    const CardWrapper = animate ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$m$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["m"].div : "div";
    const cardProps = animate ? {
        layoutId: `card-${store.id}`
    } : {};
    // FAMILIA A: card-full
    if (variant === "card-full") {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(CardWrapper, {
            ref: ref,
            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$StoreCard$2f$StoreCard$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["storeCardVariants"])({
                variant
            }), className),
            ...cardProps,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$StoreCard$2f$StoreCard$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["storeCardEmprendedorBadgeVariants"])(),
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Avatar$2f$Avatar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Avatar"], {
                            size: "sm",
                            src: store.emprendedor.avatar,
                            fallback: store.emprendedor.initials
                        }, void 0, false, {
                            fileName: "[project]/src/components/molecules/StoreCard/StoreCard.tsx",
                            lineNumber: 64,
                            columnNumber: 25
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$StoreCard$2f$StoreCard$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["storeCardEmprendedorNameVariants"])(),
                            children: store.emprendedor.name
                        }, void 0, false, {
                            fileName: "[project]/src/components/molecules/StoreCard/StoreCard.tsx",
                            lineNumber: 69,
                            columnNumber: 25
                        }, ("TURBOPACK compile-time value", void 0)),
                        store.emprendedor.verified && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "text-primary text-xs",
                            children: "✓"
                        }, void 0, false, {
                            fileName: "[project]/src/components/molecules/StoreCard/StoreCard.tsx",
                            lineNumber: 73,
                            columnNumber: 29
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/molecules/StoreCard/StoreCard.tsx",
                    lineNumber: 63,
                    columnNumber: 21
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$StoreCard$2f$StoreCard$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["storeCardFullMediaVariants"])(),
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                        src: store.image || "/images/placeholders/No-Image-Placeholder.webp",
                        alt: store.name,
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$StoreCard$2f$StoreCard$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["storeCardImageVariants"])(),
                        onError: (e)=>{
                            e.currentTarget.src = "/images/placeholders/No-Image-Placeholder.webp";
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/molecules/StoreCard/StoreCard.tsx",
                        lineNumber: 79,
                        columnNumber: 25
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/components/molecules/StoreCard/StoreCard.tsx",
                    lineNumber: 78,
                    columnNumber: 21
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$StoreCard$2f$StoreCard$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["storeCardFullContentVariants"])(),
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Typography$2f$Heading$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Heading"], {
                            level: "h4",
                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$StoreCard$2f$StoreCard$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["storeCardFullTitleVariants"])(),
                            children: store.name
                        }, void 0, false, {
                            fileName: "[project]/src/components/molecules/StoreCard/StoreCard.tsx",
                            lineNumber: 90,
                            columnNumber: 25
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Typography$2f$Text$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Text"], {
                            size: "sm",
                            variant: "muted",
                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("hidden md:block", (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$StoreCard$2f$StoreCard$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["storeCardFullDescriptionVariants"])()),
                            children: store.description
                        }, void 0, false, {
                            fileName: "[project]/src/components/molecules/StoreCard/StoreCard.tsx",
                            lineNumber: 93,
                            columnNumber: 25
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$StoreCard$2f$StoreCard$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["storeCardFullFooterRowVariants"])(),
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                    href: storeHref,
                                    target: "_blank",
                                    rel: "noopener noreferrer",
                                    onClick: (e)=>{
                                        if (onStoreClick) {
                                            e.preventDefault();
                                            onStoreClick(storeHref);
                                        }
                                    },
                                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$StoreCard$2f$StoreCard$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["storeCardFullLinkVariants"])(),
                                    children: [
                                        "Ver tienda ",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__["ArrowRight"], {
                                            className: "w-3 h-3"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/molecules/StoreCard/StoreCard.tsx",
                                            lineNumber: 110,
                                            columnNumber: 44
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/molecules/StoreCard/StoreCard.tsx",
                                    lineNumber: 98,
                                    columnNumber: 29
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center gap-1 text-muted-foreground",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$map$2d$pin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MapPin$3e$__["MapPin"], {
                                            className: "w-3 h-3"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/molecules/StoreCard/StoreCard.tsx",
                                            lineNumber: 114,
                                            columnNumber: 33
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$StoreCard$2f$StoreCard$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["storeCardFullLocationVariants"])(),
                                            children: store.location
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/molecules/StoreCard/StoreCard.tsx",
                                            lineNumber: 115,
                                            columnNumber: 33
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/molecules/StoreCard/StoreCard.tsx",
                                    lineNumber: 113,
                                    columnNumber: 29
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/molecules/StoreCard/StoreCard.tsx",
                            lineNumber: 97,
                            columnNumber: 25
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/molecules/StoreCard/StoreCard.tsx",
                    lineNumber: 89,
                    columnNumber: 21
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/molecules/StoreCard/StoreCard.tsx",
            lineNumber: 57,
            columnNumber: 17
        }, ("TURBOPACK compile-time value", void 0));
    }
    // FAMILIA A: card-min
    if (variant === "card-min") {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(CardWrapper, {
            ref: ref,
            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$StoreCard$2f$StoreCard$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["storeCardVariants"])({
                variant
            }), className),
            ...cardProps,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$StoreCard$2f$StoreCard$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["storeCardHeaderVariants"])(),
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Avatar$2f$Avatar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Avatar"], {
                            size: "sm",
                            src: store.emprendedor.avatar,
                            fallback: store.emprendedor.initials
                        }, void 0, false, {
                            fileName: "[project]/src/components/molecules/StoreCard/StoreCard.tsx",
                            lineNumber: 135,
                            columnNumber: 25
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$StoreCard$2f$StoreCard$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["storeCardMinHeaderInfoVariants"])(),
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Typography$2f$Heading$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Heading"], {
                                    level: "h4",
                                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$StoreCard$2f$StoreCard$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["storeCardMinTitleVariants"])(),
                                    children: store.name
                                }, void 0, false, {
                                    fileName: "[project]/src/components/molecules/StoreCard/StoreCard.tsx",
                                    lineNumber: 141,
                                    columnNumber: 29
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Typography$2f$Text$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Text"], {
                                    size: "xs",
                                    variant: "muted",
                                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$StoreCard$2f$StoreCard$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["storeCardMinEmprendedorNameVariants"])(),
                                    children: store.emprendedor.name
                                }, void 0, false, {
                                    fileName: "[project]/src/components/molecules/StoreCard/StoreCard.tsx",
                                    lineNumber: 144,
                                    columnNumber: 29
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/molecules/StoreCard/StoreCard.tsx",
                            lineNumber: 140,
                            columnNumber: 25
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/molecules/StoreCard/StoreCard.tsx",
                    lineNumber: 134,
                    columnNumber: 21
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$StoreCard$2f$StoreCard$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["storeCardMinMediaVariants"])(),
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                        src: store.image || "/images/placeholders/No-Image-Placeholder.webp",
                        alt: store.name,
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$StoreCard$2f$StoreCard$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["storeCardImageVariants"])(),
                        onError: (e)=>{
                            e.currentTarget.src = "/images/placeholders/No-Image-Placeholder.webp";
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/molecules/StoreCard/StoreCard.tsx",
                        lineNumber: 151,
                        columnNumber: 25
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/components/molecules/StoreCard/StoreCard.tsx",
                    lineNumber: 150,
                    columnNumber: 21
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$StoreCard$2f$StoreCard$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["storeCardMinContentVariants"])(),
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Typography$2f$Text$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Text"], {
                        size: "xs",
                        variant: "muted",
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$StoreCard$2f$StoreCard$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["storeCardMinDescriptionVariants"])(),
                        children: store.description
                    }, void 0, false, {
                        fileName: "[project]/src/components/molecules/StoreCard/StoreCard.tsx",
                        lineNumber: 162,
                        columnNumber: 25
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/components/molecules/StoreCard/StoreCard.tsx",
                    lineNumber: 161,
                    columnNumber: 21
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$StoreCard$2f$StoreCard$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["storeCardMinFooterVariants"])(),
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-1 text-muted-foreground ml-auto",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$map$2d$pin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MapPin$3e$__["MapPin"], {
                                className: "w-3 h-3"
                            }, void 0, false, {
                                fileName: "[project]/src/components/molecules/StoreCard/StoreCard.tsx",
                                lineNumber: 169,
                                columnNumber: 29
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$StoreCard$2f$StoreCard$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["storeCardMinLocationVariants"])(),
                                children: store.location
                            }, void 0, false, {
                                fileName: "[project]/src/components/molecules/StoreCard/StoreCard.tsx",
                                lineNumber: 170,
                                columnNumber: 29
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/molecules/StoreCard/StoreCard.tsx",
                        lineNumber: 168,
                        columnNumber: 25
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/components/molecules/StoreCard/StoreCard.tsx",
                    lineNumber: 167,
                    columnNumber: 21
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/molecules/StoreCard/StoreCard.tsx",
            lineNumber: 128,
            columnNumber: 17
        }, ("TURBOPACK compile-time value", void 0));
    }
    // FAMILIA B: Thumbnail Card (preview-max, preview, history)
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(CardWrapper, {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$StoreCard$2f$StoreCard$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["storeCardVariants"])({
            variant
        }), className),
        ...cardProps,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                src: store.image || "/images/placeholders/No-Image-Placeholder.webp",
                alt: store.name,
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$StoreCard$2f$StoreCard$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["storeCardImageVariants"])(), "absolute inset-0"),
                onError: (e)=>{
                    e.currentTarget.src = "/images/placeholders/No-Image-Placeholder.webp";
                }
            }, void 0, false, {
                fileName: "[project]/src/components/molecules/StoreCard/StoreCard.tsx",
                lineNumber: 186,
                columnNumber: 17
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$StoreCard$2f$StoreCard$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["storeCardThumbnailGlassVariants"])(),
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$StoreCard$2f$StoreCard$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["storeCardThumbnailTitleVariants"])(),
                        children: store.name
                    }, void 0, false, {
                        fileName: "[project]/src/components/molecules/StoreCard/StoreCard.tsx",
                        lineNumber: 195,
                        columnNumber: 21
                    }, ("TURBOPACK compile-time value", void 0)),
                    !isHistory && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$StoreCard$2f$StoreCard$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["storeCardThumbnailLocationVariants"])(),
                        children: store.location
                    }, void 0, false, {
                        fileName: "[project]/src/components/molecules/StoreCard/StoreCard.tsx",
                        lineNumber: 199,
                        columnNumber: 25
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/molecules/StoreCard/StoreCard.tsx",
                lineNumber: 194,
                columnNumber: 17
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/molecules/StoreCard/StoreCard.tsx",
        lineNumber: 181,
        columnNumber: 13
    }, ("TURBOPACK compile-time value", void 0));
});
_c1 = StoreCard;
StoreCard.displayName = "StoreCard";
var _c, _c1;
__turbopack_context__.k.register(_c, "StoreCard$forwardRef");
__turbopack_context__.k.register(_c1, "StoreCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/molecules/StoreCard/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$StoreCard$2f$StoreCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/molecules/StoreCard/StoreCard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$StoreCard$2f$StoreCard$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/molecules/StoreCard/StoreCard.variants.ts [app-client] (ecmascript)");
;
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/molecules/PaginationDots/PaginationDots.variants.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "paginationDotTooltipArrowVariants",
    ()=>paginationDotTooltipArrowVariants,
    "paginationDotTooltipVariants",
    ()=>paginationDotTooltipVariants,
    "paginationDotVariants",
    ()=>paginationDotVariants,
    "paginationDotWrapperVariants",
    ()=>paginationDotWrapperVariants,
    "paginationDotsContainerVariants",
    ()=>paginationDotsContainerVariants
]);
// ============================================================================
// PAGINATION DOTS VARIANTS — Molécula de paginación por puntos
// ============================================================================
// REFACTOR V3:
// - Nuevos CVA exportados para eliminar inline del .tsx:
//   • paginationDotWrapperVariants: "relative flex items-center justify-center"
//   • paginationDotTooltipVariants: tooltip de preview con posicionamiento,
//     colores, tipografía y animación
//   • paginationDotTooltipArrowVariants: flecha del tooltip
// - paginationDotVariants base: agregado "relative" (antes inline en button).
// - Tokens validados:
//   • bg-foreground, text-background: existen en paleta V3
//   • bg-surface-variant, hover:bg-border: existen
//   • animate-fade-in: definido en tailwind.config.ts
// - text-[10px]: patrón recurrente en el proyecto (Badge sm, Text overline).
//   Se mantiene como utilitario arbitrario aceptado para tamaños menores a xs.
// - Tipos derivados del CVA.
// ============================================================================
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/class-variance-authority/dist/index.mjs [app-client] (ecmascript)");
;
const paginationDotsContainerVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("flex items-center justify-center gap-2", {
    variants: {
        size: {
            compact: "gap-3",
            standard: "gap-2"
        }
    },
    defaultVariants: {
        size: "standard"
    }
});
const paginationDotVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("relative rounded-full transition-all duration-300 ease-smooth cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-primary/50", {
    variants: {
        active: {
            true: "bg-primary",
            false: "bg-muted-foreground/50 hover:bg-primary-dim"
        },
        size: {
            compact: "h-3 w-3",
            standard: "h-2"
        }
    },
    compoundVariants: [
        {
            active: true,
            size: "compact",
            class: "w-8"
        },
        {
            active: true,
            size: "standard",
            class: "w-6"
        },
        {
            active: false,
            size: "compact",
            class: "w-3"
        },
        {
            active: false,
            size: "standard",
            class: "w-2"
        }
    ],
    defaultVariants: {
        active: false,
        size: "standard"
    }
});
const paginationDotWrapperVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("relative flex items-center justify-center");
const paginationDotTooltipVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("absolute -top-12 left-1/2 -translate-x-1/2 z-50 px-3 py-1.5 rounded-lg bg-foreground text-background text-[10px] font-bold whitespace-nowrap shadow-xl pointer-events-none animate-fade-in");
const paginationDotTooltipArrowVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("absolute -bottom-1 left-1/2 -translate-x-1/2 w-2 h-2 bg-foreground rotate-45");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/molecules/PaginationDots/PaginationDots.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PaginationDots",
    ()=>PaginationDots
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/utils/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils/cn.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$PaginationDots$2f$PaginationDots$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/molecules/PaginationDots/PaginationDots.variants.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
// ============================================================================
// PAGINATION DOTS — Molécula de paginación por puntos
// ============================================================================
// REFACTOR V3:
// - Zero inline classes:
//   • "relative flex items-center justify-center" → paginationDotWrapperVariants
//   • Tooltip completo (posicionamiento, colores, tipografía, animación)
//     → paginationDotTooltipVariants
//   • Flecha del tooltip → paginationDotTooltipArrowVariants
//   • "relative" del button → agregado al base de paginationDotVariants
// - Tokens validados: bg-foreground, text-background, bg-surface-variant,
//   hover:bg-border, animate-fade-in. Todos existen en paleta V3.
// - Tipos importados desde .variants.ts (derivados del CVA).
// ============================================================================
"use client";
;
;
;
const PaginationDots = /*#__PURE__*/ _s((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = _s(({ size = "standard", currentOffset, onOffsetChange, total, currentIndex, previewLabels, className, ...props }, ref)=>{
    _s();
    const offsets = size === "compact" ? [
        -1,
        0,
        1
    ] : [
        -3,
        -2,
        -1,
        0,
        1,
        2,
        3
    ];
    const [hoveredOffset, setHoveredOffset] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$PaginationDots$2f$PaginationDots$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["paginationDotsContainerVariants"])({
            size
        }), className),
        role: "tablist",
        "aria-label": "Paginación de productos",
        ...props,
        children: offsets.map((offset)=>{
            const isActive = offset === currentOffset;
            const targetIndex = ((currentIndex + offset) % total + total) % total;
            const preview = previewLabels?.[offset];
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$PaginationDots$2f$PaginationDots$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["paginationDotWrapperVariants"])()),
                children: [
                    hoveredOffset === offset && preview && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$PaginationDots$2f$PaginationDots$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["paginationDotTooltipVariants"])()),
                        children: [
                            preview,
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$PaginationDots$2f$PaginationDots$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["paginationDotTooltipArrowVariants"])())
                            }, void 0, false, {
                                fileName: "[project]/src/components/molecules/PaginationDots/PaginationDots.tsx",
                                lineNumber: 86,
                                columnNumber: 37
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/molecules/PaginationDots/PaginationDots.tsx",
                        lineNumber: 84,
                        columnNumber: 33
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        role: "tab",
                        "aria-selected": isActive,
                        "aria-label": `Producto ${targetIndex + 1} de ${total}`,
                        onClick: ()=>onOffsetChange(offset),
                        onMouseEnter: ()=>setHoveredOffset(offset),
                        onMouseLeave: ()=>setHoveredOffset(null),
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$PaginationDots$2f$PaginationDots$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["paginationDotVariants"])({
                            active: isActive,
                            size
                        }))
                    }, void 0, false, {
                        fileName: "[project]/src/components/molecules/PaginationDots/PaginationDots.tsx",
                        lineNumber: 94,
                        columnNumber: 29
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, offset, true, {
                fileName: "[project]/src/components/molecules/PaginationDots/PaginationDots.tsx",
                lineNumber: 79,
                columnNumber: 25
            }, ("TURBOPACK compile-time value", void 0));
        })
    }, void 0, false, {
        fileName: "[project]/src/components/molecules/PaginationDots/PaginationDots.tsx",
        lineNumber: 62,
        columnNumber: 13
    }, ("TURBOPACK compile-time value", void 0));
}, "vK3hsf/irYgVKPzOWRDL3Ra7frw=")), "vK3hsf/irYgVKPzOWRDL3Ra7frw=");
_c1 = PaginationDots;
PaginationDots.displayName = "PaginationDots";
var _c, _c1;
__turbopack_context__.k.register(_c, "PaginationDots$forwardRef");
__turbopack_context__.k.register(_c1, "PaginationDots");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/molecules/PaginationDots/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
// ============================================================================
// PAGINATION DOTS SYSTEM — Barrel export
// ============================================================================
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$PaginationDots$2f$PaginationDots$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/molecules/PaginationDots/PaginationDots.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$PaginationDots$2f$PaginationDots$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/molecules/PaginationDots/PaginationDots.variants.ts [app-client] (ecmascript)");
;
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/atoms/BentoGrid/BentoGrid.variants.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "bentoGridVariants",
    ()=>bentoGridVariants,
    "bentoItemVariants",
    ()=>bentoItemVariants
]);
// ============================================================================
// BENTO GRID & ITEM VARIANTS — Sistema de layout unificado
// ============================================================================
// REFACTOR V4: Grid 16×9 para BentoCarousel
// - Layout carousel: usa clases CSS puras desde globals.css (bento-grid-v4)
// - Posiciones nombradas mapeadas a bento-slot-{position}
// - Nueva dimensión "type" para diferenciar producto / texto / control
// ============================================================================
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/class-variance-authority/dist/index.mjs [app-client] (ecmascript)");
;
const bentoGridVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("grid w-full", {
    variants: {
        layout: {
            standard: "gap-4 md:gap-6",
            carousel: "bento-grid-v4",
            news: "grid-cols-1 md:grid-cols-3 gap-6"
        },
        cols: {
            1: "grid-cols-1",
            2: "grid-cols-1 md:grid-cols-2",
            3: "grid-cols-1 md:grid-cols-2 lg:grid-cols-3",
            4: "grid-cols-1 md:grid-cols-2 lg:grid-cols-4",
            none: ""
        }
    },
    defaultVariants: {
        layout: "standard",
        cols: "none"
    }
});
const bentoItemVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("relative overflow-hidden rounded-clay transition-all duration-500 ease-smooth min-h-0 min-w-0", {
    variants: {
        position: {
            // ── Carousel V4: 16×9 grid ──
            "subtitle2": "bento-slot-subtitle2",
            "subtitle": "bento-slot-subtitle",
            "history-1": "bento-slot-history-1",
            "history-2": "bento-slot-history-2",
            "history-3": "bento-slot-history-3",
            "history-4": "bento-slot-history-4",
            "hero": "bento-slot-hero",
            "title": "bento-slot-title",
            "next": "bento-slot-next",
            "dots": "bento-slot-dots",
            "catalogo": "bento-slot-catalogo",
            "preview-2": "bento-slot-preview-2",
            "preview-1": "bento-slot-preview-1",
            "preview-max": "bento-slot-preview-max",
            // ── Legacy standard/news ──
            "featured": "col-span-1 md:col-span-2 row-span-2",
            "compact": "col-span-1"
        },
        type: {
            product: "bg-transparent shadow-clay",
            text: "bg-surface shadow-clay flex items-center justify-center text-center",
            control: "bg-primary/5 shadow-clay z-30 !overflow-visible w-full h-full flex items-center justify-center"
        },
        colSpan: {
            1: "col-span-1",
            2: "col-span-1 md:col-span-2",
            3: "col-span-1 md:col-span-3",
            full: "col-span-1 md:col-span-full"
        },
        rowSpan: {
            1: "row-span-1",
            2: "row-span-2",
            3: "row-span-3"
        },
        ratio: {
            large: "aspect-bento-large",
            small: "aspect-bento-small",
            vertical: "aspect-bento-vertical",
            square: "aspect-bento-square",
            portrait: "aspect-bento-portrait",
            auto: "aspect-auto h-full"
        },
        isHistory: {
            true: "grayscale opacity-50 transition-all duration-300 cursor-pointer hover:grayscale-0 hover:opacity-100",
            false: ""
        },
        background: {
            transparent: "bg-transparent",
            surface: "bg-surface shadow-clay",
            glass: "bg-white/40 backdrop-blur-xl border border-white/50",
            primary: "bg-primary",
            secondary: "bg-secondary/10",
            accent: "bg-accent/10",
            "surface-container": "bg-surface-container",
            "surface-container-low": "bg-surface-container-low"
        }
    },
    defaultVariants: {
        position: undefined,
        type: "product",
        background: "transparent",
        ratio: "auto",
        isHistory: false
    }
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/atoms/BentoGrid/BentoGrid.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BentoGrid",
    ()=>BentoGrid,
    "BentoItem",
    ()=>BentoItem
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
// ============================================================================
// BENTO GRID — Container + Item (ÁTOMO de layout)
// ============================================================================
// Sistema unificado de distribución bento.
// BentoGrid define el layout del grid (standard | carousel | news).
// BentoItem define la posición del slot dentro del grid.
// Ambos son átomos puros: sin lógica de negocio, sin estado, sin color semántico.
// ============================================================================
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/utils/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils/cn.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$BentoGrid$2f$BentoGrid$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/BentoGrid/BentoGrid.variants.ts [app-client] (ecmascript)");
;
;
;
;
const BentoGrid = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].forwardRef(_c = ({ className, layout, cols, children, ...props }, ref)=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$BentoGrid$2f$BentoGrid$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bentoGridVariants"])({
            layout,
            cols
        }), className),
        ...props,
        children: children
    }, void 0, false, {
        fileName: "[project]/src/components/atoms/BentoGrid/BentoGrid.tsx",
        lineNumber: 39,
        columnNumber: 13
    }, ("TURBOPACK compile-time value", void 0));
});
_c1 = BentoGrid;
BentoGrid.displayName = "BentoGrid";
const BentoItem = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].forwardRef(_c2 = ({ className, position, type, background, colSpan, rowSpan, ratio, isHistory, children, ...props }, ref)=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$BentoGrid$2f$BentoGrid$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bentoItemVariants"])({
            position,
            type,
            background,
            colSpan,
            rowSpan,
            ratio,
            isHistory
        }), className),
        ...props,
        children: children
    }, void 0, false, {
        fileName: "[project]/src/components/atoms/BentoGrid/BentoGrid.tsx",
        lineNumber: 90,
        columnNumber: 13
    }, ("TURBOPACK compile-time value", void 0));
});
_c3 = BentoItem;
BentoItem.displayName = "BentoItem";
var _c, _c1, _c2, _c3;
__turbopack_context__.k.register(_c, "BentoGrid$React.forwardRef");
__turbopack_context__.k.register(_c1, "BentoGrid");
__turbopack_context__.k.register(_c2, "BentoItem$React.forwardRef");
__turbopack_context__.k.register(_c3, "BentoItem");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/atoms/BentoGrid/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
// ============================================================================
// BENTO SYSTEM — Barrel export V4
// ============================================================================
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$BentoGrid$2f$BentoGrid$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/BentoGrid/BentoGrid.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$BentoGrid$2f$BentoGrid$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/BentoGrid/BentoGrid.variants.ts [app-client] (ecmascript)");
;
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/organisms/BentoCarousel/BentoCarousel.variants.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BENTO_DIRECTIONS",
    ()=>BENTO_DIRECTIONS,
    "BENTO_SLOTS",
    ()=>BENTO_SLOTS,
    "BENTO_SPRING",
    ()=>BENTO_SPRING,
    "bentoCarouselGridWrapperVariants",
    ()=>bentoCarouselGridWrapperVariants,
    "bentoCarouselHeaderVariants",
    ()=>bentoCarouselHeaderVariants,
    "bentoCarouselInfoVariants",
    ()=>bentoCarouselInfoVariants,
    "bentoCarouselLabelVariants",
    ()=>bentoCarouselLabelVariants,
    "bentoCarouselOverlineVariants",
    ()=>bentoCarouselOverlineVariants,
    "bentoPlaceholderVariants",
    ()=>bentoPlaceholderVariants
]);
// ============================================================================
// BENTO CAROUSEL VARIANTS — Organismo de carousel bento
// ============================================================================
// REFACTOR V4: Grid 16×9 para BentoCarousel
// - BENTO_SLOTS usa position (BentoItemPosition) en vez de gridClass
// - Eliminados CVA obsoletos: slot, controls, arrow, footer
// - bentoPlaceholderVariants se mantiene para slots vacíos
// ============================================================================
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/class-variance-authority/dist/index.mjs [app-client] (ecmascript)");
;
const bentoCarouselHeaderVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-12 md:mb-16");
const bentoCarouselOverlineVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("uppercase tracking-[0.2em] mb-3");
const bentoCarouselGridWrapperVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("");
const bentoPlaceholderVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("rounded-clay border-2 border-dashed border-surface-variant bg-surface-container/30", {
    variants: {
        isHistory: {
            true: "grayscale opacity-50",
            false: ""
        }
    },
    defaultVariants: {
        isHistory: false
    }
});
const bentoCarouselInfoVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("flex justify-center mt-4");
const bentoCarouselLabelVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("uppercase tracking-[0.15em] font-semibold");
const BENTO_SPRING = {
    type: "spring",
    stiffness: 300,
    damping: 30
};
const BENTO_DIRECTIONS = {
    next: {
        main: {
            enter: {
                x: 80,
                scale: 0.9,
                opacity: 0
            },
            exit: {
                x: -40,
                scale: 0.85,
                opacity: 0
            }
        },
        history: {
            enter: {
                y: -30,
                scale: 0.9,
                opacity: 0
            },
            exit: {
                y: 30,
                scale: 0.85,
                opacity: 0
            }
        }
    },
    prev: {
        main: {
            enter: {
                x: -80,
                scale: 0.9,
                opacity: 0
            },
            exit: {
                x: 40,
                scale: 0.85,
                opacity: 0
            }
        },
        history: {
            enter: {
                y: 30,
                scale: 0.9,
                opacity: 0
            },
            exit: {
                y: -30,
                scale: 0.85,
                opacity: 0
            }
        }
    }
};
const BENTO_SLOTS = [
    {
        id: "history-1",
        position: "history-1",
        variant: "history-slot",
        offset: -1,
        delay: 0.18,
        interactive: true
    },
    {
        id: "history-2",
        position: "history-2",
        variant: "history-slot",
        offset: -2,
        delay: 0.30,
        interactive: true
    },
    {
        id: "history-3",
        position: "history-3",
        variant: "history-slot",
        offset: -3,
        delay: 0.38,
        interactive: true
    },
    {
        id: "history-4",
        position: "history-4",
        variant: "history-slot",
        offset: -4,
        delay: 0.42,
        interactive: true
    },
    {
        id: "hero",
        position: "hero",
        variant: "card-full",
        offset: 0,
        delay: 0,
        interactive: true
    },
    {
        id: "next",
        position: "next",
        variant: "card-min",
        offset: 1,
        delay: 0.18,
        interactive: true
    },
    {
        id: "preview-max",
        position: "preview-max",
        variant: "card-preview-max",
        offset: 2,
        delay: 0.30,
        interactive: true
    },
    {
        id: "preview-1",
        position: "preview-1",
        variant: "card-preview",
        offset: 3,
        delay: 0.38,
        interactive: true
    },
    {
        id: "preview-2",
        position: "preview-2",
        variant: "card-preview",
        offset: 4,
        delay: 0.42,
        interactive: true
    }
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/organisms/BentoCarousel/BentoCarousel.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BentoCarousel",
    ()=>BentoCarousel
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$m$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/render/components/m/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/components/AnimatePresence/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$LazyMotion$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/components/LazyMotion/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$framer$2d$features$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/framer-features.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Container$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/components/atoms/Container/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Container$2f$Container$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Container/Container.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Typography$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/components/atoms/Typography/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Typography$2f$Heading$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Typography/Heading.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Typography$2f$Text$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Typography/Text.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Button$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/components/atoms/Button/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Button$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Button/Button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$StoreCard$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/components/molecules/StoreCard/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$StoreCard$2f$StoreCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/molecules/StoreCard/StoreCard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$PaginationDots$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/components/molecules/PaginationDots/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$PaginationDots$2f$PaginationDots$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/molecules/PaginationDots/PaginationDots.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$BentoGrid$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/components/atoms/BentoGrid/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$BentoGrid$2f$BentoGrid$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/BentoGrid/BentoGrid.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/utils/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils/cn.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useAppNavigation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/useAppNavigation.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Section$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/components/atoms/Section/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Section$2f$Section$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Section/Section.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$BentoCarousel$2f$BentoCarousel$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/organisms/BentoCarousel/BentoCarousel.variants.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
;
/* ============================================================
 * BentoCarousel — Refactor V4 | Grid 16×9
 * ============================================================ */ function wrapIndex(index, length) {
    return (index % length + length) % length;
}
function BentoCarousel({ stores, title = "Emprendedores", subtitle = "Propulsando nuevos talentos", className, interval = 4000, paginationSize = "standard", catalogHref = "https://jovenpro.com/tienda/" }) {
    _s();
    const [idx, setIdx] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [direction, setDirection] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("next");
    const [isHovered, setIsHovered] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isLocked, setIsLocked] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const intervalRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const touchStartX = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(0);
    const touchEndX = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(0);
    const { openExternal } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useAppNavigation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppNavigation"])();
    const safeStores = stores.length >= 9 ? stores : Array.from({
        length: Math.ceil(9 / stores.length)
    }, ()=>stores).flat().slice(0, Math.max(9, stores.length));
    const total = safeStores.length;
    const getItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "BentoCarousel.useCallback[getItem]": (offset)=>{
            if (total === 0) return null;
            return safeStores[wrapIndex(idx + offset, total)];
        }
    }["BentoCarousel.useCallback[getItem]"], [
        idx,
        total,
        safeStores
    ]);
    const navigate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "BentoCarousel.useCallback[navigate]": (dir, targetIdx)=>{
            if (isLocked || total === 0) return;
            setIsLocked(true);
            const newIdx = targetIdx !== undefined ? targetIdx : dir === "next" ? (idx + 1) % total : (idx - 1 + total) % total;
            setDirection(dir);
            queueMicrotask({
                "BentoCarousel.useCallback[navigate]": ()=>{
                    setIdx(newIdx);
                    setTimeout({
                        "BentoCarousel.useCallback[navigate]": ()=>setIsLocked(false)
                    }["BentoCarousel.useCallback[navigate]"], 600);
                }
            }["BentoCarousel.useCallback[navigate]"]);
        }
    }["BentoCarousel.useCallback[navigate]"], [
        idx,
        total,
        isLocked
    ]);
    const rotate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "BentoCarousel.useCallback[rotate]": (dir = "next")=>{
            navigate(dir);
        }
    }["BentoCarousel.useCallback[rotate]"], [
        navigate
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "BentoCarousel.useEffect": ()=>{
            if (!isHovered && total > 0 && !isLocked) {
                intervalRef.current = setInterval({
                    "BentoCarousel.useEffect": ()=>rotate("next")
                }["BentoCarousel.useEffect"], interval);
            }
            return ({
                "BentoCarousel.useEffect": ()=>{
                    if (intervalRef.current) clearInterval(intervalRef.current);
                }
            })["BentoCarousel.useEffect"];
        }
    }["BentoCarousel.useEffect"], [
        isHovered,
        rotate,
        interval,
        total,
        isLocked
    ]);
    const resetTimer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "BentoCarousel.useCallback[resetTimer]": ()=>{
            if (intervalRef.current) {
                clearInterval(intervalRef.current);
                intervalRef.current = null;
            }
            setTimeout({
                "BentoCarousel.useCallback[resetTimer]": ()=>{
                    if (!isHovered && total > 0 && !isLocked) {
                        intervalRef.current = setInterval({
                            "BentoCarousel.useCallback[resetTimer]": ()=>rotate("next")
                        }["BentoCarousel.useCallback[resetTimer]"], interval);
                    }
                }
            }["BentoCarousel.useCallback[resetTimer]"], 100);
        }
    }["BentoCarousel.useCallback[resetTimer]"], [
        isHovered,
        total,
        rotate,
        interval,
        isLocked
    ]);
    const handleSlotClick = (slotConfig)=>{
        const targetItem = getItem(slotConfig.offset);
        if (!targetItem) return;
        const targetIndex = safeStores.findIndex((p)=>p.id === targetItem.id);
        if (targetIndex === -1 || targetIndex === idx) return;
        const dir = targetIndex > idx ? "next" : "prev";
        navigate(dir, targetIndex);
        resetTimer();
    };
    const handleDotOffsetChange = (offset)=>{
        if (offset === 0) {
            resetTimer();
            return;
        }
        const newIdx = wrapIndex(idx + offset, total);
        const dir = offset > 0 ? "next" : "prev";
        navigate(dir, newIdx);
        resetTimer();
    };
    const handleTouchStart = (e)=>{
        touchStartX.current = e.changedTouches[0].screenX;
    };
    const handleTouchEnd = (e)=>{
        touchEndX.current = e.changedTouches[0].screenX;
        handleSwipe();
    };
    const handleSwipe = ()=>{
        if (touchEndX.current < touchStartX.current - 50) {
            rotate("next");
            resetTimer();
        }
        if (touchEndX.current > touchStartX.current + 50) {
            rotate("prev");
            resetTimer();
        }
    };
    const offsets = paginationSize === "compact" ? [
        -1,
        0,
        1
    ] : [
        -3,
        -2,
        -1,
        0,
        1,
        2,
        3
    ];
    const previewLabels = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useMemo({
        "BentoCarousel.useMemo[previewLabels]": ()=>{
            const labels = {};
            offsets.forEach({
                "BentoCarousel.useMemo[previewLabels]": (offset)=>{
                    const targetIdx = wrapIndex(idx + offset, total);
                    const store = safeStores[targetIdx];
                    labels[offset] = store ? `#${targetIdx + 1} · ${store.name}` : "";
                }
            }["BentoCarousel.useMemo[previewLabels]"]);
            return labels;
        }
    }["BentoCarousel.useMemo[previewLabels]"], [
        idx,
        total,
        safeStores,
        offsets
    ]);
    const renderSlot = (slot)=>{
        const item = getItem(slot.offset);
        const isHistory = slot.variant === "history-slot";
        const dir = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$BentoCarousel$2f$BentoCarousel$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BENTO_DIRECTIONS"][direction];
        const animations = isHistory ? dir.history : dir.main;
        const isHiddenOnMobile = [
            "history-2",
            "history-3",
            "history-4",
            "preview-1",
            "preview-2",
            "next"
        ].includes(slot.position);
        const isForcedVisibleOnMobile = [
            "history-1",
            "preview-max"
        ].includes(slot.position);
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$BentoGrid$2f$BentoGrid$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BentoItem"], {
            position: slot.position,
            type: "product",
            isHistory: isHistory,
            onClick: ()=>handleSlotClick(slot),
            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("cursor-pointer", isHiddenOnMobile && "hidden md:block", isForcedVisibleOnMobile && "!block md:!block aspect-square md:aspect-auto md:h-full", slot.position === "hero" && "h-[460px] md:h-full"),
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimatePresence"], {
                mode: "wait",
                initial: false,
                children: item ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$m$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["m"].div, {
                    initial: animations.enter,
                    animate: {
                        x: 0,
                        y: 0,
                        scale: 1,
                        opacity: 1
                    },
                    exit: animations.exit,
                    transition: {
                        ...__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$BentoCarousel$2f$BentoCarousel$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BENTO_SPRING"],
                        delay: slot.delay
                    },
                    className: "w-full h-full",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$StoreCard$2f$StoreCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StoreCard"], {
                        store: item,
                        variant: slot.variant,
                        animate: false,
                        onStoreClick: openExternal
                    }, void 0, false, {
                        fileName: "[project]/src/components/organisms/BentoCarousel/BentoCarousel.tsx",
                        lineNumber: 224,
                        columnNumber: 29
                    }, this)
                }, item.id, false, {
                    fileName: "[project]/src/components/organisms/BentoCarousel/BentoCarousel.tsx",
                    lineNumber: 213,
                    columnNumber: 25
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$m$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["m"].div, {
                    initial: {
                        opacity: 0
                    },
                    animate: {
                        opacity: 1
                    },
                    exit: {
                        opacity: 0
                    },
                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("w-full h-full", (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$BentoCarousel$2f$BentoCarousel$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bentoPlaceholderVariants"])({
                        isHistory
                    }))
                }, "placeholder", false, {
                    fileName: "[project]/src/components/organisms/BentoCarousel/BentoCarousel.tsx",
                    lineNumber: 232,
                    columnNumber: 25
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/organisms/BentoCarousel/BentoCarousel.tsx",
                lineNumber: 211,
                columnNumber: 17
            }, this)
        }, slot.id, false, {
            fileName: "[project]/src/components/organisms/BentoCarousel/BentoCarousel.tsx",
            lineNumber: 198,
            columnNumber: 13
        }, this);
    };
    const handleCatalogClick = ()=>{
        openExternal(catalogHref);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Section$2f$Section$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Section"], {
        id: "productos",
        spacing: "xl",
        background: "background",
        className: className,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Container$2f$Container$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Container"], {
            size: "xl",
            padding: "md",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$LazyMotion$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LazyMotion"], {
                    features: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$framer$2d$features$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
                    strict: true,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$BentoGrid$2f$BentoGrid$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BentoGrid"], {
                        layout: "carousel",
                        onMouseEnter: ()=>setIsHovered(true),
                        onMouseLeave: ()=>setIsHovered(false),
                        onTouchStart: handleTouchStart,
                        onTouchEnd: handleTouchEnd,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$BentoGrid$2f$BentoGrid$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BentoItem"], {
                                position: "subtitle2",
                                type: "text",
                                background: "transparent",
                                className: "hidden md:flex",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                    src: "/images/logo/JovenPro-by-ZonaPro.png",
                                    alt: "JovenPro by ZonaPro",
                                    className: "w-auto h-12 object-contain opacity-80"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/organisms/BentoCarousel/BentoCarousel.tsx",
                                    lineNumber: 265,
                                    columnNumber: 25
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/organisms/BentoCarousel/BentoCarousel.tsx",
                                lineNumber: 264,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$BentoGrid$2f$BentoGrid$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BentoItem"], {
                                position: "subtitle",
                                type: "text",
                                background: "primary",
                                className: "hidden md:flex",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Typography$2f$Text$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Text"], {
                                    variant: "inverted",
                                    size: "md",
                                    children: subtitle
                                }, void 0, false, {
                                    fileName: "[project]/src/components/organisms/BentoCarousel/BentoCarousel.tsx",
                                    lineNumber: 273,
                                    columnNumber: 25
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/organisms/BentoCarousel/BentoCarousel.tsx",
                                lineNumber: 272,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$BentoGrid$2f$BentoGrid$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BentoItem"], {
                                position: "title",
                                type: "text",
                                background: "primary",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Typography$2f$Heading$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Heading"], {
                                    level: "h3",
                                    className: "text-white",
                                    children: title
                                }, void 0, false, {
                                    fileName: "[project]/src/components/organisms/BentoCarousel/BentoCarousel.tsx",
                                    lineNumber: 282,
                                    columnNumber: 25
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/organisms/BentoCarousel/BentoCarousel.tsx",
                                lineNumber: 281,
                                columnNumber: 21
                            }, this),
                            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$BentoCarousel$2f$BentoCarousel$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BENTO_SLOTS"].map(renderSlot),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$BentoGrid$2f$BentoGrid$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BentoItem"], {
                                position: "dots",
                                type: "control",
                                background: "glass",
                                className: "hidden md:flex shadow-sm",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "w-full h-full flex flex-col items-center justify-center gap-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-xs uppercase tracking-widest font-bold text-foreground/50",
                                            children: "Navegar"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/organisms/BentoCarousel/BentoCarousel.tsx",
                                            lineNumber: 296,
                                            columnNumber: 29
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$PaginationDots$2f$PaginationDots$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PaginationDots"], {
                                            size: paginationSize,
                                            currentOffset: 0,
                                            onOffsetChange: handleDotOffsetChange,
                                            total: total,
                                            currentIndex: idx,
                                            previewLabels: previewLabels
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/organisms/BentoCarousel/BentoCarousel.tsx",
                                            lineNumber: 297,
                                            columnNumber: 29
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/organisms/BentoCarousel/BentoCarousel.tsx",
                                    lineNumber: 295,
                                    columnNumber: 25
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/organisms/BentoCarousel/BentoCarousel.tsx",
                                lineNumber: 294,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$BentoGrid$2f$BentoGrid$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BentoItem"], {
                                position: "catalogo",
                                type: "control",
                                background: "glass",
                                className: "shadow-xl shadow-primary/20",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "w-full h-full flex items-center justify-center",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Button$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                        asChild: true,
                                        variant: "primary",
                                        size: "md",
                                        className: "w-full sm:w-auto",
                                        onClick: handleCatalogClick,
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                            href: catalogHref,
                                            target: "_blank",
                                            rel: "noopener noreferrer",
                                            children: "Ver catálogo"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/organisms/BentoCarousel/BentoCarousel.tsx",
                                            lineNumber: 317,
                                            columnNumber: 33
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/organisms/BentoCarousel/BentoCarousel.tsx",
                                        lineNumber: 310,
                                        columnNumber: 29
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/organisms/BentoCarousel/BentoCarousel.tsx",
                                    lineNumber: 309,
                                    columnNumber: 25
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/organisms/BentoCarousel/BentoCarousel.tsx",
                                lineNumber: 308,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/organisms/BentoCarousel/BentoCarousel.tsx",
                        lineNumber: 256,
                        columnNumber: 21
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/organisms/BentoCarousel/BentoCarousel.tsx",
                    lineNumber: 255,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$BentoCarousel$2f$BentoCarousel$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bentoCarouselInfoVariants"])(),
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Typography$2f$Text$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Text"], {
                        size: "xs",
                        variant: "muted",
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$BentoCarousel$2f$BentoCarousel$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bentoCarouselLabelVariants"])(),
                        children: [
                            "Tienda ",
                            idx + 1,
                            " de ",
                            total
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/organisms/BentoCarousel/BentoCarousel.tsx",
                        lineNumber: 332,
                        columnNumber: 21
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/organisms/BentoCarousel/BentoCarousel.tsx",
                    lineNumber: 331,
                    columnNumber: 17
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/organisms/BentoCarousel/BentoCarousel.tsx",
            lineNumber: 254,
            columnNumber: 13
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/organisms/BentoCarousel/BentoCarousel.tsx",
        lineNumber: 253,
        columnNumber: 9
    }, this);
}
_s(BentoCarousel, "YD+dYqqE7GfqtRDKeB6XnDoEEYA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useAppNavigation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppNavigation"]
    ];
});
_c = BentoCarousel;
var _c;
__turbopack_context__.k.register(_c, "BentoCarousel");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/atoms/Badge/Badge.variants.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "badgeVariants",
    ()=>badgeVariants,
    "dotVariants",
    ()=>dotVariants,
    "indicatorVariants",
    ()=>indicatorVariants,
    "pingVariants",
    ()=>pingVariants
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/class-variance-authority/dist/index.mjs [app-client] (ecmascript)");
;
const badgeVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("inline-flex items-center gap-2 font-black transition-all", {
    variants: {
        variant: {
            default: [
                "bg-surface text-secondary shadow-clay-sm"
            ],
            primary: [
                "bg-primary-subtle text-primary-dim",
                "shadow-clay-sm",
                "border border-primary/20"
            ],
            secondary: [
                "bg-surface-variant text-secondary",
                "shadow-clay-sm",
                "border border-secondary/20"
            ],
            success: [
                "bg-success-subtle text-success shadow-none"
            ],
            danger: [
                "bg-danger text-white shadow-lg shadow-danger/30"
            ],
            warning: [
                "bg-warning-subtle text-warning shadow-none"
            ],
            glass: [
                "bg-white/40 backdrop-blur-xl border border-white/50 text-secondary",
                "shadow-lg shadow-black/5"
            ],
            skeleton: [
                "bg-white/20 backdrop-blur-md border border-white/30",
                "shadow-inner shadow-white/40",
                "animate-pulse cursor-wait",
                "text-transparent select-none"
            ],
            new: [
                "bg-success-subtle text-success",
                "shadow-clay-sm",
                "border border-success/50"
            ],
            sale: [
                "bg-accent-subtle text-secondary",
                "shadow-clay-sm",
                "border border-accent/50"
            ],
            featured: [
                "bg-accent-subtle text-secondary",
                "shadow-clay-sm",
                "border border-accent/50"
            ]
        },
        size: {
            sm: "px-2 py-1 text-[10px] rounded-full",
            md: "px-3 py-1.5 text-xs rounded-full",
            lg: "px-6 py-3 text-sm rounded-clay",
            xl: "px-2 py-1 text-[10px] rounded-full"
        },
        uppercase: {
            true: "uppercase tracking-[0.2em]",
            false: "normal-case tracking-normal"
        },
        indicator: {
            true: "pl-2",
            false: ""
        }
    },
    defaultVariants: {
        variant: "default",
        size: "md",
        uppercase: true,
        indicator: false
    }
});
const indicatorVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("relative flex h-2 w-2", {
    variants: {
        color: {
            primary: "",
            secondary: "",
            danger: "",
            success: ""
        }
    },
    defaultVariants: {
        color: "primary"
    }
});
const pingVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("animate-ping absolute inline-flex h-full w-full rounded-full opacity-75", {
    variants: {
        color: {
            primary: "bg-primary",
            secondary: "bg-secondary",
            danger: "bg-danger",
            success: "bg-success"
        }
    },
    defaultVariants: {
        color: "primary"
    }
});
const dotVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("relative inline-flex rounded-full h-2 w-2", {
    variants: {
        color: {
            primary: "bg-primary",
            secondary: "bg-secondary",
            danger: "bg-danger",
            success: "bg-success"
        }
    },
    defaultVariants: {
        color: "primary"
    }
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/atoms/Badge/Badge.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Badge",
    ()=>Badge
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Badge$2f$Badge$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Badge/Badge.variants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/utils/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils/cn.ts [app-client] (ecmascript)");
;
;
;
;
const StatusIndicator = ({ color })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Badge$2f$Badge$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["indicatorVariants"])({
            color
        })),
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Badge$2f$Badge$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pingVariants"])({
                    color
                }))
            }, void 0, false, {
                fileName: "[project]/src/components/atoms/Badge/Badge.tsx",
                lineNumber: 26,
                columnNumber: 13
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Badge$2f$Badge$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dotVariants"])({
                    color
                }))
            }, void 0, false, {
                fileName: "[project]/src/components/atoms/Badge/Badge.tsx",
                lineNumber: 27,
                columnNumber: 13
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/atoms/Badge/Badge.tsx",
        lineNumber: 25,
        columnNumber: 9
    }, ("TURBOPACK compile-time value", void 0));
};
_c = StatusIndicator;
const Badge = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].forwardRef(_c1 = ({ className, variant = "default", size = "md", uppercase = true, indicator = false, indicatorColor = "primary", indicatorPosition = "left", children, ...props }, ref)=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Badge$2f$Badge$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["badgeVariants"])({
            variant,
            size,
            uppercase,
            indicator
        }), className),
        ref: ref,
        ...props,
        children: [
            indicator && indicatorPosition === "left" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(StatusIndicator, {
                color: indicatorColor
            }, void 0, false, {
                fileName: "[project]/src/components/atoms/Badge/Badge.tsx",
                lineNumber: 62,
                columnNumber: 21
            }, ("TURBOPACK compile-time value", void 0)),
            children,
            indicator && indicatorPosition === "right" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(StatusIndicator, {
                color: indicatorColor
            }, void 0, false, {
                fileName: "[project]/src/components/atoms/Badge/Badge.tsx",
                lineNumber: 66,
                columnNumber: 21
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/atoms/Badge/Badge.tsx",
        lineNumber: 48,
        columnNumber: 13
    }, ("TURBOPACK compile-time value", void 0));
});
_c2 = Badge;
Badge.displayName = "Badge";
;
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "StatusIndicator");
__turbopack_context__.k.register(_c1, "Badge$React.forwardRef");
__turbopack_context__.k.register(_c2, "Badge");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/atoms/Badge/BadgeSkeleton.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BadgeSkeleton",
    ()=>BadgeSkeleton
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
// components/atoms/Badge/BadgeSkeleton.tsx
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Badge$2f$Badge$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Badge/Badge.variants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/utils/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils/cn.ts [app-client] (ecmascript)");
;
;
;
function BadgeSkeleton({ variant = "skeleton", size = "md", indicator = false, className }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Badge$2f$Badge$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["badgeVariants"])({
            variant,
            size,
            uppercase: true,
            indicator
        }), "skeleton-pulse border-transparent shadow-none text-transparent pointer-events-none select-none", className),
        "aria-hidden": "true"
    }, void 0, false, {
        fileName: "[project]/src/components/atoms/Badge/BadgeSkeleton.tsx",
        lineNumber: 20,
        columnNumber: 5
    }, this);
}
_c = BadgeSkeleton;
var _c;
__turbopack_context__.k.register(_c, "BadgeSkeleton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/atoms/Badge/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
// ============================================================================
// BADGE SYSTEM — Barrel export
// ============================================================================
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Badge$2f$Badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Badge/Badge.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Badge$2f$Badge$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Badge/Badge.variants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Badge$2f$BadgeSkeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Badge/BadgeSkeleton.tsx [app-client] (ecmascript)");
;
;
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/molecules/NewsCard/NewsCard.variants.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "newsCardBadgePositionVariants",
    ()=>newsCardBadgePositionVariants,
    "newsCardCategoryBadgeVariants",
    ()=>newsCardCategoryBadgeVariants,
    "newsCardContentVariants",
    ()=>newsCardContentVariants,
    "newsCardExcerptVariants",
    ()=>newsCardExcerptVariants,
    "newsCardImageVariants",
    ()=>newsCardImageVariants,
    "newsCardLinkIconVariants",
    ()=>newsCardLinkIconVariants,
    "newsCardLinkVariants",
    ()=>newsCardLinkVariants,
    "newsCardMediaVariants",
    ()=>newsCardMediaVariants,
    "newsCardMetaDotVariants",
    ()=>newsCardMetaDotVariants,
    "newsCardMetaVariants",
    ()=>newsCardMetaVariants,
    "newsCardTitleVariants",
    ()=>newsCardTitleVariants,
    "newsCardVariants",
    ()=>newsCardVariants
]);
// ============================================================================
// NEWS CARD VARIANTS — Molécula de tarjeta de noticia
// ============================================================================
// REFACTOR V3:
// - Variantes: featured (hero grande) | preview (horizontal compacto)
// - Muy parecido a ProductCard pero con estructura de noticia
// - Preview en horizontal (imagen lateral + contenido)
// - Tokens fantasmas eliminados:
//   • text-jp-navy → text-secondary
//   • text-jp-sky → text-primary
//   • text-jp-text-secondary → text-muted-foreground
// ============================================================================
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/class-variance-authority/dist/index.mjs [app-client] (ecmascript)");
;
const newsCardVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("group cursor-pointer rounded-2xl overflow-hidden bg-white border border-border/30 transition-all duration-500 ease-smooth hover:shadow-clay-active", {
    variants: {
        variant: {
            featured: "flex flex-col h-full",
            preview: "flex flex-row h-full"
        }
    },
    defaultVariants: {
        variant: "featured"
    }
});
const newsCardMediaVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("relative overflow-hidden", {
    variants: {
        variant: {
            featured: "h-72 sm:h-96 flex-shrink-0",
            preview: "w-2/5 flex-shrink-0"
        }
    },
    defaultVariants: {
        variant: "featured"
    }
});
const newsCardImageVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("w-full h-full object-cover transition-transform duration-700 group-hover:scale-105");
const newsCardBadgePositionVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("absolute top-4 left-4 z-10");
const newsCardContentVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("flex flex-col", {
    variants: {
        variant: {
            featured: "p-8 flex-1 justify-between",
            preview: "w-3/5 p-6 justify-center"
        }
    },
    defaultVariants: {
        variant: "featured"
    }
});
const newsCardMetaVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("flex items-center gap-3 mb-3 text-sm text-muted-foreground");
const newsCardMetaDotVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("w-1 h-1 rounded-full bg-border");
const newsCardTitleVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("font-headline font-bold text-secondary group-hover:text-primary transition-colors", {
    variants: {
        variant: {
            featured: "text-2xl mb-3",
            preview: "text-base leading-tight mb-2"
        }
    },
    defaultVariants: {
        variant: "featured"
    }
});
const newsCardExcerptVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("font-body text-muted-foreground leading-relaxed", {
    variants: {
        variant: {
            featured: "text-sm",
            preview: "text-xs line-clamp-2"
        }
    },
    defaultVariants: {
        variant: "featured"
    }
});
const newsCardLinkVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("inline-flex items-center gap-1 font-body font-semibold text-secondary group-hover:text-primary group-hover:gap-2 transition-all", {
    variants: {
        variant: {
            featured: "mt-6 text-xs uppercase tracking-wider",
            preview: "mt-3 text-xs hover:underline"
        }
    },
    defaultVariants: {
        variant: "featured"
    }
});
const newsCardLinkIconVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("w-4 h-4");
const newsCardCategoryBadgeVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("mb-2 w-max");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/molecules/NewsCard/NewsCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "NewsCard",
    ()=>NewsCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Badge$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/components/atoms/Badge/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Badge$2f$Badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Badge/Badge.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$up$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowUpRight$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/arrow-up-right.js [app-client] (ecmascript) <export default as ArrowUpRight>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Clock$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/clock.js [app-client] (ecmascript) <export default as Clock>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Calendar$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/calendar.js [app-client] (ecmascript) <export default as Calendar>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/utils/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils/cn.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$NewsCard$2f$NewsCard$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/molecules/NewsCard/NewsCard.variants.ts [app-client] (ecmascript)");
// ============================================================================
// NEWS CARD — Molécula de tarjeta de noticia
// ============================================================================
// - Zero Inline Policy
// - Consumo de átomos: Badge, Text (implícito via variantes)
// ============================================================================
"use client";
;
;
;
;
;
;
const NewsCard = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = ({ data, variant = "featured", className, onClick }, ref)=>{
    const isFeatured = variant === "featured";
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("article", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$NewsCard$2f$NewsCard$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["newsCardVariants"])({
            variant
        }), className),
        onClick: onClick,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$NewsCard$2f$NewsCard$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["newsCardMediaVariants"])({
                    variant
                }),
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                        src: data.image,
                        alt: data.title,
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$NewsCard$2f$NewsCard$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["newsCardImageVariants"])()
                    }, void 0, false, {
                        fileName: "[project]/src/components/molecules/NewsCard/NewsCard.tsx",
                        lineNumber: 60,
                        columnNumber: 21
                    }, ("TURBOPACK compile-time value", void 0)),
                    isFeatured && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$NewsCard$2f$NewsCard$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["newsCardBadgePositionVariants"])(),
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Badge$2f$Badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Badge"], {
                            variant: "primary",
                            size: "md",
                            children: data.category
                        }, void 0, false, {
                            fileName: "[project]/src/components/molecules/NewsCard/NewsCard.tsx",
                            lineNumber: 67,
                            columnNumber: 29
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/src/components/molecules/NewsCard/NewsCard.tsx",
                        lineNumber: 66,
                        columnNumber: 25
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/molecules/NewsCard/NewsCard.tsx",
                lineNumber: 59,
                columnNumber: 17
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$NewsCard$2f$NewsCard$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["newsCardContentVariants"])({
                    variant
                }),
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            isFeatured && data.date && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$NewsCard$2f$NewsCard$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["newsCardMetaVariants"])(),
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "flex items-center gap-1",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Calendar$3e$__["Calendar"], {
                                                className: "w-4 h-4"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/molecules/NewsCard/NewsCard.tsx",
                                                lineNumber: 81,
                                                columnNumber: 37
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            data.date
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/molecules/NewsCard/NewsCard.tsx",
                                        lineNumber: 80,
                                        columnNumber: 33
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$NewsCard$2f$NewsCard$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["newsCardMetaDotVariants"])()
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/molecules/NewsCard/NewsCard.tsx",
                                        lineNumber: 84,
                                        columnNumber: 33
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "flex items-center gap-1",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Clock$3e$__["Clock"], {
                                                className: "w-4 h-4"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/molecules/NewsCard/NewsCard.tsx",
                                                lineNumber: 86,
                                                columnNumber: 37
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            data.readTime
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/molecules/NewsCard/NewsCard.tsx",
                                        lineNumber: 85,
                                        columnNumber: 33
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/molecules/NewsCard/NewsCard.tsx",
                                lineNumber: 79,
                                columnNumber: 29
                            }, ("TURBOPACK compile-time value", void 0)),
                            !isFeatured && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$NewsCard$2f$NewsCard$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["newsCardCategoryBadgeVariants"])(),
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Badge$2f$Badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Badge"], {
                                    variant: "default",
                                    size: "sm",
                                    children: data.category
                                }, void 0, false, {
                                    fileName: "[project]/src/components/molecules/NewsCard/NewsCard.tsx",
                                    lineNumber: 95,
                                    columnNumber: 33
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/src/components/molecules/NewsCard/NewsCard.tsx",
                                lineNumber: 94,
                                columnNumber: 29
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$NewsCard$2f$NewsCard$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["newsCardTitleVariants"])({
                                    variant
                                }),
                                children: data.title
                            }, void 0, false, {
                                fileName: "[project]/src/components/molecules/NewsCard/NewsCard.tsx",
                                lineNumber: 101,
                                columnNumber: 25
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$NewsCard$2f$NewsCard$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["newsCardExcerptVariants"])({
                                    variant
                                }),
                                children: data.excerpt
                            }, void 0, false, {
                                fileName: "[project]/src/components/molecules/NewsCard/NewsCard.tsx",
                                lineNumber: 105,
                                columnNumber: 25
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/molecules/NewsCard/NewsCard.tsx",
                        lineNumber: 76,
                        columnNumber: 21
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$NewsCard$2f$NewsCard$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["newsCardLinkVariants"])({
                            variant
                        }),
                        children: [
                            isFeatured ? "Leer artículo" : "Leer más",
                            isFeatured && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$up$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowUpRight$3e$__["ArrowUpRight"], {
                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$NewsCard$2f$NewsCard$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["newsCardLinkIconVariants"])()
                            }, void 0, false, {
                                fileName: "[project]/src/components/molecules/NewsCard/NewsCard.tsx",
                                lineNumber: 113,
                                columnNumber: 29
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/molecules/NewsCard/NewsCard.tsx",
                        lineNumber: 110,
                        columnNumber: 21
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/molecules/NewsCard/NewsCard.tsx",
                lineNumber: 75,
                columnNumber: 17
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/molecules/NewsCard/NewsCard.tsx",
        lineNumber: 53,
        columnNumber: 13
    }, ("TURBOPACK compile-time value", void 0));
});
_c1 = NewsCard;
NewsCard.displayName = "NewsCard";
var _c, _c1;
__turbopack_context__.k.register(_c, "NewsCard$forwardRef");
__turbopack_context__.k.register(_c1, "NewsCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/molecules/NewsCard/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
// ============================================================================
// NEWS CARD SYSTEM — Barrel export
// ============================================================================
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$NewsCard$2f$NewsCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/molecules/NewsCard/NewsCard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$NewsCard$2f$NewsCard$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/molecules/NewsCard/NewsCard.variants.ts [app-client] (ecmascript)");
;
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/organisms/NewsSection/NewsSection.variants.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "NEWS_DIRECTIONS",
    ()=>NEWS_DIRECTIONS,
    "NEWS_SLOTS",
    ()=>NEWS_SLOTS,
    "NEWS_SPRING",
    ()=>NEWS_SPRING,
    "newsSectionGridVariants",
    ()=>newsSectionGridVariants,
    "newsSectionHeaderVariants",
    ()=>newsSectionHeaderVariants,
    "newsSectionMobileCardVariants",
    ()=>newsSectionMobileCardVariants,
    "newsSectionMobileContentVariants",
    ()=>newsSectionMobileContentVariants,
    "newsSectionMobileItemVariants",
    ()=>newsSectionMobileItemVariants,
    "newsSectionMobileMediaVariants",
    ()=>newsSectionMobileMediaVariants,
    "newsSectionMobileScrollVariants",
    ()=>newsSectionMobileScrollVariants,
    "newsSectionPaginationVariants",
    ()=>newsSectionPaginationVariants,
    "newsSectionSlotVariants",
    ()=>newsSectionSlotVariants,
    "newsSectionSubtitleVariants",
    ()=>newsSectionSubtitleVariants,
    "newsSectionTitleVariants",
    ()=>newsSectionTitleVariants,
    "newsSectionVariants",
    ()=>newsSectionVariants
]);
// ============================================================================
// NEWS SECTION VARIANTS — Organismo de sección de noticias
// ============================================================================
// REFACTOR V3:
// - Grid CSS custom 6×6 via globals.css (layout puro)
// - NewsCard como molécula base
// - Zero Inline Policy
// ============================================================================
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/class-variance-authority/dist/index.mjs [app-client] (ecmascript)");
;
const newsSectionVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("py-24 md:py-32 bg-surface-container-low");
const newsSectionHeaderVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("mb-12 md:mb-16");
const newsSectionTitleVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("mb-4");
const newsSectionSubtitleVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("");
const newsSectionGridVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("news-grid-container hidden md:grid");
const newsSectionSlotVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("news-slot", {
    variants: {
        position: {
            featured: "",
            "preview-1": "",
            "preview-2": "",
            "preview-3": ""
        }
    },
    defaultVariants: {
        position: "featured"
    }
});
const newsSectionPaginationVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("flex justify-center mt-10 hidden md:flex");
const newsSectionMobileScrollVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("md:hidden flex overflow-x-auto snap-x snap-mandatory gap-4 pb-4 -mx-4 px-4 hide-scrollbar");
const newsSectionMobileItemVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("snap-center shrink-0 w-[80vw] max-w-xs");
const newsSectionMobileCardVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("group cursor-pointer rounded-2xl overflow-hidden bg-white border border-border/30 flex flex-col");
const newsSectionMobileMediaVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("h-56 overflow-hidden relative");
const newsSectionMobileContentVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("p-6");
const NEWS_SPRING = {
    type: "spring",
    stiffness: 300,
    damping: 30
};
const NEWS_DIRECTIONS = {
    up: {
        enter: {
            y: 60,
            opacity: 0
        },
        exit: {
            y: -60,
            opacity: 0
        }
    },
    down: {
        enter: {
            y: -60,
            opacity: 0
        },
        exit: {
            y: 60,
            opacity: 0
        }
    }
};
const NEWS_SLOTS = [
    {
        id: "featured",
        variant: "featured",
        offset: 0,
        delay: 0,
        gridClass: "news-slot-featured"
    },
    {
        id: "preview-1",
        variant: "preview-1",
        offset: 1,
        delay: 0.1,
        gridClass: "news-slot-preview-1"
    },
    {
        id: "preview-2",
        variant: "preview-2",
        offset: 2,
        delay: 0.15,
        gridClass: "news-slot-preview-2"
    },
    {
        id: "preview-3",
        variant: "preview-3",
        offset: 3,
        delay: 0.2,
        gridClass: "news-slot-preview-3"
    }
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/organisms/NewsSection/NewsSection.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "NewsSection",
    ()=>NewsSection
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$m$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/render/components/m/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/components/AnimatePresence/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$LazyMotion$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/components/LazyMotion/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$framer$2d$features$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/framer-features.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Typography$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/components/atoms/Typography/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Typography$2f$Heading$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Typography/Heading.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Typography$2f$Text$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Typography/Text.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Container$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/components/atoms/Container/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Container$2f$Container$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Container/Container.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Badge$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/components/atoms/Badge/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Badge$2f$Badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Badge/Badge.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$NewsCard$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/components/molecules/NewsCard/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$NewsCard$2f$NewsCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/molecules/NewsCard/NewsCard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$PaginationDots$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/components/molecules/PaginationDots/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$PaginationDots$2f$PaginationDots$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/molecules/PaginationDots/PaginationDots.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/utils/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils/cn.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Section$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/components/atoms/Section/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Section$2f$Section$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Section/Section.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$NewsSection$2f$NewsSection$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/organisms/NewsSection/NewsSection.variants.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
function NewsSection({ items, title = "Actualidades", subtitle = "Conoce las últimas novedades y eventos de JovenPro", className, onReadArticle }) {
    _s();
    const [currentPage, setCurrentPage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [localIndex, setLocalIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const itemsPerPage = 4;
    const totalPages = Math.ceil(items.length / itemsPerPage);
    const paginatedItems = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "NewsSection.useMemo[paginatedItems]": ()=>{
            const start = currentPage * itemsPerPage;
            return items.slice(start, start + itemsPerPage);
        }
    }["NewsSection.useMemo[paginatedItems]"], [
        items,
        currentPage
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "NewsSection.useEffect": ()=>{
            setLocalIndex(0);
        }
    }["NewsSection.useEffect"], [
        currentPage
    ]);
    const getItem = (offset)=>{
        if (paginatedItems.length === 0) return null;
        return paginatedItems[(localIndex + offset) % paginatedItems.length];
    };
    const handleReadArticle = (href)=>{
        const url = href || "#";
        if (onReadArticle) {
            onReadArticle(url);
        } else {
            window.open(url, "_blank", "noopener,noreferrer");
        }
    };
    const handleSlotClick = (slot)=>{
        if (slot.offset === 0) {
            const item = getItem(0);
            if (item) handleReadArticle(item.href);
        } else {
            setLocalIndex((prev)=>(prev + slot.offset) % paginatedItems.length);
        }
    };
    const handleDotOffsetChange = (offset)=>{
        if (offset === 0) return;
        const newPage = currentPage + (offset > 0 ? 1 : -1);
        setCurrentPage(Math.max(0, Math.min(newPage, totalPages - 1)));
    };
    const previewLabels = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useMemo({
        "NewsSection.useMemo[previewLabels]": ()=>{
            const labels = {};
            for(let i = -1; i <= 1; i++){
                const page = currentPage + i;
                if (page >= 0 && page < totalPages) {
                    labels[i] = `Página ${page + 1} de ${totalPages}`;
                }
            }
            return labels;
        }
    }["NewsSection.useMemo[previewLabels]"], [
        currentPage,
        totalPages
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Section$2f$Section$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Section"], {
        id: "journal",
        spacing: "md",
        background: "transparent",
        className: className,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Container$2f$Container$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Container"], {
            size: "lg",
            padding: "md",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$LazyMotion$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LazyMotion"], {
                    features: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$framer$2d$features$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
                    strict: true,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$NewsSection$2f$NewsSection$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["newsSectionHeaderVariants"])(),
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$m$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["m"].div, {
                                    initial: {
                                        opacity: 0,
                                        y: 20
                                    },
                                    whileInView: {
                                        opacity: 1,
                                        y: 0
                                    },
                                    viewport: {
                                        once: true,
                                        margin: "-100px"
                                    },
                                    transition: {
                                        duration: 0.6,
                                        ease: [
                                            0.25,
                                            1,
                                            0.5,
                                            1
                                        ]
                                    },
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Typography$2f$Heading$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Heading"], {
                                        level: "h2",
                                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$NewsSection$2f$NewsSection$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["newsSectionTitleVariants"])(),
                                        children: title
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/organisms/NewsSection/NewsSection.tsx",
                                        lineNumber: 116,
                                        columnNumber: 25
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/organisms/NewsSection/NewsSection.tsx",
                                    lineNumber: 110,
                                    columnNumber: 21
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$m$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["m"].div, {
                                    initial: {
                                        opacity: 0,
                                        y: 20
                                    },
                                    whileInView: {
                                        opacity: 1,
                                        y: 0
                                    },
                                    viewport: {
                                        once: true,
                                        margin: "-100px"
                                    },
                                    transition: {
                                        duration: 0.6,
                                        delay: 0.1,
                                        ease: [
                                            0.25,
                                            1,
                                            0.5,
                                            1
                                        ]
                                    },
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Typography$2f$Text$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Text"], {
                                        variant: "lead",
                                        size: "lg",
                                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$NewsSection$2f$NewsSection$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["newsSectionSubtitleVariants"])(),
                                        children: subtitle
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/organisms/NewsSection/NewsSection.tsx",
                                        lineNumber: 126,
                                        columnNumber: 25
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/organisms/NewsSection/NewsSection.tsx",
                                    lineNumber: 120,
                                    columnNumber: 21
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/organisms/NewsSection/NewsSection.tsx",
                            lineNumber: 109,
                            columnNumber: 17
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimatePresence"], {
                            mode: "wait",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$m$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["m"].div, {
                                initial: {
                                    opacity: 0,
                                    y: 20
                                },
                                animate: {
                                    opacity: 1,
                                    y: 0
                                },
                                exit: {
                                    opacity: 0,
                                    y: -20
                                },
                                transition: {
                                    duration: 0.4,
                                    ease: [
                                        0.25,
                                        1,
                                        0.5,
                                        1
                                    ]
                                },
                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$NewsSection$2f$NewsSection$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["newsSectionGridVariants"])(),
                                children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$NewsSection$2f$NewsSection$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NEWS_SLOTS"].map((slot)=>{
                                    const item = getItem(slot.offset);
                                    if (!item) return null;
                                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])(slot.gridClass, (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$NewsSection$2f$NewsSection$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["newsSectionSlotVariants"])({
                                            position: slot.variant
                                        })),
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimatePresence"], {
                                            mode: "wait",
                                            initial: false,
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$m$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["m"].div, {
                                                initial: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$NewsSection$2f$NewsSection$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NEWS_DIRECTIONS"].up.enter,
                                                animate: {
                                                    y: 0,
                                                    opacity: 1
                                                },
                                                exit: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$NewsSection$2f$NewsSection$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NEWS_DIRECTIONS"].up.exit,
                                                transition: {
                                                    ...__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$NewsSection$2f$NewsSection$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NEWS_SPRING"],
                                                    delay: slot.delay
                                                },
                                                className: "w-full h-full",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$NewsCard$2f$NewsCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NewsCard"], {
                                                    data: {
                                                        id: item.id,
                                                        title: item.title,
                                                        excerpt: item.excerpt,
                                                        image: item.image,
                                                        category: item.category,
                                                        date: item.date,
                                                        readTime: item.readTime,
                                                        href: item.href
                                                    },
                                                    variant: slot.variant === "featured" ? "featured" : "preview",
                                                    onClick: ()=>handleSlotClick(slot)
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/organisms/NewsSection/NewsSection.tsx",
                                                    lineNumber: 163,
                                                    columnNumber: 45
                                                }, this)
                                            }, item.id, false, {
                                                fileName: "[project]/src/components/organisms/NewsSection/NewsSection.tsx",
                                                lineNumber: 155,
                                                columnNumber: 41
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/organisms/NewsSection/NewsSection.tsx",
                                            lineNumber: 154,
                                            columnNumber: 37
                                        }, this)
                                    }, slot.id, false, {
                                        fileName: "[project]/src/components/organisms/NewsSection/NewsSection.tsx",
                                        lineNumber: 147,
                                        columnNumber: 33
                                    }, this);
                                })
                            }, currentPage, false, {
                                fileName: "[project]/src/components/organisms/NewsSection/NewsSection.tsx",
                                lineNumber: 134,
                                columnNumber: 21
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/organisms/NewsSection/NewsSection.tsx",
                            lineNumber: 133,
                            columnNumber: 17
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/organisms/NewsSection/NewsSection.tsx",
                    lineNumber: 107,
                    columnNumber: 17
                }, this),
                totalPages > 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$NewsSection$2f$NewsSection$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["newsSectionPaginationVariants"])(),
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$PaginationDots$2f$PaginationDots$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PaginationDots"], {
                        size: "compact",
                        currentOffset: 0,
                        onOffsetChange: handleDotOffsetChange,
                        total: totalPages,
                        currentIndex: currentPage,
                        previewLabels: previewLabels
                    }, void 0, false, {
                        fileName: "[project]/src/components/organisms/NewsSection/NewsSection.tsx",
                        lineNumber: 189,
                        columnNumber: 25
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/organisms/NewsSection/NewsSection.tsx",
                    lineNumber: 188,
                    columnNumber: 21
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "md:hidden space-y-4",
                    children: (()=>{
                        const mFeatured = getItem(0);
                        const mPreviews = [
                            getItem(1),
                            getItem(2),
                            getItem(3)
                        ].filter(Boolean);
                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                            children: [
                                mFeatured && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$NewsSection$2f$NewsSection$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["newsSectionMobileCardVariants"])(),
                                    onClick: ()=>handleSlotClick(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$NewsSection$2f$NewsSection$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NEWS_SLOTS"][0]),
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$NewsSection$2f$NewsSection$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["newsSectionMobileMediaVariants"])(),
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                    src: mFeatured.image,
                                                    alt: mFeatured.title,
                                                    className: "w-full h-full object-cover"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/organisms/NewsSection/NewsSection.tsx",
                                                    lineNumber: 214,
                                                    columnNumber: 45
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "absolute top-4 left-4",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Badge$2f$Badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Badge"], {
                                                        variant: "primary",
                                                        size: "sm",
                                                        children: mFeatured.category
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/organisms/NewsSection/NewsSection.tsx",
                                                        lineNumber: 220,
                                                        columnNumber: 49
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/organisms/NewsSection/NewsSection.tsx",
                                                    lineNumber: 219,
                                                    columnNumber: 45
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/organisms/NewsSection/NewsSection.tsx",
                                            lineNumber: 213,
                                            columnNumber: 41
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$NewsSection$2f$NewsSection$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["newsSectionMobileContentVariants"])(),
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                    className: "font-headline text-lg font-bold text-secondary mb-2",
                                                    children: mFeatured.title
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/organisms/NewsSection/NewsSection.tsx",
                                                    lineNumber: 226,
                                                    columnNumber: 45
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "font-body text-sm text-muted-foreground line-clamp-2",
                                                    children: mFeatured.excerpt
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/organisms/NewsSection/NewsSection.tsx",
                                                    lineNumber: 229,
                                                    columnNumber: 45
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/organisms/NewsSection/NewsSection.tsx",
                                            lineNumber: 225,
                                            columnNumber: 41
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/organisms/NewsSection/NewsSection.tsx",
                                    lineNumber: 209,
                                    columnNumber: 37
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$NewsSection$2f$NewsSection$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["newsSectionMobileScrollVariants"])(),
                                    children: mPreviews.map((item, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$NewsSection$2f$NewsSection$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["newsSectionMobileItemVariants"])(),
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$NewsSection$2f$NewsSection$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["newsSectionMobileCardVariants"])(),
                                                onClick: ()=>handleSlotClick(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$NewsSection$2f$NewsSection$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NEWS_SLOTS"][idx + 1]),
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "aspect-square overflow-hidden",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                            src: item.image,
                                                            alt: item.title,
                                                            className: "w-full h-full object-cover"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/organisms/NewsSection/NewsSection.tsx",
                                                            lineNumber: 244,
                                                            columnNumber: 53
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/organisms/NewsSection/NewsSection.tsx",
                                                        lineNumber: 243,
                                                        columnNumber: 49
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "p-4",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Badge$2f$Badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Badge"], {
                                                                variant: "default",
                                                                size: "sm",
                                                                className: "mb-2",
                                                                children: item.category
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/organisms/NewsSection/NewsSection.tsx",
                                                                lineNumber: 251,
                                                                columnNumber: 53
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                                                className: "font-headline text-sm font-bold text-secondary mb-1",
                                                                children: item.title
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/organisms/NewsSection/NewsSection.tsx",
                                                                lineNumber: 254,
                                                                columnNumber: 53
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/organisms/NewsSection/NewsSection.tsx",
                                                        lineNumber: 250,
                                                        columnNumber: 49
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/organisms/NewsSection/NewsSection.tsx",
                                                lineNumber: 239,
                                                columnNumber: 45
                                            }, this)
                                        }, item.id, false, {
                                            fileName: "[project]/src/components/organisms/NewsSection/NewsSection.tsx",
                                            lineNumber: 238,
                                            columnNumber: 41
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/src/components/organisms/NewsSection/NewsSection.tsx",
                                    lineNumber: 236,
                                    columnNumber: 33
                                }, this)
                            ]
                        }, void 0, true);
                    })()
                }, void 0, false, {
                    fileName: "[project]/src/components/organisms/NewsSection/NewsSection.tsx",
                    lineNumber: 201,
                    columnNumber: 17
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/organisms/NewsSection/NewsSection.tsx",
            lineNumber: 106,
            columnNumber: 13
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/organisms/NewsSection/NewsSection.tsx",
        lineNumber: 105,
        columnNumber: 9
    }, this);
}
_s(NewsSection, "JugFgIc7q8F/F/QdP2igAxbW9Pk=");
_c = NewsSection;
var _c;
__turbopack_context__.k.register(_c, "NewsSection");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/organisms/VideosSection/VideosSection.variants.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "videosSectionCardVariants",
    ()=>videosSectionCardVariants,
    "videosSectionGridVariants",
    ()=>videosSectionGridVariants,
    "videosSectionItemVariants",
    ()=>videosSectionItemVariants,
    "videosSectionMediaVariants",
    ()=>videosSectionMediaVariants,
    "videosSectionMobileItemVariants",
    ()=>videosSectionMobileItemVariants,
    "videosSectionMobilePlayButtonVariants",
    ()=>videosSectionMobilePlayButtonVariants,
    "videosSectionMobileScrollVariants",
    ()=>videosSectionMobileScrollVariants,
    "videosSectionMobileThumbnailVariants",
    ()=>videosSectionMobileThumbnailVariants,
    "videosSectionPlayButtonVariants",
    ()=>videosSectionPlayButtonVariants,
    "videosSectionPlayIconVariants",
    ()=>videosSectionPlayIconVariants,
    "videosSectionPlayOverlayVariants",
    ()=>videosSectionPlayOverlayVariants,
    "videosSectionThumbnailVariants",
    ()=>videosSectionThumbnailVariants,
    "videosSectionTitleVariants",
    ()=>videosSectionTitleVariants
]);
// ============================================================================
// VIDEOS SECTION VARIANTS
// ============================================================================
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/class-variance-authority/dist/index.mjs [app-client] (ecmascript)");
;
const videosSectionGridVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("grid grid-cols-1 md:grid-cols-2 gap-8");
const videosSectionItemVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("");
const videosSectionCardVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("group cursor-pointer");
const videosSectionMediaVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("relative aspect-video rounded-2xl overflow-hidden bg-black mb-4");
const videosSectionThumbnailVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("w-full h-full object-cover opacity-80 group-hover:opacity-70 transition-opacity");
const videosSectionPlayOverlayVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("absolute inset-0 flex items-center justify-center");
const videosSectionPlayButtonVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("w-16 h-16 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center border border-white/40 group-hover:scale-110 transition-transform");
const videosSectionPlayIconVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("w-6 h-6 text-white fill-white ml-1");
const videosSectionTitleVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("font-headline text-lg font-semibold text-secondary");
const videosSectionMobileScrollVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("flex overflow-x-auto snap-x snap-mandatory gap-4 pb-4 -mx-4 px-4 hide-scrollbar");
const videosSectionMobileItemVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("snap-center shrink-0 w-[85vw] max-w-sm");
const videosSectionMobileThumbnailVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("w-full h-full object-cover opacity-80");
const videosSectionMobilePlayButtonVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("w-16 h-16 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center border border-white/40");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/organisms/VideosSection/VideosSection.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "VideosSection",
    ()=>VideosSection
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$m$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/render/components/m/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$LazyMotion$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/components/LazyMotion/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$framer$2d$features$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/framer-features.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Container$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/components/atoms/Container/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Container$2f$Container$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Container/Container.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Typography$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/components/atoms/Typography/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Typography$2f$Heading$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Typography/Heading.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$play$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Play$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/play.js [app-client] (ecmascript) <export default as Play>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Section$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/components/atoms/Section/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Section$2f$Section$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Section/Section.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$VideosSection$2f$VideosSection$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/organisms/VideosSection/VideosSection.variants.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
/** Hook simple para detectar breakpoint sin dependencias externas */ function useMediaQuery(query) {
    _s();
    const [matches, setMatches] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [mounted, setMounted] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useMediaQuery.useEffect": ()=>{
            setMounted(true);
            const mql = window.matchMedia(query);
            const handler = {
                "useMediaQuery.useEffect.handler": (e)=>setMatches(e.matches)
            }["useMediaQuery.useEffect.handler"];
            mql.addEventListener("change", handler);
            setMatches(mql.matches);
            return ({
                "useMediaQuery.useEffect": ()=>mql.removeEventListener("change", handler)
            })["useMediaQuery.useEffect"];
        }
    }["useMediaQuery.useEffect"], [
        query
    ]);
    // Durante SSR/hidratación, asumimos desktop para evitar mismatch
    if (!mounted) return true;
    return matches;
}
_s(useMediaQuery, "BOiu+fmMjYUqu4ggwXimg7pNkNM=");
function VideosSection({ videos, title, className }) {
    _s1();
    const [playingId, setPlayingId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const isDesktop = useMediaQuery("(min-width: 768px)");
    const getThumbnail = (youtubeId)=>{
        return `https://img.youtube.com/vi/${youtubeId}/maxresdefault.jpg`;
    };
    const handlePlay = (id)=>{
        setPlayingId(id);
    };
    const renderVideoCard = (video, index, isMobile)=>{
        const isPlaying = playingId === video.id;
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: isMobile ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$VideosSection$2f$VideosSection$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["videosSectionMobileItemVariants"])() : (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$VideosSection$2f$VideosSection$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["videosSectionItemVariants"])(),
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$m$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["m"].div, {
                initial: isMobile ? undefined : {
                    opacity: 0,
                    y: 20
                },
                whileInView: isMobile ? undefined : {
                    opacity: 1,
                    y: 0
                },
                viewport: isMobile ? undefined : {
                    once: true
                },
                transition: isMobile ? undefined : {
                    duration: 0.5,
                    delay: index * 0.1,
                    ease: [
                        0.25,
                        1,
                        0.5,
                        1
                    ]
                },
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$VideosSection$2f$VideosSection$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["videosSectionCardVariants"])(),
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$VideosSection$2f$VideosSection$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["videosSectionMediaVariants"])(),
                        children: isPlaying ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("iframe", {
                            src: `https://www.youtube.com/embed/${video.youtubeId}?autoplay=1`,
                            title: video.title,
                            className: "absolute inset-0 w-full h-full",
                            allow: "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture",
                            allowFullScreen: true
                        }, void 0, false, {
                            fileName: "[project]/src/components/organisms/VideosSection/VideosSection.tsx",
                            lineNumber: 102,
                            columnNumber: 29
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                    src: getThumbnail(video.youtubeId),
                                    alt: video.title,
                                    className: isMobile ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$VideosSection$2f$VideosSection$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["videosSectionMobileThumbnailVariants"])() : (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$VideosSection$2f$VideosSection$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["videosSectionThumbnailVariants"])()
                                }, void 0, false, {
                                    fileName: "[project]/src/components/organisms/VideosSection/VideosSection.tsx",
                                    lineNumber: 111,
                                    columnNumber: 33
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$VideosSection$2f$VideosSection$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["videosSectionPlayOverlayVariants"])(),
                                    onClick: ()=>handlePlay(video.id),
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: isMobile ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$VideosSection$2f$VideosSection$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["videosSectionMobilePlayButtonVariants"])() : (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$VideosSection$2f$VideosSection$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["videosSectionPlayButtonVariants"])(),
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$play$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Play$3e$__["Play"], {
                                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$VideosSection$2f$VideosSection$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["videosSectionPlayIconVariants"])()
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/organisms/VideosSection/VideosSection.tsx",
                                            lineNumber: 131,
                                            columnNumber: 41
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/organisms/VideosSection/VideosSection.tsx",
                                        lineNumber: 124,
                                        columnNumber: 37
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/organisms/VideosSection/VideosSection.tsx",
                                    lineNumber: 120,
                                    columnNumber: 33
                                }, this)
                            ]
                        }, void 0, true)
                    }, void 0, false, {
                        fileName: "[project]/src/components/organisms/VideosSection/VideosSection.tsx",
                        lineNumber: 100,
                        columnNumber: 21
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$VideosSection$2f$VideosSection$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["videosSectionTitleVariants"])(),
                        children: video.title
                    }, void 0, false, {
                        fileName: "[project]/src/components/organisms/VideosSection/VideosSection.tsx",
                        lineNumber: 137,
                        columnNumber: 21
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/organisms/VideosSection/VideosSection.tsx",
                lineNumber: 89,
                columnNumber: 17
            }, this)
        }, `${isMobile ? "m" : "d"}-${video.id}`, false, {
            fileName: "[project]/src/components/organisms/VideosSection/VideosSection.tsx",
            lineNumber: 85,
            columnNumber: 13
        }, this);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Section$2f$Section$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Section"], {
        id: "videos",
        background: "background",
        spacing: "lg",
        className: className,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Container$2f$Container$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Container"], {
            size: "lg",
            padding: "md",
            children: [
                title && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Typography$2f$Heading$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Heading"], {
                    level: "h2",
                    className: "mb-8 md:mb-12",
                    children: title
                }, void 0, false, {
                    fileName: "[project]/src/components/organisms/VideosSection/VideosSection.tsx",
                    lineNumber: 147,
                    columnNumber: 21
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$LazyMotion$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LazyMotion"], {
                    features: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$framer$2d$features$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
                    strict: true,
                    children: isDesktop ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$VideosSection$2f$VideosSection$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["videosSectionGridVariants"])(),
                        children: videos.map((video, i)=>renderVideoCard(video, i, false))
                    }, void 0, false, {
                        fileName: "[project]/src/components/organisms/VideosSection/VideosSection.tsx",
                        lineNumber: 155,
                        columnNumber: 21
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$VideosSection$2f$VideosSection$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["videosSectionMobileScrollVariants"])(),
                        children: videos.map((video, i)=>renderVideoCard(video, i, true))
                    }, void 0, false, {
                        fileName: "[project]/src/components/organisms/VideosSection/VideosSection.tsx",
                        lineNumber: 159,
                        columnNumber: 21
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/organisms/VideosSection/VideosSection.tsx",
                    lineNumber: 152,
                    columnNumber: 17
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/organisms/VideosSection/VideosSection.tsx",
            lineNumber: 145,
            columnNumber: 13
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/organisms/VideosSection/VideosSection.tsx",
        lineNumber: 144,
        columnNumber: 9
    }, this);
}
_s1(VideosSection, "APkvuh+GSpLExv2eFJmEz1tEh48=", false, function() {
    return [
        useMediaQuery
    ];
});
_c = VideosSection;
var _c;
__turbopack_context__.k.register(_c, "VideosSection");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/atoms/StarRating/StarRating.variants.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "starIconVariants",
    ()=>starIconVariants,
    "starRatingVariants",
    ()=>starRatingVariants
]);
// ============================================================================
// STAR RATING VARIANTS — Átomo de calificación visual
// ============================================================================
// REFACTOR V3:
// - Archivo creado (no existía). Extrae todo el CSS inline del .tsx.
// - starRatingVariants: contenedor flex del componente.
// - starIconVariants: cada icono Star de lucide-react, con size + state.
//   • state "filled" → text-secondary (navy marca)
//   • state "empty" → text-surface-variant (gris sutil)
// - Tipos derivados del CVA.
// ============================================================================
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/class-variance-authority/dist/index.mjs [app-client] (ecmascript)");
;
const starRatingVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("flex items-center gap-0.5");
const starIconVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("fill-current", {
    variants: {
        size: {
            sm: "w-4 h-4",
            md: "w-5 h-5",
            lg: "w-6 h-6"
        },
        state: {
            filled: "text-secondary",
            empty: "text-surface-variant"
        }
    },
    defaultVariants: {
        size: "sm",
        state: "empty"
    }
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/atoms/StarRating/StarRating.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// ============================================================================
// STAR RATING — Átomo de calificación visual
// ============================================================================
// REFACTOR V3:
// - Archivo .variants.ts creado (no existía).
// - Zero inline classes:
//   • "flex items-center gap-0.5" → starRatingVariants
//   • "fill-current" + tamaños + colores → starIconVariants
// - Lógica de renderizado (i < value) se mantiene; es pura JS, no CSS.
// ============================================================================
__turbopack_context__.s([
    "StarRating",
    ()=>StarRating
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$star$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Star$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/star.js [app-client] (ecmascript) <export default as Star>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$StarRating$2f$StarRating$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/StarRating/StarRating.variants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/utils/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils/cn.ts [app-client] (ecmascript)");
;
;
;
;
function StarRating({ value, max = 5, size = "sm", className }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$StarRating$2f$StarRating$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["starRatingVariants"])(), className),
        "aria-label": `Calificación: ${value} de ${max}`,
        role: "img",
        children: Array.from({
            length: max
        }).map((_, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$star$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Star$3e$__["Star"], {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$StarRating$2f$StarRating$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["starIconVariants"])({
                    size,
                    state: i < value ? "filled" : "empty"
                }))
            }, i, false, {
                fileName: "[project]/src/components/atoms/StarRating/StarRating.tsx",
                lineNumber: 41,
                columnNumber: 17
            }, this))
    }, void 0, false, {
        fileName: "[project]/src/components/atoms/StarRating/StarRating.tsx",
        lineNumber: 35,
        columnNumber: 9
    }, this);
}
_c = StarRating;
var _c;
__turbopack_context__.k.register(_c, "StarRating");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/atoms/Skeleton/Skeleton.variants.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "skeletonBlockVariants",
    ()=>skeletonBlockVariants,
    "skeletonCircleVariants",
    ()=>skeletonCircleVariants
]);
// ============================================================================
// SKELETON VARIANTS — Átomos de estado de carga
// ============================================================================
// REFACTOR V3:
// - Archivo unificado para SkeletonBlock y SkeletonCircle (ambos átomos de
//   carga con lógica similar, reduce overhead de archivos).
// - SkeletonBlock: corregido bug donde "animate-pulse" vivía en el base del
//   CVA, haciendo que animation="none" fuera un no-op (el base siempre gana).
//   Ahora "animate-pulse" vive solo en la variante animation.pulse.
// - Tokens validados contra paleta V3:
//   • bg-surface-variant: existe (#E2E8F0)
//   • bg-foreground/10: utilitario Tailwind válido para modo oscuro
//   • rounded-clay: existe
// - ALERTA: "animate-shimmer" no está definido en tailwind.config.ts visible.
//   Si no existe en el proyecto, esta variante es un token fantasma.
// - Tipos derivados del CVA.
// ============================================================================
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/class-variance-authority/dist/index.mjs [app-client] (ecmascript)");
;
const skeletonBlockVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("rounded", {
    variants: {
        variant: {
            default: "bg-surface-variant",
            muted: "bg-surface-variant/50",
            dark: "bg-foreground/10"
        },
        radius: {
            none: "rounded-none",
            sm: "rounded-sm",
            md: "rounded-md",
            lg: "rounded-lg",
            xl: "rounded-xl",
            full: "rounded-full",
            clay: "rounded-clay"
        },
        animation: {
            pulse: "animate-pulse",
            shimmer: "animate-shimmer bg-gradient-to-r from-surface-variant via-surface to-surface-variant bg-[length:200%_100%]",
            none: ""
        }
    },
    defaultVariants: {
        variant: "default",
        radius: "md",
        animation: "pulse"
    }
});
const skeletonCircleVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("animate-pulse rounded-full", {
    variants: {
        variant: {
            default: "bg-surface-variant",
            muted: "bg-surface-variant/50"
        },
        size: {
            xs: "w-6 h-6",
            sm: "w-8 h-8",
            md: "w-12 h-12",
            lg: "w-16 h-16",
            xl: "w-20 h-20",
            giant: "w-24 h-24"
        }
    },
    defaultVariants: {
        variant: "default",
        size: "md"
    }
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/atoms/Skeleton/SkeletonBlock.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SkeletonBlock",
    ()=>SkeletonBlock
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
// ============================================================================
// SKELETON BLOCK — Átomo de carga (rectángulo)
// ============================================================================
// REFACTOR V3:
// - CVA extraído a Skeleton.variants.ts (archivo compartido con SkeletonCircle).
// - Zero inline classes: todo el CSS vive en el CVA.
// - Bug corregido: animation="none" ahora funciona correctamente porque
//   "animate-pulse" ya no está hardcodeado en el base del CVA.
// ============================================================================
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Skeleton$2f$Skeleton$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Skeleton/Skeleton.variants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/utils/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils/cn.ts [app-client] (ecmascript)");
;
;
;
;
const SkeletonBlock = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = ({ className, variant, radius, animation, width, height, aspectRatio, style, ...props }, ref)=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Skeleton$2f$Skeleton$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["skeletonBlockVariants"])({
            variant,
            radius,
            animation
        }), className),
        style: {
            width,
            height,
            aspectRatio,
            ...style
        },
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/atoms/Skeleton/SkeletonBlock.tsx",
        lineNumber: 27,
        columnNumber: 13
    }, ("TURBOPACK compile-time value", void 0));
});
_c1 = SkeletonBlock;
SkeletonBlock.displayName = "SkeletonBlock";
;
var _c, _c1;
__turbopack_context__.k.register(_c, "SkeletonBlock$forwardRef");
__turbopack_context__.k.register(_c1, "SkeletonBlock");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/atoms/Skeleton/SkeletonCircle.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SkeletonCircle",
    ()=>SkeletonCircle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
// ============================================================================
// SKELETON CIRCLE — Átomo de carga (círculo)
// ============================================================================
// REFACTOR V3:
// - CVA extraído a Skeleton.variants.ts (archivo compartido con SkeletonBlock).
// - Zero inline classes: todo el CSS vive en el CVA.
// ============================================================================
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Skeleton$2f$Skeleton$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Skeleton/Skeleton.variants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/utils/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils/cn.ts [app-client] (ecmascript)");
;
;
;
;
const SkeletonCircle = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = ({ className, variant, size, ...props }, ref)=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Skeleton$2f$Skeleton$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["skeletonCircleVariants"])({
            variant,
            size
        }), className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/atoms/Skeleton/SkeletonCircle.tsx",
        lineNumber: 21,
        columnNumber: 13
    }, ("TURBOPACK compile-time value", void 0));
});
_c1 = SkeletonCircle;
SkeletonCircle.displayName = "SkeletonCircle";
;
var _c, _c1;
__turbopack_context__.k.register(_c, "SkeletonCircle$forwardRef");
__turbopack_context__.k.register(_c1, "SkeletonCircle");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/atoms/Skeleton/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
// ============================================================================
// SKELETON SYSTEM — Barrel export
// ============================================================================
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Skeleton$2f$SkeletonBlock$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Skeleton/SkeletonBlock.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Skeleton$2f$SkeletonCircle$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Skeleton/SkeletonCircle.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Skeleton$2f$Skeleton$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Skeleton/Skeleton.variants.ts [app-client] (ecmascript)");
;
;
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/atoms/StarRating/StarRatingSkeleton.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// components/atoms/StarRating/StarRatingSkeleton.tsx
__turbopack_context__.s([
    "StarRatingSkeleton",
    ()=>StarRatingSkeleton
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Skeleton$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/components/atoms/Skeleton/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Skeleton$2f$SkeletonBlock$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Skeleton/SkeletonBlock.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/utils/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils/cn.ts [app-client] (ecmascript)");
;
;
;
function StarRatingSkeleton({ max = 5, size = "sm", className }) {
    const starSize = size === "sm" ? "w-4 h-4" : size === "md" ? "w-5 h-5" : "w-6 h-6";
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("flex items-center gap-0.5", className),
        "aria-hidden": "true",
        children: Array.from({
            length: max
        }).map((_, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Skeleton$2f$SkeletonBlock$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SkeletonBlock"], {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("rounded-sm", starSize)
            }, i, false, {
                fileName: "[project]/src/components/atoms/StarRating/StarRatingSkeleton.tsx",
                lineNumber: 19,
                columnNumber: 17
            }, this))
    }, void 0, false, {
        fileName: "[project]/src/components/atoms/StarRating/StarRatingSkeleton.tsx",
        lineNumber: 17,
        columnNumber: 9
    }, this);
}
_c = StarRatingSkeleton;
var _c;
__turbopack_context__.k.register(_c, "StarRatingSkeleton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/atoms/StarRating/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
// ============================================================================
// STAR RATING SYSTEM — Barrel export
// ============================================================================
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$StarRating$2f$StarRating$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/StarRating/StarRating.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$StarRating$2f$StarRating$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/StarRating/StarRating.variants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$StarRating$2f$StarRatingSkeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/StarRating/StarRatingSkeleton.tsx [app-client] (ecmascript)");
;
;
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/organisms/Testimonials/Testimonials.variants.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "testimonialsArrowsWrapperVariants",
    ()=>testimonialsArrowsWrapperVariants,
    "testimonialsAuthorInfoVariants",
    ()=>testimonialsAuthorInfoVariants,
    "testimonialsAuthorVariants",
    ()=>testimonialsAuthorVariants,
    "testimonialsCardVariants",
    ()=>testimonialsCardVariants,
    "testimonialsCardWrapperVariants",
    ()=>testimonialsCardWrapperVariants,
    "testimonialsControlsVariants",
    ()=>testimonialsControlsVariants,
    "testimonialsDotVariants",
    ()=>testimonialsDotVariants,
    "testimonialsDotsWrapperVariants",
    ()=>testimonialsDotsWrapperVariants,
    "testimonialsFooterVariants",
    ()=>testimonialsFooterVariants,
    "testimonialsGridVariants",
    ()=>testimonialsGridVariants,
    "testimonialsHeaderVariants",
    ()=>testimonialsHeaderVariants,
    "testimonialsNameVariants",
    ()=>testimonialsNameVariants,
    "testimonialsOverlineVariants",
    ()=>testimonialsOverlineVariants,
    "testimonialsProductImageVariants",
    ()=>testimonialsProductImageVariants,
    "testimonialsProductVariants",
    ()=>testimonialsProductVariants,
    "testimonialsQuoteVariants",
    ()=>testimonialsQuoteVariants,
    "testimonialsRoleVariants",
    ()=>testimonialsRoleVariants
]);
// ============================================================================
// TESTIMONIALS VARIANTS — Organismo de testimonios
// ============================================================================
// REFACTOR V3:
// - Zero Inline Policy: todas las clases migradas desde .tsx
// - Tokens fantasmas:
//   • shadow-soft → shadow-clay
// - Nuevos CVA:
//   • testimonialsGridVariants
//   • testimonialsHeaderVariants
//   • testimonialsOverlineVariants
//   • testimonialsCardWrapperVariants
//   • testimonialsCardVariants
//   • testimonialsQuoteVariants
//   • testimonialsFooterVariants
//   • testimonialsAuthorVariants
//   • testimonialsAuthorInfoVariants
//   • testimonialsNameVariants
//   • testimonialsRoleVariants
//   • testimonialsProductVariants
//   • testimonialsProductImageVariants
//   • testimonialsControlsVariants
//   • testimonialsDotsWrapperVariants
//   • testimonialsDotVariants
//   • testimonialsArrowsWrapperVariants
// ============================================================================
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/class-variance-authority/dist/index.mjs [app-client] (ecmascript)");
;
const testimonialsGridVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("grid grid-cols-1 md:grid-cols-12 gap-10 items-center");
const testimonialsHeaderVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("md:col-span-4");
const testimonialsOverlineVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("mb-2 block");
const testimonialsCardWrapperVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("md:col-span-8");
const testimonialsCardVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("bg-white rounded-2xl p-8 md:p-10 shadow-clay border border-border/20 relative min-h-[280px] flex flex-col justify-between");
const testimonialsQuoteVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("font-body text-lg italic text-foreground leading-relaxed mb-8");
const testimonialsFooterVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("flex flex-col sm:flex-row items-start sm:items-center justify-between mt-8 gap-4");
const testimonialsAuthorVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("flex items-center gap-4");
const testimonialsAuthorInfoVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("");
const testimonialsNameVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("font-headline text-sm font-bold text-primary");
const testimonialsRoleVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("font-body text-xs text-foreground/60 uppercase tracking-wider");
const testimonialsProductVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("flex items-center gap-3");
const testimonialsProductImageVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("w-12 h-12 rounded-lg object-cover hidden sm:block");
const testimonialsControlsVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("flex items-center justify-between mt-6");
const testimonialsDotsWrapperVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("flex gap-2");
const testimonialsDotVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("h-2 rounded-full transition-all duration-300", {
    variants: {
        state: {
            active: "bg-primary w-6",
            inactive: "bg-surface-variant w-2 hover:bg-border"
        }
    },
    defaultVariants: {
        state: "inactive"
    }
});
const testimonialsArrowsWrapperVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("flex gap-2");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/organisms/Testimonials/Testimonials.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Testimonials",
    ()=>Testimonials
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$m$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/render/components/m/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/components/AnimatePresence/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$LazyMotion$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/components/LazyMotion/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$framer$2d$features$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/framer-features.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Container$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/components/atoms/Container/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Container$2f$Container$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Container/Container.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Typography$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/components/atoms/Typography/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Typography$2f$Heading$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Typography/Heading.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Typography$2f$Text$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Typography/Text.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$IconButton$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/components/atoms/IconButton/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$IconButton$2f$IconButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/IconButton/IconButton.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Avatar$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/components/atoms/Avatar/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Avatar$2f$Avatar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Avatar/Avatar.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$StarRating$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/components/atoms/StarRating/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$StarRating$2f$StarRating$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/StarRating/StarRating.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/utils/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils/cn.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$left$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowLeft$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/arrow-left.js [app-client] (ecmascript) <export default as ArrowLeft>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/arrow-right.js [app-client] (ecmascript) <export default as ArrowRight>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Section$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/components/atoms/Section/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Section$2f$Section$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Section/Section.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$Testimonials$2f$Testimonials$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/organisms/Testimonials/Testimonials.variants.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
function Testimonials({ testimonials, title = "Voces de la Comunidad", subtitle = "Descubre cómo JovenPro está transformando la vida de creadores alrededor del mundo.", overline = "Comunidad", className }) {
    _s();
    const [activeIndex, setActiveIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const goNext = ()=>{
        setActiveIndex((prev)=>(prev + 1) % testimonials.length);
    };
    const goPrev = ()=>{
        setActiveIndex((prev)=>(prev - 1 + testimonials.length) % testimonials.length);
    };
    const active = testimonials[activeIndex];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Section$2f$Section$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Section"], {
        id: "testimonios",
        spacing: "lg",
        background: "surface-container-low",
        className: className,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Container$2f$Container$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Container"], {
            size: "lg",
            padding: "md",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$Testimonials$2f$Testimonials$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["testimonialsGridVariants"])(),
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$Testimonials$2f$Testimonials$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["testimonialsHeaderVariants"])(),
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Typography$2f$Text$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Text"], {
                                variant: "overline",
                                size: "xs",
                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$Testimonials$2f$Testimonials$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["testimonialsOverlineVariants"])(),
                                children: overline
                            }, void 0, false, {
                                fileName: "[project]/src/components/organisms/Testimonials/Testimonials.tsx",
                                lineNumber: 81,
                                columnNumber: 25
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Typography$2f$Heading$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Heading"], {
                                level: "h2",
                                className: "mb-4",
                                children: title
                            }, void 0, false, {
                                fileName: "[project]/src/components/organisms/Testimonials/Testimonials.tsx",
                                lineNumber: 88,
                                columnNumber: 25
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Typography$2f$Text$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Text"], {
                                variant: "lead",
                                size: "base",
                                children: subtitle
                            }, void 0, false, {
                                fileName: "[project]/src/components/organisms/Testimonials/Testimonials.tsx",
                                lineNumber: 91,
                                columnNumber: 25
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/organisms/Testimonials/Testimonials.tsx",
                        lineNumber: 80,
                        columnNumber: 21
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$Testimonials$2f$Testimonials$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["testimonialsCardWrapperVariants"])(),
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$LazyMotion$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LazyMotion"], {
                                features: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$framer$2d$features$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
                                strict: true,
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimatePresence"], {
                                    mode: "wait",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$m$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["m"].div, {
                                        initial: {
                                            opacity: 0,
                                            x: 20
                                        },
                                        animate: {
                                            opacity: 1,
                                            x: 0
                                        },
                                        exit: {
                                            opacity: 0,
                                            x: -20
                                        },
                                        transition: {
                                            duration: 0.4,
                                            ease: [
                                                0.25,
                                                1,
                                                0.5,
                                                1
                                            ]
                                        },
                                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$Testimonials$2f$Testimonials$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["testimonialsCardVariants"])(),
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$Testimonials$2f$Testimonials$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["testimonialsQuoteVariants"])(),
                                                children: [
                                                    "“",
                                                    active.text,
                                                    "”"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/organisms/Testimonials/Testimonials.tsx",
                                                lineNumber: 108,
                                                columnNumber: 33
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$Testimonials$2f$Testimonials$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["testimonialsFooterVariants"])(),
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$Testimonials$2f$Testimonials$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["testimonialsAuthorVariants"])(),
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Avatar$2f$Avatar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Avatar"], {
                                                                src: active.avatar,
                                                                alt: active.name,
                                                                size: "lg"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/organisms/Testimonials/Testimonials.tsx",
                                                                lineNumber: 114,
                                                                columnNumber: 41
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$Testimonials$2f$Testimonials$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["testimonialsAuthorInfoVariants"])(),
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$Testimonials$2f$Testimonials$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["testimonialsNameVariants"])(),
                                                                        children: active.name
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/components/organisms/Testimonials/Testimonials.tsx",
                                                                        lineNumber: 120,
                                                                        columnNumber: 45
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$Testimonials$2f$Testimonials$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["testimonialsRoleVariants"])(),
                                                                        children: active.role
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/components/organisms/Testimonials/Testimonials.tsx",
                                                                        lineNumber: 123,
                                                                        columnNumber: 45
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/components/organisms/Testimonials/Testimonials.tsx",
                                                                lineNumber: 119,
                                                                columnNumber: 41
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/organisms/Testimonials/Testimonials.tsx",
                                                        lineNumber: 113,
                                                        columnNumber: 37
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$Testimonials$2f$Testimonials$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["testimonialsProductVariants"])(),
                                                        children: [
                                                            active.productImage && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                                src: active.productImage,
                                                                alt: "Producto",
                                                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$Testimonials$2f$Testimonials$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["testimonialsProductImageVariants"])()
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/organisms/Testimonials/Testimonials.tsx",
                                                                lineNumber: 131,
                                                                columnNumber: 45
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$StarRating$2f$StarRating$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StarRating"], {
                                                                value: active.rating,
                                                                size: "sm"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/organisms/Testimonials/Testimonials.tsx",
                                                                lineNumber: 137,
                                                                columnNumber: 41
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/organisms/Testimonials/Testimonials.tsx",
                                                        lineNumber: 129,
                                                        columnNumber: 37
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/organisms/Testimonials/Testimonials.tsx",
                                                lineNumber: 112,
                                                columnNumber: 33
                                            }, this)
                                        ]
                                    }, active.id, true, {
                                        fileName: "[project]/src/components/organisms/Testimonials/Testimonials.tsx",
                                        lineNumber: 100,
                                        columnNumber: 29
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/organisms/Testimonials/Testimonials.tsx",
                                    lineNumber: 99,
                                    columnNumber: 25
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/organisms/Testimonials/Testimonials.tsx",
                                lineNumber: 98,
                                columnNumber: 25
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$Testimonials$2f$Testimonials$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["testimonialsControlsVariants"])(),
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$Testimonials$2f$Testimonials$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["testimonialsDotsWrapperVariants"])(),
                                        children: testimonials.map((_, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                onClick: ()=>setActiveIndex(i),
                                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$cn$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$Testimonials$2f$Testimonials$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["testimonialsDotVariants"])({
                                                    state: i === activeIndex ? "active" : "inactive"
                                                })),
                                                "aria-label": `Testimonio ${i + 1}`
                                            }, i, false, {
                                                fileName: "[project]/src/components/organisms/Testimonials/Testimonials.tsx",
                                                lineNumber: 151,
                                                columnNumber: 37
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/organisms/Testimonials/Testimonials.tsx",
                                        lineNumber: 149,
                                        columnNumber: 29
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$Testimonials$2f$Testimonials$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["testimonialsArrowsWrapperVariants"])(),
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$IconButton$2f$IconButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IconButton"], {
                                                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$left$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowLeft$3e$__["ArrowLeft"], {
                                                    className: "w-5 h-5"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/organisms/Testimonials/Testimonials.tsx",
                                                    lineNumber: 167,
                                                    columnNumber: 43
                                                }, this),
                                                variant: "outline",
                                                size: "md",
                                                onClick: goPrev,
                                                "aria-label": "Anterior"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/organisms/Testimonials/Testimonials.tsx",
                                                lineNumber: 166,
                                                columnNumber: 33
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$IconButton$2f$IconButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IconButton"], {
                                                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__["ArrowRight"], {
                                                    className: "w-5 h-5"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/organisms/Testimonials/Testimonials.tsx",
                                                    lineNumber: 174,
                                                    columnNumber: 43
                                                }, this),
                                                variant: "default",
                                                size: "md",
                                                onClick: goNext,
                                                "aria-label": "Siguiente"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/organisms/Testimonials/Testimonials.tsx",
                                                lineNumber: 173,
                                                columnNumber: 33
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/organisms/Testimonials/Testimonials.tsx",
                                        lineNumber: 165,
                                        columnNumber: 29
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/organisms/Testimonials/Testimonials.tsx",
                                lineNumber: 148,
                                columnNumber: 25
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/organisms/Testimonials/Testimonials.tsx",
                        lineNumber: 97,
                        columnNumber: 21
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/organisms/Testimonials/Testimonials.tsx",
                lineNumber: 78,
                columnNumber: 17
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/organisms/Testimonials/Testimonials.tsx",
            lineNumber: 77,
            columnNumber: 13
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/organisms/Testimonials/Testimonials.tsx",
        lineNumber: 76,
        columnNumber: 9
    }, this);
}
_s(Testimonials, "rd+5N/MkYjuYD0I+B+MlySxQysU=");
_c = Testimonials;
var _c;
__turbopack_context__.k.register(_c, "Testimonials");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/organisms/WorkWithUs/WorkWithUs.variants.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "workWithUsCardVariants",
    ()=>workWithUsCardVariants,
    "workWithUsContentVariants",
    ()=>workWithUsContentVariants,
    "workWithUsDecoVariants",
    ()=>workWithUsDecoVariants,
    "workWithUsDescriptionVariants",
    ()=>workWithUsDescriptionVariants,
    "workWithUsDividerVariants",
    ()=>workWithUsDividerVariants,
    "workWithUsInnerVariants",
    ()=>workWithUsInnerVariants,
    "workWithUsLocationLabelVariants",
    ()=>workWithUsLocationLabelVariants,
    "workWithUsLocationSubVariants",
    ()=>workWithUsLocationSubVariants,
    "workWithUsMapImageVariants",
    ()=>workWithUsMapImageVariants,
    "workWithUsMapOverlayVariants",
    ()=>workWithUsMapOverlayVariants,
    "workWithUsMapVariants",
    ()=>workWithUsMapVariants,
    "workWithUsPinButtonVariants",
    ()=>workWithUsPinButtonVariants,
    "workWithUsPinIconVariants",
    ()=>workWithUsPinIconVariants,
    "workWithUsPinPingVariants",
    ()=>workWithUsPinPingVariants,
    "workWithUsPinWrapperVariants",
    ()=>workWithUsPinWrapperVariants,
    "workWithUsSocialsVariants",
    ()=>workWithUsSocialsVariants,
    "workWithUsTitleVariants",
    ()=>workWithUsTitleVariants,
    "workWithUsWhatsappLinkVariants",
    ()=>workWithUsWhatsappLinkVariants
]);
// ============================================================================
// WORK WITH US VARIANTS — Organismo de sección de contacto/mapa
// ============================================================================
// REFACTOR V3:
// - Zero Inline Policy: todas las clases migradas desde .tsx
// - shadow-ambient inexistente → shadow-clay
// - Tokens fantasmas: ninguno (WorkWithUs no usaba jp-* tokens)
// - Nuevos CVA:
//   • workWithUsSectionVariants: py del section
//   • workWithUsCardVariants: card principal bg-white + shadow
//   • workWithUsContentVariants: columna izquierda (texto + sociales)
//   • workWithUsDecoVariants: círculo decorativo blur
//   • workWithUsInnerVariants: wrapper relativo z-10
//   • workWithUsTitleVariants: override de Heading (mb + leading)
//   • workWithUsDescriptionVariants: subheadline
//   • workWithUsDividerVariants: separador antes de sociales
//   • workWithUsSocialsVariants: flex gap de botones sociales
//   • workWithUsMapVariants: columna derecha (mapa)
//   • workWithUsMapImageVariants: imagen del mapa con filtros
//   • workWithUsMapOverlayVariants: capa primary/10 sobre mapa
//   • workWithUsPinWrapperVariants: posicionamiento absoluto centrado
//   • workWithUsPinButtonVariants: botón circular del pin
//   • workWithUsPinPingVariants: animación ping del pin
//   • workWithUsPinIconVariants: icono del pin (w-8 h-8 text-secondary)
//   • workWithUsLocationLabelVariants: label de ubicación
//   • workWithUsLocationSubVariants: sub-label (opacity-80)
// ============================================================================
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/class-variance-authority/dist/index.mjs [app-client] (ecmascript)");
;
const workWithUsCardVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("bg-white rounded-3xl overflow-hidden shadow-clay border border-border/20 flex flex-col lg:flex-row");
const workWithUsContentVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("w-full lg:w-1/2 p-6 sm:p-10 md:p-16 flex flex-col justify-center relative overflow-hidden");
const workWithUsDecoVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("absolute -left-20 -bottom-20 w-64 h-64 bg-surface-container-low/50 rounded-full blur-3xl z-0");
const workWithUsInnerVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("relative z-10");
const workWithUsTitleVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("mb-6 leading-tight");
const workWithUsDescriptionVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("font-body text-foreground/70 text-base md:text-lg mb-6 md:mb-10 max-w-md leading-relaxed");
const workWithUsDividerVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("border-t border-border/30 pt-8");
const workWithUsSocialsVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("flex gap-3");
const workWithUsMapVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("w-full lg:w-1/2 relative min-h-[300px] md:min-h-[400px] bg-surface");
const workWithUsMapImageVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("absolute inset-0 w-full h-full object-cover opacity-60 mix-blend-multiply filter grayscale contrast-125");
const workWithUsMapOverlayVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("absolute inset-0 bg-primary/10");
const workWithUsPinWrapperVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 flex flex-col items-center");
const workWithUsPinButtonVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("w-16 h-16 bg-white rounded-full shadow-clay flex items-center justify-center relative mb-4 cursor-pointer");
const workWithUsPinPingVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("absolute inset-0 rounded-full border-2 border-secondary/30 animate-ping");
const workWithUsPinIconVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("w-8 h-8 text-secondary");
const workWithUsLocationLabelVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("bg-primary text-white px-5 py-3 rounded-xl font-body text-sm font-bold shadow-lg text-center");
const workWithUsLocationSubVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("font-normal text-xs opacity-80");
const workWithUsWhatsappLinkVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("font-headline text-base md:text-xl text-primary-dim underline font-bold block mt-4 hover:opacity-80 transition-opacity cursor-pointer bg-transparent border-none p-0");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/organisms/WorkWithUs/WorkWithUs.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "WorkWithUs",
    ()=>WorkWithUs
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$m$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/render/components/m/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$LazyMotion$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/components/LazyMotion/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$framer$2d$features$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/framer-features.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$instagram$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Instagram$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/instagram.js [app-client] (ecmascript) <export default as Instagram>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$facebook$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Facebook$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/facebook.js [app-client] (ecmascript) <export default as Facebook>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$message$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MessageCircle$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/message-circle.js [app-client] (ecmascript) <export default as MessageCircle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Container$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/components/atoms/Container/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Container$2f$Container$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Container/Container.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Typography$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/components/atoms/Typography/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Typography$2f$Heading$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Typography/Heading.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Typography$2f$Text$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Typography/Text.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$IconButton$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/components/atoms/IconButton/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$IconButton$2f$IconButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/IconButton/IconButton.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Section$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/components/atoms/Section/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Section$2f$Section$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Section/Section.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$WorkWithUs$2f$WorkWithUs$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/organisms/WorkWithUs/WorkWithUs.variants.ts [app-client] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
;
;
function WorkWithUs({ data, className, onOpenLink }) {
    const handleOpen = (url)=>{
        if (onOpenLink) {
            onOpenLink(url);
        } else {
            window.open(url, "_blank", "noopener,noreferrer");
        }
    };
    const socialLinks = [
        {
            id: "instagram",
            url: data.instagramUrl,
            label: "Instagram",
            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$instagram$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Instagram$3e$__["Instagram"], {
                className: "w-5 h-5"
            }, void 0, false, {
                fileName: "[project]/src/components/organisms/WorkWithUs/WorkWithUs.tsx",
                lineNumber: 73,
                columnNumber: 19
            }, this)
        },
        {
            id: "facebook",
            url: data.facebookUrl,
            label: "Facebook",
            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$facebook$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Facebook$3e$__["Facebook"], {
                className: "w-5 h-5"
            }, void 0, false, {
                fileName: "[project]/src/components/organisms/WorkWithUs/WorkWithUs.tsx",
                lineNumber: 79,
                columnNumber: 19
            }, this)
        },
        {
            id: "whatsapp",
            url: `https://wa.me/${data.whatsappNumber}?text=${encodeURIComponent(data.whatsappMessage)}`,
            label: "WhatsApp",
            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$message$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MessageCircle$3e$__["MessageCircle"], {
                className: "w-5 h-5"
            }, void 0, false, {
                fileName: "[project]/src/components/organisms/WorkWithUs/WorkWithUs.tsx",
                lineNumber: 85,
                columnNumber: 19
            }, this)
        }
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Section$2f$Section$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Section"], {
        id: "contacto",
        background: "background",
        spacing: "lg",
        className: className,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Container$2f$Container$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Container"], {
            size: "lg",
            padding: "md",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$WorkWithUs$2f$WorkWithUs$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["workWithUsCardVariants"])(),
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$WorkWithUs$2f$WorkWithUs$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["workWithUsContentVariants"])(),
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$WorkWithUs$2f$WorkWithUs$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["workWithUsDecoVariants"])()
                            }, void 0, false, {
                                fileName: "[project]/src/components/organisms/WorkWithUs/WorkWithUs.tsx",
                                lineNumber: 95,
                                columnNumber: 25
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$WorkWithUs$2f$WorkWithUs$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["workWithUsInnerVariants"])(),
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Typography$2f$Text$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Text"], {
                                        variant: "overline",
                                        size: "xs",
                                        className: "mb-4 block",
                                        children: data.sectionLabel
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/organisms/WorkWithUs/WorkWithUs.tsx",
                                        lineNumber: 97,
                                        columnNumber: 29
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$LazyMotion$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LazyMotion"], {
                                        features: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$framer$2d$features$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
                                        strict: true,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$m$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["m"].div, {
                                                initial: {
                                                    opacity: 0,
                                                    y: 20
                                                },
                                                whileInView: {
                                                    opacity: 1,
                                                    y: 0
                                                },
                                                viewport: {
                                                    once: true
                                                },
                                                transition: {
                                                    duration: 0.6,
                                                    ease: [
                                                        0.25,
                                                        1,
                                                        0.5,
                                                        1
                                                    ]
                                                },
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Typography$2f$Heading$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Heading"], {
                                                    level: "h2",
                                                    variant: "primary",
                                                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$WorkWithUs$2f$WorkWithUs$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["workWithUsTitleVariants"])(),
                                                    children: data.headline
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/organisms/WorkWithUs/WorkWithUs.tsx",
                                                    lineNumber: 112,
                                                    columnNumber: 33
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/organisms/WorkWithUs/WorkWithUs.tsx",
                                                lineNumber: 106,
                                                columnNumber: 29
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$m$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["m"].div, {
                                                initial: {
                                                    opacity: 0,
                                                    y: 20
                                                },
                                                whileInView: {
                                                    opacity: 1,
                                                    y: 0
                                                },
                                                viewport: {
                                                    once: true
                                                },
                                                transition: {
                                                    duration: 0.6,
                                                    delay: 0.1,
                                                    ease: [
                                                        0.25,
                                                        1,
                                                        0.5,
                                                        1
                                                    ]
                                                },
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$WorkWithUs$2f$WorkWithUs$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["workWithUsDescriptionVariants"])(),
                                                    children: data.subheadline
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/organisms/WorkWithUs/WorkWithUs.tsx",
                                                    lineNumber: 131,
                                                    columnNumber: 33
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/organisms/WorkWithUs/WorkWithUs.tsx",
                                                lineNumber: 121,
                                                columnNumber: 29
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$m$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["m"].div, {
                                                initial: {
                                                    opacity: 0,
                                                    y: 20
                                                },
                                                whileInView: {
                                                    opacity: 1,
                                                    y: 0
                                                },
                                                viewport: {
                                                    once: true
                                                },
                                                transition: {
                                                    duration: 0.6,
                                                    delay: 0.2,
                                                    ease: [
                                                        0.25,
                                                        1,
                                                        0.5,
                                                        1
                                                    ]
                                                },
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    onClick: ()=>handleOpen(`https://wa.me/${data.whatsappNumber}?text=${encodeURIComponent(data.whatsappMessage)}`),
                                                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$WorkWithUs$2f$WorkWithUs$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["workWithUsWhatsappLinkVariants"])(),
                                                    children: data.whatsappDisplayLabel
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/organisms/WorkWithUs/WorkWithUs.tsx",
                                                    lineNumber: 146,
                                                    columnNumber: 33
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/organisms/WorkWithUs/WorkWithUs.tsx",
                                                lineNumber: 136,
                                                columnNumber: 29
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/organisms/WorkWithUs/WorkWithUs.tsx",
                                        lineNumber: 105,
                                        columnNumber: 29
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$WorkWithUs$2f$WorkWithUs$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["workWithUsDividerVariants"])(),
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Typography$2f$Text$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Text"], {
                                                variant: "overline",
                                                size: "xs",
                                                className: "mb-4 block",
                                                children: data.socialsLabel
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/organisms/WorkWithUs/WorkWithUs.tsx",
                                                lineNumber: 156,
                                                columnNumber: 33
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$WorkWithUs$2f$WorkWithUs$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["workWithUsSocialsVariants"])(),
                                                children: socialLinks.map((social)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$IconButton$2f$IconButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IconButton"], {
                                                        icon: social.icon,
                                                        variant: "social",
                                                        size: "lg",
                                                        "aria-label": social.label,
                                                        onClick: ()=>handleOpen(social.url)
                                                    }, social.id, false, {
                                                        fileName: "[project]/src/components/organisms/WorkWithUs/WorkWithUs.tsx",
                                                        lineNumber: 166,
                                                        columnNumber: 41
                                                    }, this))
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/organisms/WorkWithUs/WorkWithUs.tsx",
                                                lineNumber: 164,
                                                columnNumber: 33
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/organisms/WorkWithUs/WorkWithUs.tsx",
                                        lineNumber: 155,
                                        columnNumber: 29
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/organisms/WorkWithUs/WorkWithUs.tsx",
                                lineNumber: 96,
                                columnNumber: 25
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/organisms/WorkWithUs/WorkWithUs.tsx",
                        lineNumber: 94,
                        columnNumber: 21
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$WorkWithUs$2f$WorkWithUs$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["workWithUsMapVariants"])(),
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                src: data.mapImageUrl,
                                alt: "Mapa",
                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$WorkWithUs$2f$WorkWithUs$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["workWithUsMapImageVariants"])()
                            }, void 0, false, {
                                fileName: "[project]/src/components/organisms/WorkWithUs/WorkWithUs.tsx",
                                lineNumber: 182,
                                columnNumber: 25
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$WorkWithUs$2f$WorkWithUs$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["workWithUsMapOverlayVariants"])()
                            }, void 0, false, {
                                fileName: "[project]/src/components/organisms/WorkWithUs/WorkWithUs.tsx",
                                lineNumber: 187,
                                columnNumber: 25
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$WorkWithUs$2f$WorkWithUs$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["workWithUsPinWrapperVariants"])(),
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$WorkWithUs$2f$WorkWithUs$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["workWithUsPinButtonVariants"])(),
                                        onClick: ()=>handleOpen(data.mapUrl),
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$WorkWithUs$2f$WorkWithUs$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["workWithUsPinIconVariants"])(),
                                                viewBox: "0 0 24 24",
                                                fill: "currentColor",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                    d: "M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/organisms/WorkWithUs/WorkWithUs.tsx",
                                                    lineNumber: 199,
                                                    columnNumber: 37
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/organisms/WorkWithUs/WorkWithUs.tsx",
                                                lineNumber: 194,
                                                columnNumber: 33
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$WorkWithUs$2f$WorkWithUs$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["workWithUsPinPingVariants"])()
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/organisms/WorkWithUs/WorkWithUs.tsx",
                                                lineNumber: 201,
                                                columnNumber: 33
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/organisms/WorkWithUs/WorkWithUs.tsx",
                                        lineNumber: 190,
                                        columnNumber: 29
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$WorkWithUs$2f$WorkWithUs$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["workWithUsLocationLabelVariants"])(),
                                        children: [
                                            data.locationLabel,
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                                fileName: "[project]/src/components/organisms/WorkWithUs/WorkWithUs.tsx",
                                                lineNumber: 206,
                                                columnNumber: 33
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$WorkWithUs$2f$WorkWithUs$2e$variants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["workWithUsLocationSubVariants"])(),
                                                children: data.locationSubLabel
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/organisms/WorkWithUs/WorkWithUs.tsx",
                                                lineNumber: 207,
                                                columnNumber: 33
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/organisms/WorkWithUs/WorkWithUs.tsx",
                                        lineNumber: 204,
                                        columnNumber: 29
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/organisms/WorkWithUs/WorkWithUs.tsx",
                                lineNumber: 189,
                                columnNumber: 25
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/organisms/WorkWithUs/WorkWithUs.tsx",
                        lineNumber: 181,
                        columnNumber: 21
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/organisms/WorkWithUs/WorkWithUs.tsx",
                lineNumber: 92,
                columnNumber: 17
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/organisms/WorkWithUs/WorkWithUs.tsx",
            lineNumber: 91,
            columnNumber: 13
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/organisms/WorkWithUs/WorkWithUs.tsx",
        lineNumber: 90,
        columnNumber: 9
    }, this);
}
_c = WorkWithUs;
var _c;
__turbopack_context__.k.register(_c, "WorkWithUs");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_0khraa3._.js.map